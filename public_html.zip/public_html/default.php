<script type="text/javascript">
      window.location="dashboard/StaffLogin.php";
   </script>