<?php
  include "header.php";
  include "connection.php";
   $adm=$_GET["adm"];
  if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {

  $st=mysqli_fetch_array(mysqli_query($link , "select * from student where adm_no='$adm'"));
  $tut=mysqli_fetch_array(mysqli_query($link , "select * from tution2022 where adm_no='$adm'"));
  if($st["conveyance2022"]=="YES")
    $con=mysqli_fetch_array(mysqli_query($link , "select * from conveyance2022 where adm_no='$adm'"));
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Update Student</h2>
            </div>
          </header>
    


    <div class="container-fluid">
      <br>
      <form name="form1" class="form" action="" method="post">
      <div class="row bg-white has-shadow">
        <div class="col-md-4">
          <div class="form-group row">
                          Student Type
                          <div class="col-sm-6">
                            <select name="sttype" class="form-control form-control-sm mb-3">
                              <option><?php echo $st["sttype"]; ?></option>
                              <option><?php if($st["sttype"]=="NEW")
                                               echo "OLD";
                                            else
                                               echo "NEW" ?></option>
                              
                            </select>
                          </div>
           </div>
         </div>
        <div class="col-md-4">
          <div class="form-group row">
          Admission No.
          <?php 
           echo "<div class='col-sm-6'><input type='text' name='adm' value=".$adm." class='form-control form-control-sm mb-3' disabled></div>"  ?>
         </div>
        </div>
        <div class="col-md-4">
          <div class="form-group row">
          Class
          
         
         <div class="col-sm-6">
         <input type="text" name="class"  value="<?php echo $st["class2023"]; ?>" required class="form-control form-control-sm " disabled>
         </div>
         </div>
        </div>
      </div>

      <br>

      <div class="row bg-white has-shadow">
          <div class="col-md-6">
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Name</label>
                          <div class="col-sm-6">
                            <input type="text" name="stname"  value="<?php echo $st["name"]; ?>" required class="form-control form-control-sm ">
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Father's Name</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="fname" value="<?php echo $st["father_name"]; ?>" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Mother's Name</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="mname" value="<?php echo $st["mother_name"]; ?>" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Address</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="add1" value="<?php echo $st["add1"]; ?>" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label"></label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="add2" value="<?php echo $st["add2"]; ?>" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Contact No.</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="mob1" value="<?php echo $st["contact1"]; ?>" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label"></label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="mob2" value="<?php echo $st["contact2"]; ?>" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Aadhar No.</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="aadhaar" value="<?php echo $st["aadhaar"]; ?>" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Date of Birth</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="dob" value="<?php echo $st["dob"]; ?>" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Nationality</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="nationality" value="Indian" >
                          </div>
            </div>

          </div>



          <div class="col-md-6">
            
            
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Religion</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="religion" value="<?php echo $st["religion"]; ?>" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Caste</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="caste" value="<?php echo $st["caste"]; ?>" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Gender</label>
                          <div class="col-sm-6">
                            <select name="gender" class="form-control form-control-sm mb-3">
                              <option>Male</option>
                              <option>Female</option>
                              
                            </select>
                          </div>
            </div>
            

            <center>Ensure that all the information provided are correct.<br><br><br>
              <input type="submit" class="btn btn-primary" name="submit1">
              </center>

          </div>



          
      </div>
      </form>       
    </div>

<?php
       if(!isset($_POST["submit1"]))
       {
         
              
       }
         else
         {
          echo $adm;
            
            $sqlQ = "UPDATE student SET name='$_POST[stname]', father_name='$_POST[fname]', mother_name='$_POST[mname]', dob='$_POST[dob]',aadhaar='$_POST[aadhaar]', add1='$_POST[add1]', add2='$_POST[add2]',
            contact1='$_POST[mob1]',contact2='$_POST[mob2]', caste='$_POST[caste]', religion='$_POST[religion]' where adm_no='$adm'";
            mysqli_query($link, $sqlQ);
            echo $adm;
            
           
           ?>
          <!-- <script type="text/javascript">-->
          
          <!--  alert("\n\n\n            Updated Successfuly\n\n            Admission No. : <?php echo $adm; ?>");-->
  
            
          <!--  window.location="<?php echo "./adm_success.php?adm=".$adm; ?>" ;-->
          <!--</script>-->
           
           
           <?php
            
      }        
     
      ?>
        
     
           
           <?php
           }
           
           
           
     
      ?>
        
     







<?php
  include "footer.php";
?>
          
          