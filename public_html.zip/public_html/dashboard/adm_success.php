<?php
  include "connection.php";
  include "header.php";
  if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
  $adm=$_GET["adm"];
  $res=mysqli_query($link,"select * from student where adm_no='$adm'");
  $c=mysqli_num_rows($res);
  $row=mysqli_fetch_array($res);
  $tres=mysqli_fetch_array(mysqli_query($link,"select * from tution2024 where adm_no='$adm'"));
		 ?>
<!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Admission Status</h2>
            </div>
          </header>
    <div class="container">
    			<br>
              <br><BR>
		 <?php
  if($c==0)
  {
	  echo "<center>Admission Not Successful.\n Please try it again</center><br><hr><br><hr><br><hr><br><hr><br><hr><br><hr>";
  }
  else
  {
	  echo "<center><u><b>Admission/Updation Successful</u></b><br>";
	  echo "Admission No.  :  ".$adm."<br>";
	   echo  "Student Type : ".$row["sttype"]."<br>";
	  echo  "Name : ".$row["name"]."<br>";
	  echo  "Father's Name : ".$row["father_name"]."<br>";
	  echo  "Mother's Name : ".$row["mother_name"]."<br>";
	  echo  "Class : ".$row["class2023"]."<br>";
	  echo  "Tution Fee : ".$tres["fee"]."<br>";
	  echo  "Conveyance Fee : ".$row["conveyance2024"];
	  if($row["conveyance2024"]=="YES")
	  {
		  $cres=mysqli_fetch_array(mysqli_query($link,"select * from conveyance2024 where adm_no='$adm'"));
		  echo "/".$cres["fee"]."<br>";
	  }
	 
	 echo "<br><BR><BR>";
	 
  
  
  ?>
  <div class="col-md-4">
  <a   class="btn btn-primary" href="./adm_slip.php?adm=<?php echo $adm; ?>" target=_blank>Click here to Print Admission Slip</a>
</div><br>
  <div class="col-md-4">
  <a class="btn btn-primary" href="./fee_payment.php?adm_no=<?php echo $adm; ?>">Click here to Pay Fee</a>
  </div><br>
  <div class="col-md-4">
  <a class="btn btn-primary" href="./update_st.php?adm=<?php echo $adm; ?>">Click here to Update Student Detail</a>
  </div><br>
 
    
	
    
  </div>
  <?php
}
?>
  <?php
    }
     include "footer.php"
	 ?>