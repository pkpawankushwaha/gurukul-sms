<?php
  include "header.php";
   if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Students Count</h2>
            </div>
          </header>
    <div class="container bg-white">
        <h1>2024-25</h1>
                
                <?php
                
                  $cl=mysqli_query($link,"select * from class");
                  $count=0;$count=mysqli_num_rows($cl);$total=0;
                  while($count>0)
                    {   
                      $row=mysqli_fetch_array($cl);
                    //   echo "<option>".$row["class"]."</option>";
                      $ccc = mysqli_num_rows(mysqli_query($link,"select * from student where class2024='$row[class]'" ));
                      echo $row["class"]."  -  ".$ccc."<br>";
                      $total=$total+$ccc;
                      $count-=1;
                    
                      }
                      echo "Total = ".$total;
                ?>
          <h1>2023-24</h1>
              
        <?php
        
           $cl=mysqli_query($link,"select * from class");
           $count=0;$count=mysqli_num_rows($cl);$total=0;
           while($count>0)
             {   
              $row=mysqli_fetch_array($cl);
            //   echo "<option>".$row["class"]."</option>";
               $ccc = mysqli_num_rows(mysqli_query($link,"select * from student where class2023='$row[class]'" ));
               echo $row["class"]."  -  ".$ccc."<br>";
               $total=$total+$ccc;
              $count-=1;
            
              }
              echo "Total = ".$total;
        ?>
        
        
    <h1>2022-23</h1>
              
        <?php
        
           $cl=mysqli_query($link,"select * from class");
           $count=0;$count=mysqli_num_rows($cl);$total=0;
           while($count>0)
             {   
              $row=mysqli_fetch_array($cl);
            //   echo "<option>".$row["class"]."</option>";
               $ccc = mysqli_num_rows(mysqli_query($link,"select * from student where class2022='$row[class]'" ));
               echo $row["class"]."  -  ".$ccc."<br>";
               $total=$total+$ccc;
              $count-=1;
            
              }
              echo "Total = ".$total;
        ?>
        
        <h1>2021-22</h1>
              
        <?php
        
           $cl=mysqli_query($link,"select * from class");
           $count=0;$count=mysqli_num_rows($cl);$total=0;
           while($count>0)
             {   
              $row=mysqli_fetch_array($cl);
            //   echo "<option>".$row["class"]."</option>";
               $ccc = mysqli_num_rows(mysqli_query($link,"select * from student where class2021='$row[class]'" ));
               echo $row["class"]."  -  ".$ccc."<br>";
               $total=$total+$ccc;
              $count-=1;
            
              }
              echo "Total = ".$total;
        ?>
        <h1>2020-21</h1>
              
        <?php
        
           $cl=mysqli_query($link,"select * from class");
           $count=0;$count=mysqli_num_rows($cl);$total=0;
           while($count>0)
             {   
              $row=mysqli_fetch_array($cl);
            //   echo "<option>".$row["class"]."</option>";
               $ccc = mysqli_num_rows(mysqli_query($link,"select * from student where class2020='$row[class]'" ));
               echo $row["class"]."  -  ".$ccc."<br>";
               $total=$total+$ccc;
              $count-=1;
            
              }
              echo "Total = ".$total;
        ?>
        <h1>2019-20</h1>
              
        <?php
        
           $cl=mysqli_query($link,"select * from class");
           $count=0;$count=mysqli_num_rows($cl);$total=0;
           while($count>0)
             {   
              $row=mysqli_fetch_array($cl);
            //   echo "<option>".$row["class"]."</option>";
               $ccc = mysqli_num_rows(mysqli_query($link,"select * from student where class='$row[class]'" ));
               echo $row["class"]."  -  ".$ccc."<br>";
               $total=$total+$ccc;
              $count-=1;
            
              }
              echo "Total = ".$total;
        ?>
        
   
              
        <?php
        
          
        
     }
     include "footer.php";
   
   ?>