<?php
  include "header.php";
  include "connection.php";
  if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Remainder</h2>
            </div>
          </header>


   		  <div class="container bg-white">
    	  		<form name="form1" class="form" action="generate_reminder.php" method="post">
    			<div class="form-group row">
     				 <div class="col-md-4"></div>
     					 <div class="col-md-2">Select Class</div>
      						  <div class="col-md-2">
        					  <select name="class" class="form-control form-control-sm mb-3">
                    			<option>All</option>
        						<?php
        
							           $cl=mysqli_query($link,"select * from class");
							           $count=0;$count=mysqli_num_rows($cl);
							           while($count>0)
							             {   
							              $row=mysqli_fetch_array($cl);
							               echo "<option>".$row["class"]."</option>";
							              $count-=1;
							            
							              }
        
							        ?>
							   </select>
							</div>
				</div>
				<div class="form-group row">
					<div class="col-md-2"></div>
					<div class='col-md-8'>
						<b><u>Tuition Fees<br></u></b><br>
					<table ><tr>
						<td><input type=checkbox name=April value=April> April &nbsp </td>
						<td><input type=checkbox name=May value=May> May &nbsp </td>
						<td><input type=checkbox name=June value=June> June &nbsp </td>
						<td><input type=checkbox name=July value=July> July &nbsp </td>
						<td><input type=checkbox name=August value=August> August &nbsp </td>
						<td><input type=checkbox name=September value=September> September &nbsp </td></tr>
						<tr>
						<td><input type=checkbox name=October value=October> October &nbsp </td>
						<td><input type=checkbox name=November value=November> November &nbsp </td>
						<td><input type=checkbox name=December value=December> December &nbsp </td>
						<td><input type=checkbox name=Janaury value=Janaury> Janaury &nbsp </td>
						<td><input type=checkbox name=February value=February> February &nbsp </td>
						<td><input type=checkbox name=March value=March> March &nbsp </td>
						
					</tr></table>
					</div>
					<div class="col-md-2"></div>
   		 		 </div>

   		 		 <div class="form-group row">
					<div class="col-md-2"></div>
					<div class='col-md-8'>
						<b><u>Conveyance Fees<br></u></b><br>
					<table ><tr>
						<td><input type=checkbox name=cApril value=April> April &nbsp </td>
						<td><input type=checkbox name=cMay value=May> May &nbsp </td>
						<td><input type=checkbox name=cJune value=June> June &nbsp </td>
						<td><input type=checkbox name=cJuly value=July> July &nbsp </td>
						<td><input type=checkbox name=cAugust value=August> August &nbsp </td>
						<td><input type=checkbox name=cSeptember value=September> September &nbsp </td></tr>
						<tr>
						<td><input type=checkbox name=cOctober value=October> October &nbsp </td>
						<td><input type=checkbox name=cNovember value=November> November &nbsp </td>
						<td><input type=checkbox name=cDecember value=December> December &nbsp </td>
						<td><input type=checkbox name=cJanaury value=Janaury> Janaury &nbsp </td>
						<td><input type=checkbox name=cFebruary value=February> February &nbsp </td>
						<td><input type=checkbox name=cMarch value=March> March &nbsp </td>
						
					</tr></table>
					</div>
					<div class="col-md-2"></div>
   		 		 </div>

				<div class="form-group row">
					<div class="col-md-2"></div>
					<div class='col-md-8'>
						<b><u>Other Fees<br></u></b><br>
					<table ><tr>
						<td><input type=checkbox name=idcard value=idcard> ID Card &nbsp </td>
						<td><input type=checkbox name=exam1 value=exam1> TM Exam &nbsp </td>
						<td><input type=checkbox name=exam2 value=exam2> HY Exam &nbsp </td>
						<td><input type=checkbox name=exam3 value=exam3> Y Exam &nbsp </td>
						<td><input type=checkbox name=result_card value=result_card> ResultCard &nbsp </td>
						
						
					</tr></table>
					</div>
					<div class="col-md-2"></div>
   		 		 </div>

   		 		 <div>
   		 		 	<center><input type="submit" name="submit" class="btn btn-primary" value="Generate Remainder">
   		 		 	</center>
   		 		 </div>
<?php
}
?>

<?php
 include "footer.php";
 ?>
