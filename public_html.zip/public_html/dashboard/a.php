<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>GSS Gurukul Shikshan Sansthan</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <div class="page">
			<div style="height:1140px;width: 1200px">
				<div class="row" style="min-height: 540px;width: 1200px">
					<div class="col-md-1"></div>
					<div class="col-md-5">
						  			<table border=3 height=480px width=385px>
	     <tr>
		  <td width=49%>
		     <div style="height:150px">
				    <font size=5px><center><b>Gurukul Shikshan Sansthan</b> </center></font>
					<font size=3px><center>Khampar(Jaipur) Deoria (U.P.) </center><hr>
					<center><b><u>FEE Reminder RECIEPT</b></u></center></font></b></center>
					<b>Date : </b><?php echo date('d/m/Y');?>&nbsp  &nbsp&nbsp <?php echo $row["class"];?> &nbsp&nbsp &nbsp 
					<b>Adm.No.: </b><?php echo $row["adm_no"]; ?><br>
					<center><b>Name : </b><?php echo $row["name"];?></center>
					--------------------------------------------------------------------
			 </div>
             <div style="height:160px">	

			       <table  border=1 min-height=500px  width=100%>
				      <th>Particulars</th><th width=20%>Amt(Rs.)</th><tr>
					  <td><b><u>Tuition Fee</b></u><br><?php echo $st;?>&nbsp&nbsp&nbsp&nbsp</b></td><td style="text-align:right;">563</td></tr>
					  <tr><td><b><u>Conveyance Fee</b></u><br><?php echo $st;?>&nbsp&nbsp&nbsp&nbsp</b></td><td style="text-align:right;">563</td></tr>
					  <tr><td><b><u>Other Fee</b></u></b></td><td style="text-align:right;">563</td></tr>	   
				  	 </td></tr>
				  	 <tr><td><b><u>Total Fee</b></u></b></td><td style="text-align:right;">563</td></tr>	   
				  	 </td></tr>
				  	</table>
				  	</div>
				  	<pre>
मान्यवर,
    अभिभावक महोदय,
आपके पाल्य का मासिक शुल्क बकाया है| कुल मिलाकर इनका 
बकाया शुल्क रु० <?php echo "23231"; ?> है|
   आपसे यह निवेदन है कि शुल्क का भुगतान यथाशीघ्र करके
 पठन-पाठन कार्य सुचारू रूप से चलाने में हमारी मदद करें|
</pre>

				  	<br><br><div style="text-align:right;"><b>Cashier/Clerk &nbsp&nbsp&nbsp&nbsp</b></div>
			 
		    
		</td></tr></table>
					</div>
					<div class="col-md-1"></div>
					<div class="col-md-5">
						LelloLords
					</div>
					

				</div>
				<div class="row" style="min-height: 540px;width: 800px">
					
					<div class="col-md-6">
						HelloWorlds
					</div>
					<div class="col-md-6">
						LelloLords
					</div>
					

				</div>
			</div>
	</div>

	<script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>
</body>
