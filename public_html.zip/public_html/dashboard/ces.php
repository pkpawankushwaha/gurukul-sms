<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>CES ANSWER EVALUATION</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.png">
   		<!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
  <body>
  		<header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">CES ANSWER EVALUATION</h2>
            </div>
        </header>
  		<div class="container-fluid bg-white has-shadow">
  			<BR><BR>
  			<form name="form1" class="form" action="" method="post">
  					<div class="form-group row">
  						<div class="col-md-2">
  							Name
  						</div>
  						<div class="col-md-2">
  							<input type="text" name="Name" class="form-control form-control-sm" placeholder="Student FullName">
  						</div>
  					</div>
  					<div class="form-group row">
  						<div class="col-md-2">
  							Branch
  						</div>
  						<div class="col-md-2">
  							<input type="text" name="branch" class="form-control form-control-sm" placeholder="Branch">
  						</div>
  					</div>
  					<div class="form-group row">
  						<div class="col-md-2">
  							Mobile
  						</div>
  						<div class="col-md-2">
  							<input type="text" name="mobile" class="form-control form-control-sm" placeholder="Mobile No.">
  						</div>
  					</div>

  					<?php
  					  $c=1;
  					  while($c<=40)
  					  {
  					  	$Q="Q".$c;
  					  	?>
  					  	<div class="form-group row">
  						<div class="col-md-2">
  							<?php echo $Q;?>
  						</div>
  						<div class="col-md-2">
  							<input type="text" name="<?php echo $Q;?>" class="form-control form-control-sm" placeholder="Answer for <?php echo $Q;?>">
  						</div>
  					</div>
  					  	<?php

  					  	$c+=1;
  					  }
  					  ?>
  					  <input type="submit" name="submit" value="Submit" class="btn btn-primary">
  					
  			</form>
  			<br><BR>
  			<?php
       if(!isset($_POST["submit"]))
       {
         
              
       }
         else
         {  
          echo $_POST["Name"]."\n";
          
          echo $_POST["branch"]."\n";
          echo $_POST["mobile"]."\n";
          echo $_POST["Q31"]."\n";
          echo $_POST["Q1"]."\n";
          echo $_POST["Q40"];
      }
      ?>
           <BR><BR><BR><BR><BR>
  		</div>

  </body>
</html>
