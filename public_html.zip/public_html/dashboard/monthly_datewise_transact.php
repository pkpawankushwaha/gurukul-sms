<?php
  include "header.php";
   if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
      $mon=$_GET['mon'];
      $session=$_GET['session'];
      $sqlQuery;
      $monFormat = "%".$mon."%";
      switch ($session) {
        case 'reciept2024':
            $classCol = 'class2023';
            $sqlQuery = "SELECT * FROM reciept2024 INNER JOIN student ON reciept2024.adm_no = student.adm_no WHERE student.class2023 IN ('I A', 'I B', 'II A', 'II B', 'III A', 'III B', 'IV A', 'IV B', 'V A', 'V B') and date LIKE '$monFormat' ORDER BY date ASC";
            break;
        case 'reciept2023':
            $classCol = 'class2022';
            $sqlQuery = "SELECT * FROM reciept2023 INNER JOIN student ON reciept2023.adm_no = student.adm_no WHERE student.class2022 IN ('I A', 'I B', 'II A', 'II B', 'III A', 'III B', 'IV A', 'IV B', 'V A', 'V B') and date LIKE '$monFormat' ORDER BY date ASC";
            break;
        case 'reciept2022':
            $classCol = 'class2021';
            $sqlQuery = "SELECT * FROM reciept2022 INNER JOIN student ON reciept2022.adm_no = student.adm_no WHERE student.class2021 IN ('I A', 'I B', 'II A', 'II B', 'III A', 'III B', 'IV A', 'IV B', 'V A', 'V B') and date LIKE '$monFormat' ORDER BY date ASC";
            break;
      }

    $res=mysqli_query($link, $sqlQuery);
   ?>
   <table border=1 width=100%>
        <th>Date</th><th>Fee</th><tr>
        <?php 
            $date = 1;
            $totalM=0;
            while($date<=31) {
              $c=1;
              $res1=mysqli_query($link, $sqlQuery);
              $count=mysqli_num_rows($res1);
              $totalt=0;$totalc=0;$totalo=0;
              $dateFormatted = "";
              if($date<10) $dateFormatted ="0";
              $dateFormatted = $dateFormatted.$date."/".$mon;
              while($c<=$count)
              {    $row=mysqli_fetch_array($res1);

                if($row['date'] == $dateFormatted) {
                   
                   $otherfee=$row["form"]+$row["idcard"]+$row["tie_belt"]+$row["adm_fee"]+$row["exam1"]+$row["exam2"]+$row["exam3"]+$row["result_card"];
                  
                      $totalt+=$row["t_m_amt"];$totalc+=$row["c_m_amt"];$totalo+=$otherfee;
                }
                  
                  $c+=1;
              }
              $date +=1;
              echo "<td>".$dateFormatted."</td><td>".($totalt+$totalc+$totalo)."</td><tr>";
              $totalM = $totalM + ($totalt+$totalc+$totalo);
            }
            
            echo "<td><b>Total</b></td><td><b>".($totalM)."</b></td><tr>";
            echo "</table>";
        }
        ?>

    </table>