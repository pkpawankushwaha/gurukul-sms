<?php
    // session_start();
	
   
    include "connection.php";
    
    $cl=mysqli_query($link,"select * from studentDump");
           $count=0;$count=mysqli_num_rows($cl);
           while($count>0)
             {   
              $row=mysqli_fetch_array($cl);
               
               ?>
              <?php
               $adm=$row["adm_no"];
               $sqlQ = "UPDATE student SET name='$row[name]', 
                            father_name='$row[father_name]', 
                            mother_name='$row[mother_name]', dob='$row[dob]',aadhaar='$row[aadhaar]', add1='$row[add1]', add2='$row[add2]',
            contact1='$row[contact1]',contact2='$row[contact2]', caste='$row[caste]', religion='$row[religion]' where adm_no='$adm'";
            
                echo $adm;
                mysqli_query($link, $sqlQ);
            // mysqli_query($link, $sqlQ);
            // echo $adm;
              $count-=1;
            
              }
    ?>