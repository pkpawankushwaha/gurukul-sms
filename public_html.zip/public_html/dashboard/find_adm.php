<?php
  include "header.php";
   if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Admission Status</h2>
            </div>
          </header>
    <div class="container bg-white"><br>
             <form name="form1" class="form" action="" method="post">
               <center><div class="form-group row">
                <div class="col-md-4"></div>
                <div class="col-md-4"><input type="text" name="adm" class="form-control form-control-sm" placeholder="Admission No." ></div>
               <div class="col-md-4"><input type="submit" name="submit" value="Submit" class="btn btn-primary"></div>
             </div>
              </center>
            </form>
              <center>
            <?php 
       
     if(!isset($_POST["submit"]))
      {
        
      }
         
      else
      { 
           $adm=$_POST["adm"];
       $res=mysqli_query($link,"select * from student where adm_no='$adm'");
       
       $c=mysqli_num_rows($res);
       if($c==0)
         echo "<br><br> <b>Admission No. <font color=red>".$_POST["adm"]." </font> is not found</b>";
       else 
       {
           echo "<br><br><a href =adm_slip.php?adm=".$adm." target=_blank>Click here to Print Admission Slip</a>";
         echo "<br><br><a href =update_st.php?adm=".$adm.">Click here to Update Student Details</a>";
       }
      }
      ?>
      </center>
    </div>






<?php
}
?>


<?php
  include "footer.php";
?>
          
          