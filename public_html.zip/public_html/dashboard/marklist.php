<?php
  include "header.php";
   if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Mark List</h2>
            </div>
          </header>
    <div class="container bg-white">

               
    <form name="form1" class="form" action="" method="post">
    <div class="form-group row">
      <div class="col-md-4"></div>
      <div class="col-md-2">Select Class</div>
        <div class="col-md-2">
        <select name="class" class="form-control form-control-sm mb-3">
                    
        <?php
        
           $cl=mysqli_query($link,"select * from class");
           $count=0;$count=mysqli_num_rows($cl);
           while($count>0)
             {   
              $row=mysqli_fetch_array($cl);
               echo "<option>".$row["class"]."</option>";
              $count-=1;
            
              }
        
        ?>
    </select></div></div>
    
    <center><input type="submit" class="btn btn-primary" name="submit1"></center>
    </form><br>
  
  <?php
     if(!isset($_POST["submit1"]))
       {
         
              
       }
         else
         {     echo "<center>Students in class ".$_POST["class"]." : ";
               $res1=mysqli_query($link,"select * from student where class2024='$_POST[class]'");
           $c=mysqli_num_rows($res1);
           echo $c;
          ?>
            <br><br>
            <a href="print_marklist.php?class=<?php echo $_POST["class"]; ?>" target=_blank><font size=6px>Click here to print Mark List</font></a>
          <?php
       }
       echo "</center>";
     }
     include "footer.php";
   
   ?>