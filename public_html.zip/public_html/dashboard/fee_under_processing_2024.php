<?php
  include "header.php";
  include "connection.php";
  if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Reciept Details</h2>
            </div>
          </header>
    <div class="container">
<?php
 
   
   
   $row=mysqli_fetch_array(mysqli_query($link,"select * from tution2025 where adm_no='$_GET[adm]'"));
   $fee=0;$total=0;$m_c=0;$m_t=0;
   $fee=$row["fee"];$cfee=0;$tfee=0;
   $rec=(mysqli_num_rows(mysqli_query($link,"select * from reciept2025"))+20241111);
   $otherfee_res=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2025 where adm_no=20190000"));
				
   $date=date("d/m/Y");
   $cfa=array(0,0,0,0,0,0,0,0,0,0,0,0);
   
   
   
   $tfn="0";
   $tln="0";
   $cfn="0";
   $cln="0";
   
   $adm=$_GET["adm"];
   
   echo "<center><div class='table-responsive'><table border=1 width='80%'><tr><th width=8px>SNo.</th><th width=400px>Particulars</th><th width=2px>Amount</th></tr>";
   echo "<td>1</td><td><b>Tution FEE<b><br>";
 //-------------------------------------------------------------------------------------------  
   $count=0;
   
   if(isset($_POST["April"]))
   {
	   echo "April";
	   if($tfn=="0")
		   $tfn="April";
	   $tln="April";
	   $tfa1=1;
	   $count+=1;$m_t+=1;
	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["May"]))
   {   echo "May";
		if($tfn=="0")
		   $tfn="May";
	   $tln="May";
			   $count+=1;$m_t+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["June"]))
   {   echo "June";
		if($tfn=="0")
		   $tfn="June";
	   $tln="June";
	   $count+=1;$m_t+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["July"]))
   {    echo "July";
		if($tfn=="0")
		   $tfn="July";
	   $tln="July";
	   $count+=1;$m_t+=1;$tfa[3]=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["August"]))
   {    echo "August";
	  if($tfn=="0")
		   $tfn="August";
	   $tln="August";
	   $count+=1;$m_t+=1;$tfa[4]=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["September"]))
   {   echo "September";$tfa[5]=1;
	  if($tfn=="0")
		   $tfn="September";
	   $tln="September";
	   $count+=1;$m_t+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["October"]))
   {    echo "October";
		if($tfn=="0")
		   $tfn="October";
	   $tln="October";
	   $count+=1;$m_t+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["November"]))
   {    echo "November";
		if($tfn=="0")
		   $tfn="November";
	   $tln="November";
	   $count+=1;$m_t+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["December"]))
   {   echo "December";
		if($tfn=="0")
		   $tfn="December";
	   $tln="December";
	   $count+=1;$m_t+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["January"]))
   {   echo "January";
		if($tfn=="0")
		   $tfn="January";
	   $tln="January";
	   $count+=1;$m_t+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["February"]))
   {
	   echo "February";
	   if($tfn=="0")
		   $tfn="February";
	   $tln="February";
	   $count+=1;$m_t+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["March"]))
   {   echo "March";
		if($tfn=="0")
		   $tfn="March";
	   $tln="March";
	   $count+=1;$m_t+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   $total+=($count*$fee);$tfee=($count*$fee);
   echo "</td><td>$count*$fee=".$count*$fee."</td></tr>";
   $s=1;
   
//-------------------------------------------------------------------------------------   
 if(mysqli_num_rows(mysqli_query($link,"select * from conveyance2025 where adm_no='$_GET[adm]'"))!=0)
 { $s+=1;
   echo "<td>".$s."</td><td><b>Conveyance FEE<b><br>";
   $row=mysqli_fetch_array(mysqli_query($link,"select * from conveyance2025 where adm_no='$_GET[adm]'"));
   $fee=$row["fee"];$count=0;
   if(isset($_POST["cApril"]))
   {
	   echo "April";
	   if($cfn=="0")
		   $cfn="April";
	   $cln="April";
	   $count+=1;$cfa[0]=1;
	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["cMay"]))
   {   echo "May";
		if($cfn=="0")
		   $cfn="May";
	   $cln="May";
	   $count+=1;$cfa[1]=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["cJune"]))
   {   echo "June";
		if($cfn=="0")
		   $cfn="June";
	   $cln="June";
	   $count+=1;$cfa[2]=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["cJuly"]))
   {    echo "July";
		if($cfn=="0")
		   $cfn="July";
	   $cln="July";
	   $count+=1;$cfa[3]=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["cAugust"]))
   {    echo "August";$cfa[4]=1;
        if($cfn=="0")
		   $cfn="August";
	   $cln="August";
	   $count+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["cSeptember"]))
   {   echo "September";$cfa[5]=1;
		if($cfn=="0")
		   $cfn="September";
	   $cln="September";
	   $count+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["cOctober"]))
   {    echo "October";$cfa[6]=1;
	   $count+=1;
	   if($cfn=="0")
		   $cfn="October";
	   $cln="October";
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["cNovember"]))
   {    echo "November";$cfa[7]=1;
       if($cfn=="0")
		   $cfn="November";
	   $cln="November";
	   $count+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["cDecember"]))
   {   echo "December";$cfa[8]=1;
	  if($cfn=="0")
		   $cfn="December";
	   $cln="December";
	   $count+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["cJanuary"]))
   {   echo "January";$cfa[9]=1;
		if($cfn=="0")
		   $cfn="January";
	   $cln="January";
	   $count+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["cFebruary"]))
   {
	   echo "February";$cfa[10]=1;
	   if($cfn=="0")
		   $cfn="February";
	   $cln="February";
	   $count+=1;
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   if(isset($_POST["cMarch"]))
   {   echo "March";$cfa[11]=1;
	   $count+=1;
	   if($cfn=="0")
		   $cfn="March";
	   $cln="March";
	   	   if($count==4||$count==8||$count==12)
		   echo "<br>";
   }
   $m_c=$count;
   $total+=($count*$fee);$cfee=($count*$fee);
   echo "</td><td>$count*$fee=".$count*$fee."</td></tr>";
   
 }  
   if(isset($_POST["form"]))
   {   $s+=1;
	   echo "<td>".$s."</td><td><b>Form</b></td><td style='text-align:right;'>".$otherfee_res["form_rec"]."</td><tr>";
	   $total+=$otherfee_res["form_rec"];
	   
   }
if(isset($_POST["tie_belt"]))
   {   $s+=1;
	   echo "<td>".$s."</td><td><b>Tie and Belt</b></td><td style='text-align:right;'>".$otherfee_res["tie_belt_rec"]."</td><tr>";
	   $total+=$otherfee_res["tie_belt_rec"];
   }
   if(isset($_POST["adm_fee"]))
   {   $s+=1;
	   echo "<td>".$s."</td><td><b>Admission Fee</b></td><td style='text-align:right;'>".$otherfee_res["adm_fee_rec"]."</td><tr>";
	   $total+=$otherfee_res["adm_fee_rec"];
   }
   if(isset($_POST["idcard"]))
   {   $s+=1;
	   echo "<td>".$s."</td><td><b>Identity Card</b></td><td style='text-align:right;'>".$otherfee_res["idcard_rec"]."</td><tr>";
	   $total+=$otherfee_res["idcard_rec"];
   }
   if(isset($_POST["exam1"]))
   {   $s+=1;
	   echo "<td>".$s."</td><td><b>Third Monthly Exam</b></td><td style='text-align:right;'>".$otherfee_res["exam1_rec"]."</td><tr>";
	   $total+=$otherfee_res["exam1_rec"];
   }
   if(isset($_POST["exam2"]))
   {   $s+=1;
	   echo "<td>".$s."</td><td><b>Half Yearly Exam</b></td><td style='text-align:right;'>".$otherfee_res["exam2_rec"]."</td><tr>";
	   $total+=$otherfee_res["exam2_rec"];
   }
   if(isset($_POST["exam3"]))
   {   $s+=1;
	   echo "<td>".$s."</td><td><b>Yearly Exam</b></td><td style='text-align:right;'>".$otherfee_res["exam3_rec"]."</td><tr>";
	   $total+=$otherfee_res["exam3_rec"];
   }
   if(isset($_POST["result_card"]))
   {   $s+=1;
	   echo "<td>".$s."</td><td><b>Result Card</b></td><td style='text-align:right;'>".$otherfee_res["result_card_rec"]."</td><tr>";
	   $total+=$otherfee_res["result_card_rec"];
   }
   echo "<tr><th></th><th>Total</th><th>".$total."</th></tr></table></div>";
   
   
   
  
  
  
  
  ?>
  
   
	 
  <?php
  
   
	         
			 
	         if(isset($_POST["April"]))
				{   
	                $result=mysqli_query($link,"update tution2025 set April='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set April_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set April_date='$date' where adm_no='$adm'");		
							
				}
			if(isset($_POST["May"]))
				{
	                $result=mysqli_query($link,"update tution2025 set May='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set May_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set May_date='$date' where adm_no='$adm'");
				}
			if(isset($_POST["June"]))
				{
	                $result=mysqli_query($link,"update tution2025 set June='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set June_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set June_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["July"]))
				{
	                $result=mysqli_query($link,"update tution2025 set July='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set July_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set July_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["August"]))
				{
	                $result=mysqli_query($link,"update tution2025 set August='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set August_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set August_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["September"]))
				{
	                $result=mysqli_query($link,"update tution2025 set September='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set September_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set September_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["October"]))
				{
	                $result=mysqli_query($link,"update tution2025 set October='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set October_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set October_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["November"]))
				{
					$result=mysqli_query($link,"update tution2025 set November='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set November_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set November_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["December"]))
				{
	                $result=mysqli_query($link,"update tution2025 set December='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set December_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set December_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["January"]))
				{
	                $result=mysqli_query($link,"update tution2025 set January='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set January_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set January_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["February"]))
				{
					$result=mysqli_query($link,"update tution2025 set February='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set February_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set February_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["March"]))
				{
	               	$result=mysqli_query($link,"update tution2025 set March='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set March_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update tution2025 set March_date='$date' where adm_no='$adm'");

				}
			 
//-------------------------------------------------------------------------------------			 
			 if(isset($_POST["cApril"]))
				{
	                $result=mysqli_query($link,"update conveyance2025 set April='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set April_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set April_date='$date' where adm_no='$adm'");				
				}
			if(isset($_POST["cMay"]))
				{
	                $result=mysqli_query($link,"update conveyance2025 set May='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set May_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set May_date='$date' where adm_no='$adm'");
				}
			if(isset($_POST["cJune"]))
				{
	                $result=mysqli_query($link,"update conveyance2025 set June='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set June_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set June_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["cJuly"]))
				{
	                $result=mysqli_query($link,"update conveyance2025 set July='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set July_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set July_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["cAugust"]))
				{
	                $result=mysqli_query($link,"update conveyance2025 set August='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set August_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set August_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["cSeptember"]))
				{
	                $result=mysqli_query($link,"update conveyance2025 set September='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set September_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set September_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["cOctober"]))
				{
	                $result=mysqli_query($link,"update conveyance2025 set October='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set October_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set October_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["cNovember"]))
				{
						                $result=mysqli_query($link,"update conveyance2025 set November='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set November_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set November_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["cDecember"]))
				{
	                	                $result=mysqli_query($link,"update conveyance2025 set December='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set December_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set December_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["cJanuary"]))
				{
	                	                $result=mysqli_query($link,"update conveyance2025 set January='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set January_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set January_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["cFebruary"]))
				{
						                $result=mysqli_query($link,"update conveyance2025 set February='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set February_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set February_date='$date' where adm_no='$adm'");

				}
			if(isset($_POST["cMarch"]))
				{
	               	                $result=mysqli_query($link,"update conveyance2025 set March='Y' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set March_rec='$rec' where adm_no='$adm'");
					$result=mysqli_query($link,"update conveyance2025 set March_date='$date' where adm_no='$adm'");

				}
			 $tfn=$tfn."-".$tln;
			 $cfn=$cfn."-".$cln;
//--------------------------------------------------------------------------
				




//---------------------------------------------------------------------------------
	//$teacher=mysqli_query($link,"select * from teacher where name='$_SESSION[teacher_user]");
	//$tcash=$teacher["cashinhand"]+$total;
   
   $idc=$rec;
  mysqli_query($link,"insert into reciept2025 values('$rec','$rec','$_GET[adm]','$date','$_SESSION[teacher_user]','$m_t','$tfee','$tfn','$m_c','$cfee','$cfn','0','0','0','0','0','0','0','0','$total')");
	//mysqli_query($link,"update teacher set cashinhand='$tcash' where name='$_SESSION[teacher_user]");
//---------------------------------------------------------otherfee---------------------------------------             
   if(isset($_POST["form"]))
   {   
      $result=mysqli_query($link,"update reciept2025 set form=".$otherfee_res["form_rec"]." where rec_no='$rec'");
	   mysqli_query($link,"update otherfee2025 set form='Y' where adm_no='$adm'");
	   mysqli_query($link,"update otherfee2025 set form_rec='$rec' where adm_no='$adm'");
		mysqli_query($link,"update otherfee2025 set form_date='$date' where adm_no='$adm'");


   }
if(isset($_POST["tie_belt"]))
   {   $result=mysqli_query($link,"update reciept2025 set tie_belt=".$otherfee_res["tie_belt_rec"]." where rec_no='$rec'");
	   mysqli_query($link,"update otherfee2025 set tie_belt='Y' where adm_no='$adm'");
	   mysqli_query($link,"update otherfee2025 set tie_belt_rec='$rec' where adm_no='$adm'");
		mysqli_query($link,"update otherfee2025 set tie_belt_date='$date' where adm_no='$adm'");
   }
   if(isset($_POST["adm_fee"]))
   {   $result=mysqli_query($link,"update reciept2025 set adm_fee=".$otherfee_res["adm_fee_rec"]." where rec_no='$rec'");
	   mysqli_query($link,"update otherfee2025 set adm_fee='Y' where adm_no='$adm'");
	   mysqli_query($link,"update otherfee2025 set adm_fee_rec='$rec' where adm_no='$adm'");
		mysqli_query($link,"update otherfee2025 set adm_fee_date='$date' where adm_no='$adm'");
   }
   if(isset($_POST["idcard"]))
   {   $result=mysqli_query($link,"update reciept2025 set idcard=".$otherfee_res["idcard_rec"]." where rec_no='$rec'");
	   mysqli_query($link,"update otherfee2025 set idcard='Y' where adm_no='$adm'");
	   mysqli_query($link,"update otherfee2025 set idcard_rec='$rec' where adm_no='$adm'");
		mysqli_query($link,"update otherfee2025 set idcard_date='$date' where adm_no='$adm'");
   }
   if(isset($_POST["exam1"]))
   {   $result=mysqli_query($link,"update reciept2025 set exam1=".$otherfee_res["exam1_rec"]." where rec_no='$rec'");
	   mysqli_query($link,"update otherfee2025 set exam1='Y' where adm_no='$adm'");
	   mysqli_query($link,"update otherfee2025 set exam1_rec='$rec' where adm_no='$adm'");
		mysqli_query($link,"update otherfee2025 set exam1_date='$date' where adm_no='$adm'");
   }
   if(isset($_POST["exam2"]))
   {   $result=mysqli_query($link,"update reciept2025 set exam2=".$otherfee_res["exam2_rec"]." where rec_no='$rec'");
	   mysqli_query($link,"update otherfee2025 set exam2='Y' where adm_no='$adm'");
	   mysqli_query($link,"update otherfee2025 set exam2_rec='$rec' where adm_no='$adm'");
		mysqli_query($link,"update otherfee2025 set exam2_date='$date' where adm_no='$adm'");
   }
   if(isset($_POST["exam3"]))
   {   $result=mysqli_query($link,"update reciept2025 set exam3=".$otherfee_res["exam3_rec"]." where rec_no='$rec'");
	   mysqli_query($link,"update otherfee2025 set exam3='Y' where adm_no='$adm'");
	   mysqli_query($link,"update otherfee2025 set exam3_rec='$rec' where adm_no='$adm'");
		mysqli_query($link,"update otherfee2025 set exam3_date='$date' where adm_no='$adm'");
   }
   if(isset($_POST["result_card"]))
   {   $result=mysqli_query($link,"update reciept2025 set result_card=".$otherfee_res["result_card_rec"]." where rec_no='$rec'");
	   mysqli_query($link,"update otherfee2025 set result_card=50 where adm_no='$adm'");
	   mysqli_query($link,"update otherfee2025 set result_card_rec='$rec' where adm_no='$adm'");
		mysqli_query($link,"update otherfee2025 set result_card_date='$date' where adm_no='$adm'");
   }
  
 //---------------------------------------------------------otherfee---------------------------------------       
             echo "<br><br><font color=red size=5px>FEE PAID SUCCESSFULLY<br>Reciept No. : ".$rec."</font><br>";
  
             
  ?>
       <br><br><?php echo "<a href=reciept.php?rec=".$rec." target=_blank class='btn btn-primary'>Click here to Print Reciept</a>"; ?>
  
   
  
    </div>
<?php
}
?>
    <?php
    	include "footer.php";
    	?>