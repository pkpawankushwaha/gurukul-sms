<?php
 session_start();
 include "connection.php";
if(!isset($_SESSION["teacher_user"]))
    {
        echo "Access Denied.<br>Login to continue";
    }
	else
	{
 $date=$_GET["date"];
 
 $res=mysqli_query($link,"select * from reciept where date='$date'");
 $count=mysqli_num_rows($res);
 $res21=mysqli_query($link,"select * from reciept2021 where date='$date'");
  $res22=mysqli_query($link,"select * from reciept2022 where date='$date'"); 
  $res23=mysqli_query($link,"select * from reciept2023 where date='$date'");
  $res24=mysqli_query($link,"select * from reciept2024 where date='$date'");
  $res25=mysqli_query($link,"select * from reciept2025 where date='$date'");
 $c=1; ?>
 <center>
<b>Gurukul Shikshan Sansthan Khampar(Jaipur) Deoria(UP)<b><br>
 <u>Daily Fee Report 2019-20 Detailed </u>  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
 <?php echo "<b>Date : </b>".$date."<br><br>"; ?>
 <table border=1 width=100%>
 <th>N.</th><th>Rec.No.</th><th>Adm.No.</th><th>Name</th><th>Class</th><th>Tution Fee</th><th>Conveyance FEE</th><th>Other FEE</th><th>Total</th><th>Teacher</th><tr>
<?php 
  $totalt=0;$totalc=0;$totalo=0;
 while($c<=$count)
 {    $row=mysqli_fetch_array($res);
      $rowst=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$row[adm_no]'"));
     
      $otherfee=$row["form"]+$row["idcard"]+$row["tie_belt"]+$row["adm_fee"]+$row["exam1"]+$row["exam2"]+$row["exam3"]+$row["result_card"];
	  
	    $totalt+=$row["t_m_amt"];$totalc+=$row["c_m_amt"];$totalo+=$otherfee;
		
	  echo "<td>".$c."</td><td>".$row["rec_no"]."</td><td>".$row["adm_no"]."</td><td>".$rowst["name"]."</td><td>".$rowst["class"]."</td>
	        <td>".$row['t_m_amt']."(".$row['t_m_name'].")"."</td><td>".$row['c_m_amt']."(".$row['c_m_name'].")"."</td><td>".$otherfee."</td><td>".
			         ($otherfee+$row["t_m_amt"]+$row["c_m_amt"])."</td><td>".$row["teacher"]."</td><tr>";
	  $c+=1;
 }
   echo "<td></td><td></td><td></td><td><b>TOTAL</b></td><td></td><td><b>".$totalt."</td><td><b>".$totalc."</td><td><b>".$totalo."</td><td><b>".($totalc+$totalo+$totalt)."</td><tr>";
   echo "</table>";
	}
?>


<center>

 <u>Daily Fee Report 2020-21 </u>  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
 <?php echo "<b>Date : </b>".$date."<br><br>"; ?>
 <table border=1 width=100%>
 <th>N.</th><th>Rec.No.</th><th>Adm.No.</th><th>Name</th><th>Class</th><th>Tution Fee</th><th>Conveyance FEE</th><th>Other FEE</th><th>Total</th><th>Teacher</th><tr>
<?php 
$count=mysqli_num_rows($res21);
$c=1;
  $totalt=0;$totalc=0;$totalo=0;
 while($c<=$count)
 {    $row=mysqli_fetch_array($res21);
      $rowst=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$row[adm_no]'"));
     
      $otherfee=$row["form"]+$row["idcard"]+$row["tie_belt"]+$row["adm_fee"]+$row["exam1"]+$row["exam2"]+$row["exam3"]+$row["result_card"];
	  
	    $totalt+=$row["t_m_amt"];$totalc+=$row["c_m_amt"];$totalo+=$otherfee;
		
	  echo "<td>".$c."</td><td>".$row["rec_no"]."</td><td>".$row["adm_no"]."</td><td>".$rowst["name"]."</td><td>".$rowst["class2020"]."</td>
	        <td>".$row['t_m_amt']."(".$row['t_m_name'].")"."</td><td>".$row['c_m_amt']."(".$row['c_m_name'].")"."</td><td>".$otherfee."</td><td>".
			         ($otherfee+$row["t_m_amt"]+$row["c_m_amt"])."</td><td>".$row["teacher"]."</td><tr>";
	  $c+=1;
 }
   echo "<td></td><td></td><td></td><td><b>TOTAL</b></td><td></td><td><b>".$totalt."</td><td><b>".$totalc."</td><td><b>".$totalo."</td><td><b>".($totalc+$totalo+$totalt)."</td><tr>";
   echo "</table>";
	
?>


<center>

 <u>Daily Fee Report 2021-22 </u>  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
 <?php echo "<b>Date : </b>".$date."<br><br>"; ?>
 <table border=1 width=100%>
 <th>N.</th><th>Rec.No.</th><th>Adm.No.</th><th>Name</th><th>Class</th><th>Tution Fee</th><th>Conveyance FEE</th><th>Other FEE</th><th>Total</th><th>Teacher</th><tr>
<?php 
$count=mysqli_num_rows($res22);
$c=1;
  $totalt=0;$totalc=0;$totalo=0;
 while($c<=$count)
 {    $row=mysqli_fetch_array($res22);
      $rowst=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$row[adm_no]'"));
     
      $otherfee=$row["form"]+$row["idcard"]+$row["tie_belt"]+$row["adm_fee"]+$row["exam1"]+$row["exam2"]+$row["exam3"]+$row["result_card"];
	  
	    $totalt+=$row["t_m_amt"];$totalc+=$row["c_m_amt"];$totalo+=$otherfee;
		
	  echo "<td>".$c."</td><td>".$row["rec_no"]."</td><td>".$row["adm_no"]."</td><td>".$rowst["name"]."</td><td>".$rowst["class2021"]."</td>
	        <td>".$row['t_m_amt']."(".$row['t_m_name'].")"."</td><td>".$row['c_m_amt']."(".$row['c_m_name'].")"."</td><td>".$otherfee."</td><td>".
			         ($otherfee+$row["t_m_amt"]+$row["c_m_amt"])."</td><td>".$row["teacher"]."</td><tr>";
	  $c+=1;
 }
   echo "<td></td><td></td><td></td><td><b>TOTAL</b></td><td></td><td><b>".$totalt."</td><td><b>".$totalc."</td><td><b>".$totalo."</td><td><b>".($totalc+$totalo+$totalt)."</td><tr>";
   echo "</table>";
	
?>

<u>Daily Fee Report 2022-23 </u>  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
 <?php echo "<b>Date : </b>".$date."<br><br>"; ?>
 <table border=1 width=100%>
 <th>N.</th><th>Rec.No.</th><th>Adm.No.</th><th>Name</th><th>Class</th><th>Tution Fee</th><th>Conveyance FEE</th><th>Other FEE</th><th>Total</th><th>Teacher</th><tr>
<?php 
$count=mysqli_num_rows($res23);
$c=1;
  $totalt=0;$totalc=0;$totalo=0;
 while($c<=$count)
 {    $row=mysqli_fetch_array($res23);
      $rowst=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$row[adm_no]'"));
     
      $otherfee=$row["form"]+$row["idcard"]+$row["tie_belt"]+$row["adm_fee"]+$row["exam1"]+$row["exam2"]+$row["exam3"]+$row["result_card"];
	  
	    $totalt+=$row["t_m_amt"];$totalc+=$row["c_m_amt"];$totalo+=$otherfee;
		
	  echo "<td>".$c."</td><td>".$row["rec_no"]."</td><td>".$row["adm_no"]."</td><td>".$rowst["name"]."</td><td>".$rowst["class2022"]."</td>
	        <td>".$row['t_m_amt']."(".$row['t_m_name'].")"."</td><td>".$row['c_m_amt']."(".$row['c_m_name'].")"."</td><td>".$otherfee."</td><td>".
			         ($otherfee+$row["t_m_amt"]+$row["c_m_amt"])."</td><td>".$row["teacher"]."</td><tr>";
	  $c+=1;
 }
   echo "<td></td><td></td><td></td><td><b>TOTAL</b></td><td></td><td><b>".$totalt."</td><td><b>".$totalc."</td><td><b>".$totalo."</td><td><b>".($totalc+$totalo+$totalt)."</td><tr>";
   echo "</table>";
	
?>


<u>Daily Fee Report 2023-24 </u>  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
 <?php echo "<b>Date : </b>".$date."<br><br>"; ?>
 <table border=1 width=100%>
 <th>N.</th><th>Rec.No.</th><th>Adm.No.</th><th>Name</th><th>Class</th><th>Tution Fee</th><th>Conveyance FEE</th><th>Other FEE</th><th>Total</th><th>Teacher</th><tr>
<?php 
$count=mysqli_num_rows($res24);
$c=1;
  $totalt=0;$totalc=0;$totalo=0;
 while($c<=$count)
 {    $row=mysqli_fetch_array($res24);
      $rowst=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$row[adm_no]'"));
     
      $otherfee=$row["form"]+$row["idcard"]+$row["tie_belt"]+$row["adm_fee"]+$row["exam1"]+$row["exam2"]+$row["exam3"]+$row["result_card"];
	  
	    $totalt+=$row["t_m_amt"];$totalc+=$row["c_m_amt"];$totalo+=$otherfee;
		
	  echo "<td>".$c."</td><td>".$row["rec_no"]."</td><td>".$row["adm_no"]."</td><td>".$rowst["name"]."</td><td>".$rowst["class2023"]."</td>
	        <td>".$row['t_m_amt']."(".$row['t_m_name'].")"."</td><td>".$row['c_m_amt']."(".$row['c_m_name'].")"."</td><td>".$otherfee."</td><td>".
			         ($otherfee+$row["t_m_amt"]+$row["c_m_amt"])."</td><td>".$row["teacher"]."</td><tr>";
	  $c+=1;
 }
   echo "<td></td><td></td><td></td><td><b>TOTAL</b></td><td></td><td><b>".$totalt."</td><td><b>".$totalc."</td><td><b>".$totalo."</td><td><b>".($totalc+$totalo+$totalt)."</td><tr>";
   echo "</table>";
	
?>

<BR><BR><BR>
<u>Daily Fee Report 2024-25 </u>  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
 <?php echo "<b>Date : </b>".$date."<br><br>"; ?>
 <table border=1 width=100%>
 <th>N.</th><th>Rec.No.</th><th>Adm.No.</th><th>Name</th><th>Class</th><th>Tution Fee</th><th>Conveyance FEE</th><th>Other FEE</th><th>Total</th><th>Teacher</th><tr>
<?php 
$count=mysqli_num_rows($res25);
$c=1;
  $totalt=0;$totalc=0;$totalo=0;
 while($c<=$count)
 {    $row=mysqli_fetch_array($res25);
      $rowst=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$row[adm_no]'"));
     
      $otherfee=$row["form"]+$row["idcard"]+$row["tie_belt"]+$row["adm_fee"]+$row["exam1"]+$row["exam2"]+$row["exam3"]+$row["result_card"];
	  
	    $totalt+=$row["t_m_amt"];$totalc+=$row["c_m_amt"];$totalo+=$otherfee;
		
	  echo "<td>".$c."</td><td>".$row["rec_no"]."</td><td>".$row["adm_no"]."</td><td>".$rowst["name"]."</td><td>".$rowst["class2024"]."</td>
	        <td>".$row['t_m_amt']."(".$row['t_m_name'].")"."</td><td>".$row['c_m_amt']."(".$row['c_m_name'].")"."</td><td>".$otherfee."</td><td>".
			         ($otherfee+$row["t_m_amt"]+$row["c_m_amt"])."</td><td>".$row["teacher"]."</td><tr>";
	  $c+=1;
 }
   echo "<td></td><td></td><td></td><td><b>TOTAL</b></td><td></td><td><b>".$totalt."</td><td><b>".$totalc."</td><td><b>".$totalo."</td><td><b>".($totalc+$totalo+$totalt)."</td><tr>";
   echo "</table>";
	
?>

