<?php
  include "connection.php";
  
  session_start();
 
 
 if(!isset($_SESSION["teacher_user"]))
 {
   
   ?>

   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
    Access Denied.
   Please Login to Continue
   <?php
 }
 else
 {
   $teacher_name=$_SESSION["teacher_user"];
 
   $res=mysqli_query($link,"select * from teacher where name='$teacher_name'");
   $row=mysqli_fetch_array($res);
   if($row["acct_access"]=='0') {
    ?>

   <script type="text/javascript">
      window.location="examHome.php";
   </script>
    Access Denied.
   Please Login to Continue
   <?php
   }

 
 
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>GSS Gurukul Shikshan Sansthan</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
        
        
        <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-158846168-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-158846168-1');
</script>

  </head>
  <body>
    <div class="page">
      <!-- Main Navbar-->
      <header class="header">
        <nav class="navbar">
          
          <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              <!-- Navbar Header-->
              <div class="navbar-header">
                <!-- Navbar Brand --><a href="dashboardStaff.php" class="navbar-brand d-none d-sm-inline-block">
                  <div class="brand-text d-none d-lg-inline-block"><img src="logo3.gif" width=200px></div>
                  <div class="brand-text d-none d-sm-inline-block d-lg-none"><strong>GSS</strong></div></a>
                <!-- Toggle Button--><a id="toggle-btn" href="#" class="menu-btn active"><span></span><span></span><span></span></a>
              </div>
              <!-- Navbar Menu -->
              <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                <li>Gurukul Shikshan Sansthan&nbsp</li>
                <li>&nbspKhampar(Jaipur)</li>
                <!-- Logout    -->
                <li class="nav-item"><a href="logout.php" class="nav-link logout"> <span class="d-none d-sm-inline">Logout</span><i class="fa fa-sign-out"></i></a></li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
      <div class="page-content d-flex align-items-stretch"> 
        <!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4"><?php echo $teacher_name;?></h1>
              
              
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
            <li class="active"><a href="dashboardStaff.php"> <i class="icon-home"></i>Home </a></li>
            
                <li><a href="add_student.php"> <i class="icon-grid"></i>Add Student </a></li>
             

            <li><a href="fee_payment.php"> <i class="fa fa-bar-chart"></i>Pay Fee</a></li>
            
            <li><a href="class_list.php"> <i class="icon-padnote"></i>Class List </a></li>
            <li><a href="#exampledropdownDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Exam</a>
              <ul id="exampledropdownDropdown" class="collapse list-unstyled ">
                <!--<li><a href="marksEntryHY.php"> <i class="icon-padnote"></i>Add HalfYearly Marks </a></li>-->
                <li><a href="marksEntryTM.php"> <i class="icon-padnote"></i>Add ThirdMonthly Marks </a></li>
                <!--<li><a href="marksEntryY.php"> <i class="icon-padnote"></i>Add Yearly Marks </a></li>-->
                
                <li><a href="examViewMarkListTM.php"> <i class="icon-padnote"></i>View ThirdMonthly Marks </a></li>
                <!--<li><a href="examViewMarkListY.php"> <i class="icon-padnote"></i>View Yearly Marks </a></li>-->
                <li><a href="printResult.php"> <i class="icon-padnote"></i>PrintResult</a></li>
              </ul>
            </li>
            
            <li><a href="addTeacher.php"> <i class="icon-padnote"></i>Add Teacher </a></li>
            <li><a href="update.php"> <i class="icon-grid"></i>Update Conveyance/Class/Roll </a></li>
            <li><a href="countStudents.php"> <i class="fa fa-bar-chart"></i>Students Count</a></li>
            <li><a href="print_newadmission.php" target="_blank"> <i class="fa fa-bar-chart"></i>New Admissions List</a></li>
            <li><a href="#exampledropdownDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Print</a>
              <ul id="exampledropdownDropdown" class="collapse list-unstyled ">
                <li><a href="daily_report.php">Daily Report</a></li>
                <li><a href="monthly_primary_report.php">Monthly Primary Report</a></li>
                <li><a href="yearly_primary_report.php">Yearly Primary Report</a></li>
                <li><a href="find_adm.php">Admission Slip</a></li>
                <li><a href="find_rec.php">Reciept</a></li>
                <li><a target="_blank" href="reminder.php">Reminder</a></li>
                <li><a target="_blank" href="admit_card.php">Admit Card</a></li>
                <li><a target="_blank" href="ledger.php">Ledger</a></li>
                <li><a target="_blank" href="ledger2022.php">Ledger 2022</a></li>
                <li><a target="_blank" href="ledger2023.php">Ledger 2023</a></li>
                <li><a target="_blank" href="ledger2024.php">Ledger 2024</a></li>
                <li><a target="_blank" href="marklist.php">Mark List</a></li>
                <li><a target="_blank" href="print_conveyance.php">Conveyance List</a></li>
                <li><a target="_blank" href="paid_unpaid.php">Paid/Unpaid List</a></li>
                <li><a target="_blank" href="que_paper.php">Question Papers</a></li>
              </ul>
            </li>
            <!-----------
            <li><a href="login.html"> <i class="icon-interface-windows"></i>Login page </a></li>
          </ul><span class="heading">Extras</span>
          <ul class="list-unstyled">
            <li> <a href="#"> <i class="icon-flask"></i>Demo </a></li>
            <li> <a href="#"> <i class="icon-screen"></i>Demo </a></li>
            <li> <a href="#"> <i class="icon-mail"></i>Demo </a></li>
            <li> <a href="#"> <i class="icon-picture"></i>Demo </a></li>
          </ul>
          ----->
        </nav>
        <div class="content-inner">
        <?php
         }
         ?>  