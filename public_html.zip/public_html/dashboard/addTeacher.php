<?php
  include "header.php";
  if(!isset($_SESSION["teacher_user"]))
  {
    ?>
    <script type="text/javascript">
        window.location="StaffLogin.php";
    </script>
    <?php
   } else
   {
?>
    <!-- Page Header-->
    <header class="page-header">
        <div class="container-fluid">
            <h2 class="no-margin-bottom">Add Teacher</h2>
        </div>
    </header>

    

    <div class="container-fluid">
            <label for="teacherName">Teacher Name:</label>
            <input type="text" id="teacherName" name="teacherName" required>
            <br><br>
            
            <label for="mobileNumber">Mobile Number:</label>
            <input type="text" id="mobileNumber" name="mobileNumber" pattern="[0-9]{10}" required>
            <small>Enter a 10-digit mobile number.</small>
            <br><br>
        <button id="addButton">ADD </button>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript">
        
        $("#addButton").click(function() {
            teacherName = $("#teacherName").val();
            mobNumber = $("#mobileNumber").val();
            addTeacher(teacherName, mobNumber);
        });

        function addTeacher(teacherName, mobNumber) {
            $.ajax({
                    url: 'examAPI.php/addTeacher?teacherName=' + encodeURIComponent(teacherName) + '&mobNumber=' + mobNumber,
                    type: "GET",
                    dataType: "json",
                    success: function(data) {
                        alert("Added Successfully. Redirecting...");
                        window.location='dashboardStaff.php';
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching data:", error);
                        window.location='dashboardStaff.php';
                    }
                });
        }

    </script>
<?php
   }
?>
