<?php
    session_start();
	
   
    include "connection.php";
	if(!isset($_SESSION["teacher_user"]))
    {
    	echo "Access Denied Please Login";
    }
	else
	{
		$class=$_GET["class"];
		$res=mysqli_query($link,"select * from student where class2022 ='$class' ORDER BY `student`.`roll2022` ASC");
		$c=mysqli_num_rows($res);
		echo "&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp<b><u>Class : ".$class."</b></u><br><br>"; 
		?>
		
		<table border=1 >
		<th>N.</th><th>Adm.No.</th><th>Name </th><th>Father's Name</th><th>Mother's Name</th><th>contact</th><th>Address</th><th>Aadhaar</th><th>DOB</th><tr>
		
		
		<?php $k=1;
		while($c>0)
		{
		   $row=mysqli_fetch_array($res);
		   echo "<td>".$row['roll2022']."</td><td>".$row["adm_no"]."</td><td>".$row["name"]."</td><td>".$row["father_name"]."</td><td>".$row["mother_name"]."</td><td>".$row["contact1"]."</td><td>".$row["add1"]." ".$row["add2"]."</td><td>".$row["aadhaar"]."</td><td>".$row["dob"]."</td><tr>";
		   $k+=1;$c-=1;
		   
		}
	}
	?>
	  </table>