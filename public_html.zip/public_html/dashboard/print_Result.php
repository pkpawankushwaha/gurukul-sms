<html>
    <head>
        <style>
            .result-div{
                height: 26cm;
                width: 17cm;
                margin-bottom: 100px;
                margin-top: 20px;
                margin-left: 30px;
                border: 2px solid black;
                border-radius: 20px;
            }
            .result-div-bg{
                position: absolute;
                z-index: -1;
                height: 26cm;
                margin-top: 20px;
                margin-left: 30px;
                width: 17cm;
                opacity: 0.05;
            }
            .result-div-bg img {
                margin: 50% 0 0 25%;
            }
            .result-div table tbody {
                height: 10px;
                margin-bottom: 100px;
            }
            .td-left {
                border-right: 1px solid black;
                padding: 0px;
                text-align: left;
                /* border-collapse: collapse; */
            }

            .td-right {
                border-left: 1px solid black;
                text-align: center;
            }
            .result-header {
                height: 15%;
                width: 96%;
                padding-left: 2%;
                padding-right: 2%;
                padding-bottom: 5%;
                padding-top: 5%;
                border-bottom: 1px solid black;
            }
            .result-header-left {
                height: 100%;
                width: 20%;
                float: left;
            }
            .result-header-left img {
                height: 100%;
                width: 100%;
                float: left;
            }
            .result-header-right {
                height: 100%;
                width: 80%;
                float: right;
                text-align: center;
            }
            .result-exam-heading {
                height: 3%;
                width: 100%;
                font-size: 20px;
                text-align: center;
                border-bottom: 1px solid black;
                vertical-align: center;
            }
            .result-exam-heading h4 {
                margin: 0;
                padding: 0;
                height: 80%;
            }

            .result-student-details {
                height: 6%;
                width: 96%;
                padding: 2%;
                border-bottom: 1px black solid;
                font-size: 20px;
            }
            .result-student-details-left {
                height: 100%;
                text-align: left;
                float: left;
                width: 70%;
            }
            .result-student-details-right {
                height: 100%;
                text-align: left;
                float: right;
                width: 30%;
            }
            .result-signatures {
                height: 16%;
                padding: 2%;
                text-align: center;
                border-top: 1px solid black;
            }
            .result-signatures h2 {
                opacity: 0.5;
                margin: 0;
                padding: 0;
            }
            .result-signatures-div {
                margin-top: 5%;
                height: 15%;
            }
            .result-signatures-left {
                width: 33%;
                float: left;
                font-weight: bold;
            }
            .result-marklist {
                height: 55%;
                width: 100%;
                margin: 0;
            }
            .result-marklist-heading-table {
                height: 10%;
                width: 100%;
                margin: 0;
                border-collapse: collapse;
            }
            .result-marklist-heading {
                height: 20px;
                width: 100%;
                font-size: 20px;
                border: 1px black solid;
                padding: 0;
            }
            .result-marklist-subjects {
                height: 30px;
                width: 80%;
                
                border-bottom: 1px black solid;
                padding: 0;
            }
            .result-marklist-marks {
                height: 30px;
                width: 20%;
                border-left: 1px black solid;
                border-bottom: 1px black solid;
                padding: 0;
            }
            .result-marklist-values {
                height: 30px;
                width: 100%;
                border: 1px black solid;
                padding: 0;
                margin: 0;
                font-size: 20px;
            }
            .result-marklist-heading-table tr td {
                height : 30px;
                border-left: 1px black solid;
                padding: 2px;
            }
            .result-marklist-heading-table tr td:nth-child(1) {
                padding-left: 20px;
                text-align: left;
                font-size: 20px;
            }
            .result-marklist-heading-table tr td:nth-child(2) {
                text-align: center;
            }
            .result-marklist-heading-table tr td:nth-child(3) {
                text-align: center;
            }
            .result-marklist-heading-table tr td:nth-child(4) {
                text-align: center;
            }
            .result-marklist-footer th {
                margin-top: 10px;
                padding-top: 10px;
                padding-bottom: 10px;
                border: 1px solid black;
                font-size: 20px;
            }
            .empty-row {
                height: 120px;
            }
        </style>
    </head>
    <body>
<?php
            include "connection.php";
            $class=$_GET["class"];
            $result = fetchClassResult($link, $class);

            $resultY = fetchYResult($link, $class);

            
            // $rankMarks = array();

            // //Iterate through $result and calculate total marks
            // foreach ($result as $student) {
            //     $adm_no = $student->adm_no;
            //     $rankMarks[$adm_no] = $student->total;
            // }
            
            // // Iterate through $resultY and add total marks
            // foreach ($resultY as $student) {
            //     $adm_no = $student->adm_no;
            //     if (isset($rankMarks[$adm_no])) {
            //         $rankMarks[$adm_no] += $student->total;
            //     } else {
            //         $rankMarks[$adm_no] = $student->total;
            //     }
            // }
            // uasort($rankMarks, function($a, $b) {
            //     return $b - $a; // Sort in descending order
            // });
            
            
            // $ranks = array(); // You can replace this with a map

            // $rank = 1;
            // $prev_total = null;
            
            // foreach ($rankMarks as $adm_no => $total) {
            //     if ($total !== $prev_total) {
            //         $rank = count($ranks) + 1;
            //     }
            //     $ranks[$adm_no] = $rank; // Store rank along with admission number in the map
                
            //     $prev_total = $total;
            // }
                
            
            $i=0;
            while($i<count($result)){
                $rankText = '';
                $rr=$ranks[$result[$i]->adm_no];
                // if(isAnyAbsent($result[$i]->marks, $resultY[$i]->marks))
                // {
                //     $rankText = "Promoted";
                // } else {
                //     $rankText = 'Passed';
                // }
                // switch ($rr) {
                //     case 1:
                //         $rankText = $rankText.' | First Rank';
                //         break;
                //     case 2:
                //         $rankText = $rankText.' | Second Rank';
                //         break;
                //     case 3:
                //         $rankText  = $rankText.' | Third Rank';
                //         break;
                //     default:
                //         $rankText = 'Passed';
                //         break;
                // }
                printResult($result[$i], $result[$i], $rankText);$i+=1;
            }
            
            
            class Marks {
                public $marks;
                public $mm;
                public $subject;
            
                public function __construct($marks, $mm, $subject) {
                    $this->marks = $marks;
                    $this->mm = $mm;
                    $this->subject = $subject;
                }
            }
            
            
            class StudentResult {
                public $adm_no;
                public $class;
                public $rollNo;
                public $name;
                public $fname;
                public $mname;
                public $marks;
                public $total;
                public $max;
                public $percentage;
            
                public function __construct($adm_no, $class, $rollNo, $name, $fname, $mname, 
                    $marks, 
                    $total, 
                    $max, 
                    $percentage) {
                    $this->adm_no = $adm_no;
                    $this->name = $name;
                    $this->fname = $fname;
                    $this->mname = $mname;
                    $this->marks = $marks;
                    $this->class = $class;
                    $this->rollNo = $rollNo;
                    $this->total = $total;
                    $this->max = $max;
                    $this->percentage = $percentage;
                }
            }
            
            class Subject {
                public $code;
                public $name;
            
                public function __construct($code, $name) {
                    $this->name = $name;
                    $this->code = $code;
                }
            }
            
            function isAnyAbsent($marks, $marksY) {
                $i=0;
                while($i<count($marks)) {
                    if($marks[$i]->marks === 'A')return true;$i+=1;
                }
                $i=0;
                while($i<count($marksY)) {
                    if($marksY[$i]->marks === 'A')return true;$i+=1;
                }
                return false;
            }

            function printResult($studentResult, $studentResultY, $rank) {
                
                ?>
                <div class="result-div-bg">
                    <img src="logo.png">
                </div>
                <div class="result-div">
                    <div class="result-header">
                        <div class="result-header-left">
                            <img src="logo.png">
                        </div>
                        <div class="result-header-right">
                            <h1>Gurukul Shikshan Sansthan</h1>
                            <h4>Khampar(Jaipur), Deoria (U.P.)</h4>

                            <h5>Contact : 9628123917, 9919821260 Email : gurukulkhampar@gmail.com</h5>
                        </div>
                    </div>
                    <div class="result-exam-heading">
                        <h4>Third Monthly Report - 2024-25<h4>
                    </div>

                    <div class="result-student-details">
                        <div class="result-student-details-left">
                            <b>Name  : </b> <?php echo $studentResult -> name; ?> <br>
                            <b>Father's Name : </b> <?php echo $studentResult -> fname; ?><br> 
                            <b>Mother's Name : </b> <?php echo $studentResult -> mname; ?><br> 
                        </div>
                        <div class="result-student-details-right">
                            <b>Adm No.  : </b> <?php echo $studentResult -> adm_no; ?> <br>
                            <b>Class : </b> <?php echo $studentResult -> class; ?><br> 
                            <b>Roll No. : </b> <?php echo $studentResult -> rollNo; ?><br> 
                        </div>
                    </div>

                    <div class="result-marklist">
                        <table class="result-marklist-heading-table">
                            <tr class="result-marklist-heading">
                                <th class="result-marklist-subjects">SUBJECTS</td>
                                <!--<th class="result-marklist-marks">Half Yearly</td>-->

                                <!--<th class="result-marklist-marks">Yearly</td>-->

                                <th class="result-marklist-marks">Third Monthly</td>
                            </tr>
                            <?php
                                $i=0;
                                $marks = $studentResult->marks;
                                $marksY = $studentResultY->marks;
                                while($i<count($marks)) {
                                    $aggregateMark = 0;
                                    if($marksY[$i]->marks != 'A')$aggregateMark+=$marksY[$i]->marks;
                                    if($marks[$i]->marks != 'A')$aggregateMark+=$marks[$i]->marks;
                                    
                                    ?>
                                    <tr>
                                        <td><?php echo $marks[$i]->subject; ?></td>
                                        <td ><?php echo $marks[$i]->marks."/".$marks[$i]->mm;  ?></td>
                                        <!--<td ><?php echo $marksY[$i]->marks."/".$marksY[$i]->mm;  ?></td>-->
                                        <!--<td ><?php echo ($aggregateMark)."/".($marks[$i]->mm+$marksY[$i]->mm);  ?></td>-->
                                    </tr>
                                    <?php
                                    $i+=1;
                                }
                            ?>
                            
                            <tr class="empty-row">
                                <td > </td>
                                <td > </td>
                            </tr>
                            <tr class="result-marklist-footer">
                                <th>Total</td>
                                <th><?php echo $studentResult -> total."/".$studentResult -> max; ?></td>
                                    <!--<th><?php echo $studentResultY -> total."/".$studentResult -> max; ?></td>-->
                                        <!--<th><?php echo ($studentResult -> total+$studentResultY -> total)."/".($studentResult -> max + $studentResultY -> max); ?></td>-->
                            </tr>
                            <tr class="result-marklist-footer">
                                <th>Percentage</td>
                                <th><?php echo $studentResult -> percentage; ?></td>

                                <!--<th><?php echo $studentResultY -> percentage; ?></td>-->

                                <!--<th><?php echo round(($studentResult -> total+$studentResultY -> total)/($studentResult -> max + $studentResultY -> max)*100,2) ?></td>-->
                            </tr>
                            <tr class="result-marklist-footer">
                                <th colspan="4"><?php echo $rank?></td>
                            </tr>
                        </table>
                        
                    </div>

                    <div class="result-signatures">
                        <h2> SIGNATURES </h2>
                        <div class="result-signatures-div">
                            <div class="result-signatures-left">
                                CLASS TEACHER
                            </div>
                            <div class="result-signatures-left">
                                PARENT
                            </div>
                            <div class="result-signatures-left">
                                PRINCIPAL
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            }

            function fetchHYResult($link, $class) {
                $subjects = fetchSubjects($link, $class);
                $subCode = "sub1";
                $mm=50;
                if($class=='IX A')
                    $mm=50;
                $exam = '`exam2024tm`';
                $exam_sub = "";
                $studentList = array();
                for($i=0;$i<count($subjects);$i++) {
                    $exam_sub = $exam_sub."".$exam.".`".$subjects[$i]->code."`, ";
                }
                $query = "select `student`.`adm_no`, `student`.`class2024`, `student`.`roll2024`,  $exam_sub `student`.`name`, `student`.`father_name`, `student`.`mother_name` FROM `student` INNER JOIN $exam WHERE `student`.`adm_no` = $exam.`adm_no` AND `student`.`class2024`='$class' ORDER BY `student`.`roll2024` ASC";
                $resStudents = mysqli_query($link, $query);
                while ($row = mysqli_fetch_array($resStudents)) {
                    $marks = array();
                    $total = 0;
                    for($i=0;$i<count($subjects);$i++) {
                       $score = $row[$subjects[$i]->code];
                       if($score>$mm || $score<0) $score = 'A';
                       if($score!=='A') $total += $score;
                       $marks[] = new Marks($score, $mm, $subjects[$i]->name);
                    }
                    $max=$mm*count($marks);
                    $percentage = round(($total/$max)*100, 2);
                    $studentsList[] = new StudentResult($row['adm_no'], $row["class2024"], $row["roll2024"], 
                        $row['name'], $row['father_name'], $row['mother_name'], 
                        $marks,
                        $total, 
                        $max,
                        $percentage);
                }
                return $studentsList;
            }

            function fetchYResult($link, $class) {
                $subjects = fetchSubjects($link, $class);
                $subCode = "sub1";
                $mm=50;
                if($class=='IX A')
                    $mm=100;
                $exam = '`exam2023y`';
                $exam_sub = "";
                $studentList = array();
                for($i=0;$i<count($subjects);$i++) {
                    $exam_sub = $exam_sub."".$exam.".`".$subjects[$i]->code."`, ";
                }
                $query = "select `student`.`adm_no`, `student`.`class2023`, `student`.`roll2023`,  $exam_sub `student`.`name`, `student`.`father_name`, `student`.`mother_name` FROM `student` INNER JOIN $exam WHERE `student`.`adm_no` = $exam.`adm_no` AND `student`.`class2023`='$class' ORDER BY `student`.`roll2023` ASC";
                $resStudents = mysqli_query($link, $query);
                while ($row = mysqli_fetch_array($resStudents)) {
                    $marks = array();
                    $total = 0;
                    for($i=0;$i<count($subjects);$i++) {
                       $score = $row[$subjects[$i]->code];
                       if($score>$mm || $score<0) $score = 'A';
                       if($score!=='A') $total += $score;
                       $marks[] = new Marks($score, $mm, $subjects[$i]->name);
                    }
                    $max=$mm*count($marks);
                    $percentage = round(($total/$max)*100, 2);
                    $studentsList[] = new StudentResult($row['adm_no'], $row["class2023"], $row["roll2023"], 
                        $row['name'], $row['father_name'], $row['mother_name'], 
                        $marks,
                        $total, 
                        $max,
                        $percentage);
                }
                return $studentsList;
            }

            function fetchClassResult($link, $class) {
                $subjects = fetchSubjects($link, $class);
                return fetchHYResult($link, $class);
            }

            function fetchSubjects($link, $class) {
                $query = "select subjectCode, subjectName from classsubject where `class`='$class'";
                $resSubjects = mysqli_query($link, $query);
                $subList = array();
            
                while ($row = mysqli_fetch_array($resSubjects)) {
                    $subList[] = new Subject($row['subjectCode'], $row['subjectName']);
                }
                return $subList;
            }


    
?>
</body>
</html>