<?php
  include "header.php";
  include "connection.php";
  if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">AdmitCard</h2>
            </div>
          </header>


   		  <div class="container bg-white">
    	  		<form name="form1" class="form" action="generate_admit.php" method="post">
    			<div class="form-group row">
     				 <div class="col-md-4"></div>
     					 <div class="col-md-2">Select Class</div>
      						  <div class="col-md-2">
        					  <select name="class" class="form-control form-control-sm mb-3">
                    			<option>All</option>
        						<?php
        
							           $cl=mysqli_query($link,"select * from class");
							           $count=0;$count=mysqli_num_rows($cl);
							           while($count>0)
							             {   
							              $row=mysqli_fetch_array($cl);
							               echo "<option>".$row["class"]."</option>";
							              $count-=1;
							            
							              }
        
							        ?>
							   </select>
							</div>
				</div>
				

   		 		 <div>
   		 		 	<center><input type="submit" name="submit" class="btn btn-primary" value="Generate AdmitCard">
   		 		 	</center>
   		 		 </div>
<?php
}
?>

<?php
 include "footer.php";
 ?>
