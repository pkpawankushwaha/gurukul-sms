<?php
  include "header.php";
   if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
      $mon=$_GET['mon'];
      $admin=0;
      $admin2=0;
      for ($x = 1; $x <=31; $x++) {
                
                $date=$x."/".$mon;
                if($x<10)$date="0".$date;
               
                $res23=mysqli_query($link,"select * from reciept2023 where date='$date'");
                $res22=mysqli_query($link,"select * from reciept2022 where date='$date'");
                $res24=mysqli_query($link,"select * from reciept2024 where date='$date'");
                $res25=mysqli_query($link,"select * from reciept2025 where date='$date'");
                
                $c22=mysqli_num_rows($res22);
                $c23=mysqli_num_rows($res23);
                $c24=mysqli_num_rows($res24);
                $c25=mysqli_num_rows($res25);
                $ad=0;$ad2=0;
                for($y = 0; $y <$c22; $y++){
                    $r=mysqli_fetch_array($res22);
                    if($r["teacher"]==="admin"){
                        $ad+=$r["total"];
                        
                    }
                    else{
                        $ad2+=$r["total"];
                        
                    }
                }
                for($y = 0; $y <$c23; $y++){
                    $r=mysqli_fetch_array($res23);
                    if($r["teacher"]==="admin"){
                        $ad+=$r["total"];
                        
                    }
                    else{
                        $ad2+=$r["total"];
                        
                    }
                }
                for($y = 0; $y <$c24; $y++){
                    $r=mysqli_fetch_array($res24);
                    if($r["teacher"]==="admin"){
                        $ad+=$r["total"];
                        
                    }
                    else{
                        $ad2+=$r["total"];
                        
                    }
                }
                for($y = 0; $y <$c25; $y++){
                    $r=mysqli_fetch_array($res25);
                    if($r["teacher"]==="admin"){
                        $ad+=$r["total"];
                        
                    }
                    else{
                        $ad2+=$r["total"];
                        
                    }
                }
                echo $date."----".$ad.".....$ad2"."<br>";
                
                $admin+=$ad;
                $admin2+=$ad2;
        }
      
       echo $admin.".....$admin2";
  }
  
?>