<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>GSS Gurukul Shikshan Sansthan</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <div class="page">
    	<?php
    // session_start();
	
   
    include "connection.php";
	if(true)
	{

		$class=$_GET["class"];
		?>
		<div class="row" style="width: 110%">
			<div class="col-md-4">
				<div style="width: 80%;text-align: center;">
		<?php
		$res=mysqli_query($link,"select * from student where class2024='$class' ORDER BY `student`.`roll2024` ASC");
		$c=mysqli_num_rows($res);
		echo "&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp<b><u>Class : ".$class."</b></u><br>"; 
		?>
		Exam : ________  M.M. : ___<br>
		Sub : _________________<br>
		<table border=1>
		<th>N.</th><th>Name </th><th>Marks</th><tr>
		
		
		<?php $k=1;
		while($c>0)
		{
		   $row=mysqli_fetch_array($res);
		   echo "<td>".$k."</td><td>".$row["name"]."</td><td></td><tr>";
		   $k+=1;$c-=1;
		   
		}
	
	?>
	  </table>
	  <br><br>Signature _____________<br>
	</div>
		</div>
		
		<div class="col-md-4">
			<div style="width: 80%;text-align: center;">
		<?php
		$res=mysqli_query($link,"select * from student where class2024='$class' ORDER BY `student`.`roll2024` ASC");
		$c=mysqli_num_rows($res);
		echo "&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp<b><u>Class : ".$class."</b></u><br>"; 
		?>
		Exam : ________  M.M. : ___<br>
		Sub : _________________<br>
		<table border=1 >
		<th>N.</th><th>Name </th><th>Marks</th><tr>
		
		
		<?php $k=1;
		while($c>0)
		{
		   $row=mysqli_fetch_array($res);
		   echo "<td>".$k."</td><td>".$row["name"]."</td><td></td><tr>";
		   $k+=1;$c-=1;
		   
		}
	
	?>
	  </table>
	  <br><br>Signature _____________<br>
		</div></div>
		<div class="col-md-4">
			<div style="width: 80%;text-align: center;">
		<?php
		$res=mysqli_query($link,"select * from student where class2024='$class' ORDER BY `student`.`roll2024` ASC");
		$c=mysqli_num_rows($res);
		echo "&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp<b><u>Class : ".$class."</b></u><br>"; 
		?>
		Exam : ________  M.M. : ___<br>
		Sub : _________________<br>
		<table border=1 >
		<th>N.</th><th>Name </th><th>Marks</th><tr>
		
		
		<?php $k=1;
		while($c>0)
		{
		   $row=mysqli_fetch_array($res);
		   echo "<td>".$k."</td><td>".$row["name"]."</td><td></td><tr>";
		   $k+=1;$c-=1;
		   
		}
	}
	?>
	  </table>
	  	<br><br>Signature _____________<br>
		</div></div>

	</div>