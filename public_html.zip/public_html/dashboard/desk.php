<?php
    session_start();
	
   
    include "connection.php";
	if(!isset($_SESSION["teacher_user"]))
    {
    	echo "Access Denied Please Login";
    }
	else
	{
	    ?>
		<table border=0 width=100%>
		<?php
	   // $class = $_GET["class"];
		
		$res=mysqli_query($link,"select * from student where class2021='X A' ORDER BY `student`.`roll2021` ASC");
		
		$c= mysqli_num_rows($res);
		
		for($i=0;$i<$c;$i++){
		    if($i%3==0)echo "<tr>";
		    echo "<td>";
		    $r=mysqli_fetch_array($res);
		    echo $r['name']."<br>";
		    echo "Roll No.  : ".$r['roll2021']."<br>";
		    echo "Class : ".$r['class2021']."<br><br><br>";
		    echo "</td>";
		    if($i%3==2)echo "</tr>";
		    
		}
		
		
			$res=mysqli_query($link,"select * from student where class2021='IX A' ORDER BY `student`.`roll2021` ASC");
		
		$c= mysqli_num_rows($res);
		
		for($i=0;$i<$c;$i++){
		    if($i%3==0)echo "<tr>";
		    echo "<td>";
		    $r=mysqli_fetch_array($res);
		    echo $r['name']."<br>";
		    echo "Roll No.  : ".$r['roll2021']."<br>";
		    echo "Class : ".$r['class2021']."<br><br><br>";
		    echo "</td>";
		    if($i%3==2)echo "</tr>";
		    
		}
		
		
			$res=mysqli_query($link,"select * from student where class2021='VIII A' ORDER BY `student`.`roll2021` ASC");
		
		$c= mysqli_num_rows($res);
		
		for($i=0;$i<$c;$i++){
		    if($i%3==0)echo "<tr>";
		    echo "<td>";
		    $r=mysqli_fetch_array($res);
		    echo $r['name']."<br>";
		    echo "Roll No.  : ".$r['roll2021']."<br>";
		    echo "Class : ".$r['class2021']."<br><br><br>";
		    echo "</td>";
		    if($i%3==2)echo "</tr>";
		    
		}
		
		
			$res=mysqli_query($link,"select * from student where class2021='VII A' ORDER BY `student`.`roll2021` ASC");
		
		$c= mysqli_num_rows($res);
		
		for($i=0;$i<$c;$i++){
		    if($i%3==0)echo "<tr>";
		    echo "<td>";
		    $r=mysqli_fetch_array($res);
		    echo $r['name']."<br>";
		    echo "Roll No.  : ".$r['roll2021']."<br>";
		    echo "Class : ".$r['class2021']."<br><br><br>";
		    echo "</td>";
		    if($i%3==2)echo "</tr>";
		    
		}
		
		
			$res=mysqli_query($link,"select * from student where class2021='VI A' ORDER BY `student`.`roll2021` ASC");
		
		$c= mysqli_num_rows($res);
		
		for($i=0;$i<$c;$i++){
		    if($i%3==0)echo "<tr>";
		    echo "<td>";
		    $r=mysqli_fetch_array($res);
		    echo $r['name']."<br>";
		    echo "Roll No.  : ".$r['roll2021']."<br>";
		    echo "Class : ".$r['class2021']."<br><br><br>";
		    echo "</td>";
		    if($i%3==2)echo "</tr>";
		    
		}
		
		
			$res=mysqli_query($link,"select * from student where class2021='V A' ORDER BY `student`.`roll2021` ASC");
		
		$c= mysqli_num_rows($res);
		
		for($i=0;$i<$c;$i++){
		    if($i%3==0)echo "<tr>";
		    echo "<td>";
		    $r=mysqli_fetch_array($res);
		    echo $r['name']."<br>";
		    echo "Roll No.  : ".$r['roll2021']."<br>";
		    echo "Class : ".$r['class2021']."<br><br><br>";
		    echo "</td>";
		    if($i%3==2)echo "</tr>";
		    
		}
		
		
		
			$res=mysqli_query($link,"select * from student where class2021='IV A' ORDER BY `student`.`roll2021` ASC");
		
		$c= mysqli_num_rows($res);
		
		for($i=0;$i<$c;$i++){
		    if($i%3==0)echo "<tr>";
		    echo "<td>";
		    $r=mysqli_fetch_array($res);
		    echo $r['name']."<br>";
		    echo "Roll No.  : ".$r['roll2021']."<br>";
		    echo "Class : ".$r['class2021']."<br><br><br>";
		    echo "</td>";
		    if($i%3==2)echo "</tr>";
		    
		}
		
		
		
			$res=mysqli_query($link,"select * from student where class2021='III A' ORDER BY `student`.`roll2021` ASC");
		
		$c= mysqli_num_rows($res);
		
		for($i=0;$i<$c;$i++){
		    if($i%3==0)echo "<tr>";
		    echo "<td>";
		    $r=mysqli_fetch_array($res);
		    echo $r['name']."<br>";
		    echo "Roll No.  : ".$r['roll2021']."<br>";
		    echo "Class : ".$r['class2021']."<br><br><br>";
		    echo "</td>";
		    if($i%3==2)echo "</tr>";
		    
		}
		
		
		
			$res=mysqli_query($link,"select * from student where class2021='II A' ORDER BY `student`.`roll2021` ASC");
		
		$c= mysqli_num_rows($res);
		
		for($i=0;$i<$c;$i++){
		    if($i%3==0)echo "<tr>";
		    echo "<td>";
		    $r=mysqli_fetch_array($res);
		    echo $r['name']."<br>";
		    echo "Roll No.  : ".$r['roll2021']."<br>";
		    echo "Class : ".$r['class2021']."<br><br><br>";
		    echo "</td>";
		    if($i%3==2)echo "</tr>";
		    
		}
		
		
		
			$res=mysqli_query($link,"select * from student where class2021='I A' ORDER BY `student`.`roll2021` ASC");
		
		$c= mysqli_num_rows($res);
		
		for($i=0;$i<$c;$i++){
		    if($i%3==0)echo "<tr>";
		    echo "<td>";
		    $r=mysqli_fetch_array($res);
		    echo $r['name']."<br>";
		    echo "Roll No.  : ".$r['roll2021']."<br>";
		    echo "Class : ".$r['class2021']."<br><br><br>";
		    echo "</td>";
		    if($i%3==2)echo "</tr>";
		    
		}
		
		
		
		
			$res=mysqli_query($link,"select * from student where class2021='UKG A' ORDER BY `student`.`roll2021` ASC");
		
		$c= mysqli_num_rows($res);
		
		for($i=0;$i<$c;$i++){
		    if($i%3==0)echo "<tr>";
		    echo "<td>";
		    $r=mysqli_fetch_array($res);
		    echo $r['name']."<br>";
		    echo "Roll No.  : ".$r['roll2021']."<br>";
		    echo "Class : ".$r['class2021']."<br><br><br>";
		    echo "</td>";
		    if($i%3==2)echo "</tr>";
		    
		}
		
		
		
			$res=mysqli_query($link,"select * from student where class2021='LKG A' ORDER BY `student`.`roll2021` ASC");
		
		$c= mysqli_num_rows($res);
		
		for($i=0;$i<$c;$i++){
		    if($i%3==0)echo "<tr>";
		    echo "<td>";
		    $r=mysqli_fetch_array($res);
		    echo $r['name']."<br>";
		    echo "Roll No.  : ".$r['roll2021']."<br>";
		    echo "Class : ".$r['class2021']."<br><br><br>";
		    echo "</td>";
		    if($i%3==2)echo "</tr>";
		    
		}
	}
?>
</table>