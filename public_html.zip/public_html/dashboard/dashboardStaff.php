<?php
  include "header.php";
   if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Dashboard</h2>
            </div>
          </header>
          <br>
          
         
          
    <div class="container">
              <br>
              
               
              
               
                <a href="LKG_A.pdf" target="_blank">  LKG A</a>
                <a href="UKG_A.pdf" target="_blank">  UKG A</a>
                <a href="UKG_B.pdf" target="_blank">  UKG B</a>
                <a href="I_A.pdf" target="_blank">  I A</a>
                <a href="I_B.pdf" target="_blank">  I B</a>
                <a href="II_A.pdf" target="_blank">  II A</a>
                <a href="III_A.pdf" target="_blank">  III A</a>
                <a href="IV_A.pdf" target="_blank">  IV A</a>
                <a href="V_A.pdf" target="_blank">  V A</a>
                <a href="VI_A.pdf" target="_blank">  VI A</a>
                <a href="VII_A.pdf" target="_blank">  VII A</a>
                <a href="VIII_A.pdf" target="_blank">  VIII A</a>
                <a href="IX_A.pdf" target="_blank">  IX A</a>
                <a href="X_A.pdf" target="_blank">  X A</a><br>
                
                <a href="GSS_TT_HY_2024-25.pdf" target="_blank">  TimeTable_HY_2024-25</a>
                
                <a href="GSS_hindi.pdf" target="_blank">  Hindi_HY_2024-25</a>
                <a href="GSS_English.pdf" target="_blank">  English_HY_2024-25</a>
                <a href="GSS_Maths1-5.pdf" target="_blank">  Maths 1-5</a>
                
                
              
              
              
              
              <div class="row bg-white has-shadow">
                 <div class="col-xl-3 col-sm-4">
                    <a href="../index.php">
                      <center><img src="./img/home.png" height=150px style="border-radius:50%"><br>School Home Page</center>
                    </a>
                 </div>
                 <div class="col-xl-3 col-sm-4">
                    <a href="dashboardStaff.php">
                      <center><img src="./img/home.png" height=150px style="border-radius:50%"><br>Dashboard</center>
                    </a>
                 </div>
                 <div class="col-xl-3 col-sm-4">
                    <a href="printResult.php">
                      <center><img src="./img/home.png" height=150px style="border-radius:50%"><br>Print Result</center>
                    </a>
                 </div>
                 <div class="col-xl-3 col-sm-4">
                    <a href="add_student.php">
                      <center><img src="./img/addst.jpg" height=150px style="border-radius:50%"><br>Add Student</center>
                    </a>
                 </div>
                 <div class="col-xl-3 col-sm-4">
                 <a href="fee_payment.php">
                      <center><img src="./img/pay.jpg" height=150px style="border-radius:50%;width: 120px"><br>Pay Fee</center>
                    </a></div>
                  <div class="col-xl-3 col-sm-4">
                    <a href="marksEntry.php">
                      <center><img src="./img/addst.jpg" height=150px style="border-radius:50%"><br>Add Marks</center>
                    </a>
                 </div>
                 <div class="col-xl-3 col-sm-4">

                  <a href="logout.php">
                      <center><img src="./img/logout.jpg" height=150px style="border-radius:50%"><br>Logout</center>
                    </a>
                 </div>
                 
              </div>
    </div>






<?php
}
?>


<?php
  include "footer.php";
?>
          
          