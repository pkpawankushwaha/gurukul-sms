<?php
    session_start();
	
   
    include "connection.php";
	if(!isset($_SESSION["teacher_user"]))
    {
    	echo "Access Denied\nPlease Login";
    }
	else
	{
	  $adm=$_GET["adm"];
	  
	  $adm_st=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$adm'"));

	  $st_tut=mysqli_fetch_array(mysqli_query($link,"select * from tution2025 where adm_no='$adm'"));
	  
	  
     echo "---------------------------Student Copy---------------------------------------------------------Office Copy----------------------------<br>";	
?>
    <html>
	<body>
	
	
	<table border=3 height=450px width=780px>
	     <tr>
		 
	
		  <td width=49%>
		     
			 
			 
			 
			     <div style="height:160px">
				    <font size=5px><center><b>Gurukul Shikshan Sansthan</b> </center></font>
					<font size=3px><center>Khampar(Jaipur) Deoria (U.P.) </center><hr>
					<center><b><u>Admission Slip</b></u></center></font><br>
					<b>Adm.No.: </b><?php echo $adm_st["adm_no"]; ?> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
					<b>Adm Date.: </b><?php echo $adm_st["doa"]; ?><br>
					<b>StudentType : </b><?php echo $adm_st["sttype"]; ?> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
					<b>Class: </b><?php echo $adm_st["class2024"]; ?> -
				 	<?php echo $adm_st["roll2024"]; ?><br> 
					
					--------------------------------------------------------------------
				 </div>
                
				
				
				 <div style="height:240px;width:100%;">		
			         
					      <div style="float:left;height:190px;width:35%;">
					          <b>Name  </b><br>
							  <b>Father's Name </b><br>
							  <b>Mother's Name </b><br>
							  <b>Address</b><br><br>
							  <b>Contact</b><br>
							  <b>Aadhar </b><br>
							  <b>Date of Birth</b><br>
							  <b>Nationality </b><br>
							  <b>Religion/Caste </b><br>
							  <b>Tuition FEE </b><br>
							  <b>Conveyance FEE </b><br>
					      </div>
					 
					      <div style="float:right;height:190px;width:65%;">
							 <?php echo $adm_st["name"]; ?><br>
							 <?php echo $adm_st["father_name"]; ?><br>
							 <?php echo $adm_st["mother_name"]; ?><br>
							 <?php echo $adm_st["add1"]; ?><br>
							 <?php echo $adm_st["add2"]; ?><br>
							 <?php echo $adm_st["contact1"]." , ".$adm_st["contact2"]; ?><br>
							 
							 <?php echo $adm_st["aadhaar"]; ?><br>
							 <?php echo $adm_st["dob"]; ?><br>
							 <?php echo $adm_st["nationality"]; ?><br>
							 <?php echo $adm_st["religion"]."/".$adm_st["caste"]; ?><br>
							 <?php echo $st_tut["fee"]; ?><br>
							 <?php echo $adm_st["conveyance2025"]; 
							     if($adm_st["conveyance2025"]=="YES")
								 {
									 $st_con=mysqli_fetch_array(mysqli_query($link,"select * from conveyance2025 where adm_no='$adm'"));
										echo "/".$st_con["fee"];
								 }
							 ?><br>
							 
					      </div>
					  
					 </div>
				 
					 
					 

				  
				  
				  
				  <div style="height:50px">
				         --------------------------------------------------------------------
						 <br><center>Thanks</center>
				   </div>
		    
			
			
			
			
			
			</td>
			
			
	
		  <td width=1%><center><font color=red>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br></center></td>
		















		<td width=49%>
		            		 
							 
							 
							 
							 			 
			 
			     <div style="height:160px">
				    <font size=5px><center><b>Gurukul Shikshan Sansthan</b> </center></font>
					<font size=3px><center>Khampar(Jaipur) Deoria (U.P.) </center><hr>
					<center><b><u>Admission Slip</b></u></center></font><br>
					<b>Adm.No.: </b><?php echo $adm_st["adm_no"]; ?> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
					<b>Adm Date.: </b><?php echo $adm_st["doa"]; ?><br>
					<b>StudentType : </b><?php echo $adm_st["sttype"]; ?> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
					<b>Class: </b><?php echo $adm_st["class2024"]; ?> - 
				 	<?php echo $adm_st["roll2024"]; ?><br> 
					
					--------------------------------------------------------------------
				 </div>
                
				
				
				 <div style="height:240px;width:100%;">		
			         
					      <div style="float:left;height:190px;width:35%;">
					          <b>Name  </b><br>
							  <b>Father's Name </b><br>
							  <b>Mother's Name </b><br>
							  <b>Address</b><br><br>
							  <b>Contact</b><br>
							  <b>Aadhar </b><br>
							  <b>Date of Birth</b><br>
							  <b>Nationality </b><br>
							  <b>Religion/Caste </b><br>
							  <b>Tuition FEE </b><br>
							  <b>Conveyance FEE </b><br>
					      </div>
					 
					      <div style="float:right;height:190px;width:65%;">
							 <?php echo $adm_st["name"]; ?><br>
							 <?php echo $adm_st["father_name"]; ?><br>
							 <?php echo $adm_st["mother_name"]; ?><br>
							 <?php echo $adm_st["add1"]; ?><br>
							 <?php echo $adm_st["add2"]; ?><br>
							 <?php echo $adm_st["contact1"]." , ".$adm_st["contact2"]; ?><br>
							 
							 <?php echo $adm_st["aadhaar"]; ?><br>
							 <?php echo $adm_st["dob"]; ?><br>
							 <?php echo $adm_st["nationality"]; ?><br>
							 <?php echo $adm_st["religion"]."/".$adm_st["caste"]; ?><br>
							 <?php echo $st_tut["fee"]; ?><br>
							 <?php echo $adm_st["conveyance2025"]; 
							     if($adm_st["conveyance2025"]=="YES")
								 {
									 $st_con=mysqli_fetch_array(mysqli_query($link,"select * from conveyance2025 where adm_no='$adm'"));
										echo "/".$st_con["fee"];
								 }
							 ?><br>
							 
					      </div>
					  
					 </div>
				 
					 
					 

				  
				  
				  
				  <div style="height:50px">
				         --------------------------------------------------------------------
						 <br><center>Thanks</center>
				   </div>
		    
			
			
			
			
			
				   
		    </td>
		</tr>
	</table>
	
	</body></html>
<?php
	}
?>