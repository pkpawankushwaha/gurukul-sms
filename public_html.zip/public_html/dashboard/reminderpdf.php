<?php
  include "header.php";
   if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Reminder PDF</h2>
            </div>
          </header>
          
    <div class="container">
              <br>
              <a href="reminder/LKG A.pdf" target=_blank>LKG A</a><br>
              <a href="reminder/UKG A.pdf" target=_blank>UKG A</a><br>
              <a href="reminder/UKG B.pdf" target=_blank>UKG B</a><br>
              <a href="reminder/I A.pdf" target=_blank>I A</a><br>
              <a href="reminder/I B.pdf" target=_blank>I B</a><br>
              <a href="reminder/II A.pdf" target=_blank>II A</a><br>
              <a href="reminder/III A.pdf" target=_blank>III A</a><br>
              <a href="reminder/III B.pdf" target=_blank>III B</a><br>
              <a href="reminder/IV A.pdf" target=_blank>IV A</a><br>
              <a href="reminder/V A.pdf" target=_blank>V A</a><br>
              <a href="reminder/VI A.pdf" target=_blank>VI A</a><br>
              <a href="reminder/VI B.pdf" target=_blank>VI B</a><br>
              <a href="reminder/VII A.pdf" target=_blank>VII A</a><br>
              <a href="reminder/VIII A.pdf" target=_blank>VIII A</a><br>
              <a href="reminder/IX A.pdf" target=_blank>IX A</a><br>
              <a href="reminder/X A.pdf" target=_blank>X A</a><br>
              <br>
    </div>






<?php
}
?>


<?php
  include "footer.php";
?>
          
          