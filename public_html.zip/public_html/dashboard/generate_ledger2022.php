<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>GSS Gurukul Shikshan Sansthan</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<?php
 
  include "connection.php";
  if(!isset($_SESSION["teacher_user"]))
 {	
 	$res=mysqli_query($link,"SELECT * FROM `student` WHERE class2022='$_POST[class]' ORDER BY `student`.`roll2022` ASC");
 	$count=mysqli_num_rows($res);
	?>
    <h3>Fee Ledger for 2022-23</h3>
 	<table border=1>
 		<tr>
 			<th colspan="20">Class <?php echo $_POST["class"];?></th>
 		</tr>
 		<tr>
 			<th colspan="20">Fees total to be paid for :<br>
 				<?php
 				if(isset($_POST["April"]))
 		{
			echo "April ";
 		}
 		if(isset($_POST["May"]))
 		{
 			echo "May ";
 		}
 		if(isset($_POST["June"]))
 		{
 			echo "June ";
 		}
 		if(isset($_POST["July"]))
 		{
 			echo "July ";
 		}
 		if(isset($_POST["August"]))
 		{
 			echo "Aug ";
 		}
 		if(isset($_POST["September"]))
 		{
 			echo "Sep ";
 		}

 		if(isset($_POST["October"]))
 		{
 			echo "Oct ";
 		}
 		if(isset($_POST["November"]))
 		{
 			echo "Nov ";
 		}
 		if(isset($_POST["December"]))
 		{
 			echo "Dec ";
 		}
 		if(isset($_POST["Janaury"]))
 		{
 			echo "Jan ";
 		}
 		if(isset($_POST["February"]))
 		{
 			echo "Feb ";
 		}
 		if(isset($_POST["March"]))
 		{
 			echo "Mar ";
 		}
 		echo "<br>";
 		if(isset($_POST["idcard"]))
 		{
 			echo "IDCard ";
 		}
 		if(isset($_POST["exam1"]))
 		{
 			echo "ThirdMonthlyExam ";
 		}
 		if(isset($_POST["exam2"]))
 		{
 			echo "HalfYearlyExam ";
 		}
 		if(isset($_POST["exam3"]))
 		{
 			echo "YearlyExam ";
 		}
 		if(isset($_POST["result_card"]))
 		{
 			echo "Result Card ";
 		}
 		?>
 			</th>
 		</tr>
		<tr>
			<th>Roll</th><th>AdmNo.</th><th>Name</th><th>Father Name</th><th>Fee</th>
					<th>Apr</th><th>May</th><th>Jun</th><th>Jul</th><th>Aug</th><th>Sep</th><th>Oct</th><th>Nov</th><th>Dec</th><th>Jan</th><th>Feb</th><th>Mar</th>
					<th>ID</th><th>Exam</th><th>Res</th><th>Total</th>
				
		</tr>
		
	<?php
 	for($i=0;$i<$count;$i++)
 	{	
 		$row=mysqli_fetch_array($res);
		
 		$tut=mysqli_fetch_array(mysqli_query($link,"select * from tution2023 where adm_no='$row[adm_no]'"));
 		$con=mysqli_fetch_array(mysqli_query($link,"select * from conveyance2023 where adm_no='$row[adm_no]'"));
		$oth=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2023 where adm_no='$row[adm_no]'"));
		$other=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2023 where adm_no=20190000"));
		$total=0;$c=0;
		if(isset($_POST["April"]))
 		{
			if($tut["April"]=="N")
 			{
 				
 				$c+=1;
 			}
 		}
 		if(isset($_POST["May"]))
 		{
 			if($tut["May"]=="N")
 			{
 				
 				$c+=1;
 			}
 		}
 		if(isset($_POST["June"]))
 		{
 			if($tut["June"]=="N")
 			{
 				
 				$c+=1;
 			}
 		}
 		if(isset($_POST["July"]))
 		{
 			if($tut["July"]=="N")
 			{
 				
 				$c+=1;
 			}
 		}
 		if(isset($_POST["August"]))
 		{
 			if($tut["August"]=="N")
 			{
 				
 				$c+=1;
 			}
 		}
 		if(isset($_POST["September"]))
 		{
 			if($tut["September"]=="N")
 			{
 				
 				$c+=1;
 			}
 		}

 		if(isset($_POST["October"]))
 		{
 			if($tut["October"]=="N")
 			{
 				
 				$c+=1;
 			}
 		}
 		if(isset($_POST["November"]))
 		{
 			if($tut["November"]=="N")
 			{
 				
 				$c+=1;
 			}
 		}
 		if(isset($_POST["December"]))
 		{
 			if($tut["December"]=="N")
 			{
 				
 				$c+=1;
 			}
 		}
 		if(isset($_POST["Janaury"]))
 		{
 			if($tut["January"]=="N")
 			{ 				$c+=1;
 			}
 		}
 		if(isset($_POST["February"]))
 		{
 			if($tut["February"]=="N")
 			{
 				$c+=1;
 			}
 		}
 		if(isset($_POST["March"]))
 		{
 			if($tut["March"]=="N")
 			{
 				$c+=1;
 			}
 		}
 		
 		$tutf=$c*$tut["fee"];
 		$total+=$tutf;$st="";
 		
		
			if($row['conveyance']=="YES"){
				$c=0;echo "<tr>";
				if(isset($_POST["cApril"]))
			 		{
			 			if($con["April"]=="N")
			 			{
			 				$st=$st."Apr ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cMay"]))
			 		{
			 			if($con["May"]=="N")
			 			{
			 				$st=$st."May ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cJune"]))
			 		{
			 			if($con["June"]=="N")
			 			{
			 				$st=$st."Jun ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cJuly"]))
			 		{
			 			if($con["July"]=="N")
			 			{
			 				$st=$st."Jul ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cAugust"]))
			 		{
			 			if($con["August"]=="N")
			 			{
			 				$st=$st."Aug ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cSeptember"]))
			 		{
			 			if($con["September"]=="N")
			 			{
			 				$st=$st."Sep ";
			 				$c+=1;
			 			}
			 		}

			 		if(isset($_POST["cOctober"]))
			 		{
			 			if($con["October"]=="N")
			 			{
			 				$st=$st."Oct ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cNovember"]))
			 		{
			 			if($con["November"]=="N")
			 			{
			 				$st=$st."Nov ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cDecember"]))
			 		{
			 			if($con["December"]=="N")
			 			{
			 				$st=$st."Dec ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cJanaury"]))
			 		{
			 			if($con["Janaury"]=="N")
			 			{
			 				$st=$st."Jan ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cFebruary"]))
			 		{
			 			if($con["February"]=="N")
			 			{
			 				$st=$st."Feb ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cMarch"]))
			 		{
			 			if($con["March"]=="N")
			 			{
			 				$st=$st."Mar ";
			 				$c+=1;
			 			}
			 		}

			 		
			 		$conc=$c;
			 		$conf=$c*$con["fee"];
			 		$total+=$conf;
			 		

				?>
				<td rowspan="2"><?php echo ($i+1); ?></td><td rowspan="2"><?php echo "$row[adm_no]"; ?></td><td rowspan="2"><?php echo "$row[name]"; ?></td><td rowspan="2"><?php echo "$row[father_name]"; ?></td>
			<?php
			}
			else{
				?>
				<td  ><?php echo ($i+1); ?></td><td  ><?php echo "$row[adm_no]"; ?></td><td  ><?php echo "$row[name]"; ?></td><td  ><?php echo "$row[father_name]"; ?></td>
				<?php
			}
			
			echo "<td>".$tut["fee"]."</td>";
			echo "<td>".$tut["April"]."</td>";
			echo "<td>".$tut["May"]."</td>";
			echo "<td>".$tut["June"]."</td>";
			echo "<td>".$tut["July"]."</td>";
			echo "<td>".$tut["August"]."</td>";
			echo "<td>".$tut["September"]."</td>";
			echo "<td>".$tut["October"]."</td>";
			echo "<td>".$tut["November"]."</td>";
			echo "<td>".$tut["December"]."</td>";
			echo "<td>".$tut["January"]."</td>";
			echo "<td>".$tut["February"]."</td>";
			echo "<td>".$tut["March"]."</td>";
			echo "<td>".$oth["idcard"]."</td>";
			if($oth["result_card"]==20)
			    $result_card="Y";
			else
			    $result_card="N";
			    
			    
			    if(isset($_POST["idcard"]))
			 		{
			 			if($oth["idcard"]=="N")
			 			{
			 				
			 				$total+=$other["idcard_rec"];
			 			}
			 		}
			 		if(isset($_POST["exam1"]))
			 		{
			 			if($oth["exam1"]=="N")
			 			{
			 				
			 				$total+=$other["exam1_rec"];
			 			}
			 		}
			 		if(isset($_POST["exam2"]))
			 		{
			 			if($oth["exam2"]=="N")
			 			{
			 				
			 				$total+=$other["exam2_rec"];
			 			}
			 		}
			 		if(isset($_POST["exam3"]))
			 		{
			 			if($oth["exam3"]=="N")
			 			{
			 				
			 				$total+=$other["exam3_rec"];
			 			}
			 		}
			 		if(isset($_POST["result_card"]))
			 		{
			 			if($oth["result_card"]==0)
			 			{
			 				
			 				$total+=$other["result_card"];
			 			}
			 		}
			 		
			echo "<td>".$oth["exam1"]." ".$oth["exam2"]." ".$oth["exam3"]."</td>";
			echo "<td>".$result_card."</td>";
			if($row['conveyance']=="YES"){
				?>
				<td rowspan="2"><?php echo $total; ?></td>
				</tr>
				<tr>
				<?php
					echo "<td>".$con["fee"]."</td>";
					echo "<td>".$con["April"]."</td>";
					echo "<td>".$con["May"]."</td>";
					echo "<td>".$con["June"]."</td>";
					echo "<td>".$con["July"]."</td>";
					echo "<td>".$con["August"]."</td>";
					echo "<td>".$con["September"]."</td>";
					echo "<td>".$con["October"]."</td>";
					echo "<td>".$con["November"]."</td>";
					echo "<td>".$con["December"]."</td>";
					echo "<td>".$con["Janaury"]."</td>";
					echo "<td>".$con["February"]."</td>";
					echo "<td>".$con["March"]."</td>";
					echo "<td> </td><td> </td>";
					echo "</tr>";
				
			}
			else{
						
 			
				?>
				<td  ><?php echo $total; ?></td>
				</tr>
				
				<?php
			}
		}
	}
	echo "</table>";
?>