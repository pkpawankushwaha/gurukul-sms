<?php
  include "header.php";
   if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Class List</h2>
            </div>
          </header>
    <div class="container bg-white">

               
    <form name="form1" class="form" action="" method="post">
    <div class="form-group row">
      <div class="col-md-4"></div>
      <div class="col-md-2">Select Class</div>
        <div class="col-md-2">
        <select name="class" class="form-control form-control-sm mb-3">
                    
        <?php
        
           $cl=mysqli_query($link,"select * from class");
           $count=0;$count=mysqli_num_rows($cl);
           while($count>0)
             {   
              $row=mysqli_fetch_array($cl);
               echo "<option>".$row["class"]."</option>";
              $count-=1;
            
              }
        
        ?>
    </select></div></div>
    
    <center><input type="submit" class="btn btn-primary" name="submit1"></center>
    </form><br>
  
  <?php
     if(!isset($_POST["submit1"]))
       {
         
              
       }
         else
         {     
               $res1=mysqli_query($link,"select * from student where class='$_POST[class]'");
           $c=mysqli_num_rows($res1);
           echo $c;
          ?>
            <br><br>
            <a href="print_classlist.php?class=<?php echo $_POST["class"]; ?>" target=_blank><font size=6px>Click here to print Class List 2019-20</font></a>
            
            
            <br><br>
            <a href="print_classlist2020.php?class=<?php echo $_POST["class"]; ?>" target=_blank><font size=6px>Click here to print Class List 2020-21</font></a>
            
            <br><br>
            <a href="print_classlist2021.php?class=<?php echo $_POST["class"]; ?>" target=_blank><font size=6px>Click here to print Class List 2021-22</font></a>
            
            <br><br>
            <a href="print_classlist2022.php?class=<?php echo $_POST["class"]; ?>" target=_blank><font size=6px>Click here to print Class List 2022-23</font></a>
            
            <a href="print_classlist2023.php?class=<?php echo $_POST["class"]; ?>" target=_blank><font size=6px>Click here to print Class List 2023-24</font></a>
            <a href="print_classlist2024.php?class=<?php echo $_POST["class"]; ?>" target=_blank><font size=6px>Click here to print Class List 2024-25</font></a>
            
            
            
          <?php
       }
       echo "</center>";
     }
     include "footer.php";
   
   ?>