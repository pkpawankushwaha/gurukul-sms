<?php
    session_start();
	
   
    include "connection.php";
	if(!isset($_SESSION["teacher_user"]))
    {
    	echo "Access Denied\nPlease Login";
    }
	else
	{
		$class="1211";
	  
	  $rec=$_GET["rec"];
	  $recres=mysqli_fetch_array(mysqli_query($link,"select * from reciept2021"));
	  if($rec[2]=='2' and $rec[3]=='0'){
		$recres=mysqli_fetch_array(mysqli_query($link,"select * from reciept2021 where rec_no='$rec'"));
		
	  }
	  else if($rec[2]=='2' and $rec[3]=='1'){
		$recres=mysqli_fetch_array(mysqli_query($link,"select * from reciept2022 where rec_no='$rec'"));
		
	  }
	  else if($rec[2]=='2' and $rec[3]=='2'){
		$recres=mysqli_fetch_array(mysqli_query($link,"select * from reciept2023 where rec_no='$rec'"));
		
	  }
	  else if($rec[2]=='2' and $rec[3]=='3'){
		$recres=mysqli_fetch_array(mysqli_query($link,"select * from reciept2024 where rec_no='$rec'"));
		
	  }
	  else if($rec[2]=='2' and $rec[3]=='4'){
		$recres=mysqli_fetch_array(mysqli_query($link,"select * from reciept2025 where rec_no='$rec'"));
		
	  }
	  else{
		$recres=mysqli_fetch_array(mysqli_query($link,"select * from reciept where rec_no='$rec'"));
	  }
	 
	  $adm=$recres["adm_no"];
	  $roll=0;
	  $stres=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$adm'"));
	  if($rec[2]=='2' and $rec[3]=='0'){
		  $class=$stres["class2020"];
		  $roll=$stres['roll2020'];
	  }
	  else if($rec[2]=='2' and $rec[3]=='1'){
		  $class=$stres["class2021"];
		   $roll=$stres['roll2021'];
	  }
	  else if($rec[2]=='2' and $rec[3]=='2'){
		$class=$stres["class2022"];
		 $roll=$stres['roll2022'];
	} else if($rec[2]=='2' and $rec[3]=='3'){
		$class=$stres["class2023"];
		 $roll=$stres['roll2023'];
	}
	else if($rec[2]=='2' and $rec[3]=='4'){
		$class=$stres["class2024"];
		 $roll=$stres['roll2024'];
	}
	  else{
			$class=$stres["class"];
	  }
	  

	  
	  
     echo "---------------------------Student Copy---------------------------------------------------------Office Copy----------------------------<br>";	
?>
    <html>
	<body>
	
	
	<table border=3 height=450px width=780px>
	     <tr>
		  <td width=49%>
		     <div style="height:160px">
				    <font size=5px><center><b>Gurukul Shikshan Sansthan</b> </center></font>
					<font size=3px><center>Khampar(Jaipur) Deoria (U.P.) </center><hr>
					<center><b><u>FEE RECIEPT</b></u></center></font>
					&nbsp  <b>Date : </b><?php echo $recres["date"]."   &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp<b>Reciept No.: </b>".$rec; ?><br>
					&nbsp  <b>Adm.No.: </b><?php  $c=1;echo $adm." &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<b>Class :</b> ".$class."<br><center><b>
					        Name : &nbsp".$stres["name"]."</b>   Roll No. : ".$roll."<br>Father's Name : ".$stres["father_name"]."<br>"; ?>  
					--------------------------------------------------------------------
				</div>
                <div style="height:190px">		
			       <table  border=1 min-height=500px  width=100%>
				      <th width=4%>S.No.</th><th>Particulars</th><th width=20%>Amt(Rs.)</th><tr>
					  <td width=4%><?php echo $c;$c+=1; ?></td><td><b><u>Tuition Fee</b></u>&nbsp&nbsp&nbsp&nbsp
					          <?php 
							  
							     if($recres["t_m_num"]==1)
								 {	 $pr=$recres["t_m_name"]; 
							         echo $pr[0].$pr[1].$pr[2];
									 echo "     (".$recres["t_m_num"].") ";}
								 else{
							         echo $recres["t_m_name"]; 
								 echo "     (".$recres["t_m_num"].") ";}
							  
							  ?></td><td width=20% style="text-align:right;"><?php echo $recres["t_m_amt"]; ?></td><tr>
					 <?php
					   
						if($recres["c_m_num"]>0)
						{
					    echo "<td width=4%>";echo $c;
						echo "</td><td><b><u>ConveyanceFee</b></u>&nbsp&nbsp&nbsp&nbsp";
						
					          if($recres["c_m_num"]==1)
								 {	 $pr=$recres["c_m_name"]; 
							         echo $pr[0].$pr[1].$pr[2];
									 echo "     (".$recres["c_m_num"].") ";}
								 else{
							         echo $recres["c_m_name"]; 
									 echo "     (".$recres["c_m_num"].") ";
								 }
							  
							  
							  
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["c_m_amt"]; echo "</td><tr>";
							  
						
					 
						}
						if($recres["form"]>0)
						      {
					             echo "<td width=4%>";echo $c;$c+=1;
						         echo "</td><td><b>Form Fee</b>&nbsp&nbsp&nbsp&nbsp";
							     echo "</td><td width=20% style='text-align:right;'>";echo $recres["form"]; echo "</td><tr>";
					 
						      }
						if($recres["adm_fee"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Admission Fee</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["adm_fee"]; echo "</td><tr>";
					 
						}
						if($recres["tie_belt"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Tie and Belt</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["tie_belt"]; echo "</td><tr>";
					 
						}if($recres["idcard"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Identity Card</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["idcard"]; echo "</td><tr>";
					 
						}
						if($recres["exam1"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Third Monthly Exam</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["exam1"]; echo "</td><tr>";
					 
						}
						if($recres["exam2"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Half Yearly Exam</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["exam2"]; echo "</td><tr>";
					 
						}
						if($recres["exam3"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Yearly Exam</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["exam3"]; echo "</td><tr>";
					 
						}
						if($recres["result_card"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Result Card</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["result_card"]; echo "</td><tr>";
					 
						}
					 ?>
				      <th width=4%></th><th>Total</th><th width=20% style="text-align:right;" ><?php echo $recres["total"]; ?></th>
				   </table><br>
				   <b><center>Net Amount to Pay  : &nbsp &nbsp Rs.<?php echo $recres["total"]; ?></center></b>
				  </div>
				  <div style="text-align:right;margin-right:30px;height:100px">
				  <br><br><br>
				 
				   			   <b>Cashier/Clerk</b><br>
				   <?php echo $recres["teacher"]; ?><br>
				   </div>
		    </td>
			
			
	
		  <td width=1%><center><font color=red>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br></center></td>
		 <td width=49%>
		            <div style="height:160px">
				    <font size=5px><center><b>Gurukul Shikshan Sansthan</b> </center></font>
					<font size=3px><center>Khampar(Jaipur) Deoria (U.P.) </center><hr>
					<center><b><u>FEE RECIEPT</b></u></center></font>
					&nbsp  <b>Date : </b><?php echo $recres["date"]."   &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp<b>Reciept No.: </b>".$rec; ?><br>
					&nbsp  <b>Adm.No.: </b><?php  $c=1;echo $adm." &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<b>Class :</b> ".$class."<br><center><b>
					         Name : &nbsp".$stres["name"]."</b>   Roll No. : ".$roll."<br>Father's Name : ".$stres["father_name"]."<br>"; ?>   
					--------------------------------------------------------------------
				</div>
                <div style="height:190px">		
			       <table  border=1 min-height=500px  width=100%>
				      <th width=4%>S.No.</th><th>Particulars</th><th width=20%>Amt(Rs.)</th><tr>
					  <td width=4%><?php echo $c;$c+=1; ?></td><td><b><u>Tuition Fee</b></u>&nbsp&nbsp&nbsp&nbsp
					          <?php 
							  
							     if($recres["t_m_num"]==1)
								 {	 $pr=$recres["t_m_name"]; 
							         echo $pr[0].$pr[1].$pr[2];
									 echo "     (".$recres["t_m_num"].") ";}
								 else{
							         echo $recres["t_m_name"]; 
									 echo "     (".$recres["t_m_num"].") ";
								 }
							  
							  ?></td><td width=20% style="text-align:right;"><?php echo $recres["t_m_amt"]; ?></td><tr>
					 <?php
					   
						if($recres["c_m_num"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b><u>ConveyanceFee</b></u>&nbsp&nbsp&nbsp&nbsp";
						
					          if($recres["c_m_num"]==1)
								 {	 $pr=$recres["c_m_name"]; 
							         echo $pr[0].$pr[1].$pr[2];
									 echo "     (".$recres["c_m_num"].") ";}
								 else{
							         echo $recres["c_m_name"]; 
									 echo "     (".$recres["c_m_num"].") ";
								 }
							  
							  
							  
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["c_m_amt"]; echo "</td><tr>";
					 
						}
						
						
						if($recres["form"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Form Fee</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["form"]; echo "</td><tr>";
					 
						}
						if($recres["adm_fee"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Admission Fee</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["adm_fee"]; echo "</td><tr>";
					 
						}
						if($recres["tie_belt"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Tie and Belt</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["tie_belt"]; echo "</td><tr>";
					 
						}if($recres["idcard"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b><u>Identity Card</b></u>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["idcard"]; echo "</td><tr>";
					 
						}
						if($recres["exam1"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Third Monthly Exam</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["exam1"]; echo "</td><tr>";
					 
						}
						if($recres["exam2"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Half Yearly Exam</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["exam2"]; echo "</td><tr>";
					 
						}
						if($recres["exam3"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Yearly Exam</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["exam3"]; echo "</td><tr>";
					 
						}
						if($recres["result_card"]>0)
						{
					    echo "<td width=4%>";echo $c;$c+=1;
						echo "</td><td><b>Result Card</b>&nbsp&nbsp&nbsp&nbsp";
							  echo "</td><td width=20% style='text-align:right;'>";echo $recres["result_card"]; echo "</td><tr>";
					 
						}
						
					 ?>
				      <th width=4%></th><th>Total</th><th width=20% style="text-align:right;" ><?php echo $recres["total"]; ?></th>
				   </table><br>
				   <b><center>Net Amount to Pay  : &nbsp &nbsp Rs.<?php echo $recres["total"]; ?></center></b>
				  </div>
				  <div style="text-align:right;margin-right:30px;height:100px">
				  <br><br><br>
				 
				   			   <b>Cashier/Clerk</b><br>
				   <?php echo $recres["teacher"]; ?><br>
				   </div>
		    </td>
		</tr>
	</table>
	
	</body></html>
<?php
	}
?>