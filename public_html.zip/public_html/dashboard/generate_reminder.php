<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>GSS Gurukul Shikshan Sansthan</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<?php
 
  include "connection.php";
  if(!isset($_SESSION["teacher_user"]))
 {
 	$res=mysqli_query($link,"select * from student where class2024='$_POST[class]' ORDER BY roll2024");
 	$count=mysqli_num_rows($res);
//  	echo $count;

 	for($i=0;$i<$count;$i++)
 	{	
 	  //  echo $i;
 		$row=mysqli_fetch_array($res);
//  		echo $row["adm_no"]."<br>";
 		$tut=mysqli_fetch_array(mysqli_query($link,"select * from tution2025 where adm_no='$row[adm_no]'"));
 		
 		
 		$st="";$total=0;$n=0;
 		$end="";
 		$c=0;

 		if(isset($_POST["April"]))
 		{
 			if($tut["April"]=="0")
 			{
 				$st=$st."Apr ";
 				$c+=1;
 			}
 		}
 		if(isset($_POST["May"]))
 		{
 			if($tut["May"]=="0")
 			{
 				$st=$st."May ";
 				$c+=1;
 			}
 		}
 		if(isset($_POST["June"]))
 		{
 			if($tut["June"]=="0")
 			{
 				$st=$st."Jun ";
 				$c+=1;
 			}
 		}
 		if(isset($_POST["July"]))
 		{
 			if($tut["July"]=="0")
 			{
 				$st=$st."Jul ";
 				$c+=1;
 			}
 		}
 		if(isset($_POST["August"]))
 		{
 			if($tut["August"]=="0")
 			{
 				$st=$st."Aug ";
 				$c+=1;
 			}
 		}
 		if(isset($_POST["September"]))
 		{
 			if($tut["September"]=="0")
 			{
 				$st=$st."Sep ";
 				$c+=1;
 			}
 		}

 		if(isset($_POST["October"]))
 		{
 			if($tut["October"]=="0")
 			{
 				$st=$st."Oct ";
 				$c+=1;
 			}
 		}
 		if(isset($_POST["November"]))
 		{
 			if($tut["November"]=="0")
 			{
 				$st=$st."Nov ";
 				$c+=1;
 			}
 		}
 		if(isset($_POST["December"]))
 		{
 			if($tut["December"]=="0")
 			{
 				$st=$st."Dec ";
 				$c+=1;
 			}
 		}
//  		echo $st."....<br>";
 		if(isset($_POST["Janaury"]))
 		{
 			if($tut["January"]=="0")
 			{
 				$st=$st."Jan ";
 				$c+=1;
 			}
 		}
 		if(isset($_POST["February"]))
 		{
 			if($tut["February"]=="0")
 			{
 				$st=$st."Feb ";
 				$c+=1;
 			}
 		}
 		if(isset($_POST["March"]))
 		{
 			if($tut["March"]=="0")
 			{
 				$st=$st."Mar ";
 				$c+=1;
 			}
 		}
//  		echo $st."<br>";
 		$tuts=$st;$tutc=$c;
 		$tutf=$c*$tut["fee"];
 		$total+=$tutf;
 		
 		$conf=0;$st="";$c=0;
 		if($row["conveyance2025"]=="YES")
 		{
 			$con=mysqli_fetch_array(mysqli_query($link,"select * from conveyance2025 where adm_no='$row[adm_no]'"));
             $tut=$con;
               
			 		if(isset($_POST["cApril"]))
			 		{
			 			if($tut["April"]=="0")
			 			{
			 				$st=$st."Apr ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cMay"]))
			 		{
			 			if($tut["May"]=="0")
			 			{
			 				$st=$st."May ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cJune"]))
			 		{
			 			if($tut["June"]=="0")
			 			{
			 				$st=$st."Jun ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cJuly"]))
			 		{
			 			if($tut["July"]=="0")
			 			{
			 				$st=$st."Jul ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cAugust"]))
			 		{
			 			if($tut["August"]=="0")
			 			{
			 				$st=$st."Aug ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cSeptember"]))
			 		{
			 			if($tut["September"]=="0")
			 			{
			 				$st=$st."Sep ";
			 				$c+=1;
			 			}
			 		}

			 		if(isset($_POST["cOctober"]))
			 		{
			 			if($tut["October"]=="0")
			 			{
			 				$st=$st."Oct ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cNovember"]))
			 		{
			 			if($tut["November"]=="0")
			 			{
			 				$st=$st."Nov ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cDecember"]))
			 		{
			 			if($tut["December"]=="0")
			 			{
			 				$st=$st."Dec ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cJanaury"]))
			 		{
			 			if($tut["January"]=="0")
			 			{
			 				$st=$st."Jan ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cFebruary"]))
			 		{
			 			if($tut["February"]=="0")
			 			{
			 				$st=$st."Feb ";
			 				$c+=1;
			 			}
			 		}
			 		if(isset($_POST["cMarch"]))
			 		{
			 			if($tut["March"]=="0")
			 			{
			 				$st=$st."Mar ";
			 				$c+=1;
			 			}
			 		}

			 		$cons=$st;
			 		$conc=$c;
			 		$conf=$c*$con["fee"];$total+=$conf;



 		}


 		$st="";$othf=0;
 		$oth=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2025 where adm_no='$row[adm_no]'"));
 		$othA=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2025 where adm_no='20190000'"));
 		if(isset($_POST["idcard"]))
 		{
 			if($oth["idcard"]=="0")
 			{
 				$st=$st."IDCard";
 				$othf+=$othA["idcard_rec"];
 			}
 		}
 		if(isset($_POST["exam1"]))
 		{
 			if($oth["exam1"]=="0")
 			{
 				$st=$st." TM_EXAM";
 				$othf+=$othA["exam1_rec"];
 			}
 		}
 		if(isset($_POST["exam2"]))
 		{
 			if($oth["exam2"]=="0")
 			{
 				$st=$st." HY_Exam";
 				$othf+=$othA["exam2_rec"];
 			}
 		}
 		if(isset($_POST["exam3"]))
 		{
 			if($oth["exam3"]=="0")
 			{
 				$st=$st." Y_Exam";
 				$othf+=$othA["exam3_rec"];
 			}
 			
 		}
 		if(isset($_POST["result_card"]))
 		{
 			if($oth["result_card"]==0)
 			{
 				$st=$st." result_card";
 				$othf+=$othA["result_card_rec"];
 			}
 			
 		}
 		
        $total+=$othf;
		
        if($total>0){
        $n+=1;
		




		if($n%6==1){
 			?>
 			<div style="height: 990px;width:1200px">
 			
 				<?php
 		}

 		if($n%2==1){
 			?>
 			<div style="height: 550px;width:1200px">
 				<div style="float:left;width: 500px; margin-right: 50px;margin-bottom:10px;">
 			
 				<?php
 		}
 		else{
 			?><div style="float:right; width: 500px; margin-left: 50px;margin-bottom:10px;">
 			<?php
 		}

 		?>

  			<table border=3 height=550px width=500px>
	     <tr>
		  <td>
		     <div style="height:160px">
				    <font size=5px><center><b>Gurukul Shikshan Sansthan</b> </center></font>
					<font size=3px><center>Khampar(Jaipur) Deoria (U.P.) </center><hr>
					<center><b><u>FEE Reminder RECIEPT</b></u></center></font></b></center>
					<b>Date : </b><?php echo date('d/m/Y');?>&nbsp  <?php echo $row["class2024"];?> -
					<?php echo $row["roll2024"];?> &nbsp&nbsp 
					<b>AdmNo:</b><?php echo $row["adm_no"]; ?>&nbsp<b>Mob:</b><?php echo $row["contact1"] ?><br>
					<b>Name : </b><?php echo $row["name"];?><br>
					
					<b>Father's Name : </b><?php echo $row["father_name"];?>
					
			 </div><br>
             <div style="height:120px">	

			       <table  border=1 min-height=300px  width=100%>
				      <th>Particulars</th><th width=20%>Amt(Rs.)</th><tr>
					  <td><b><u>Tuition Fee</b></u><br><?php echo $tuts;?>&nbsp&nbsp&nbsp&nbsp</b></td><td style="text-align:right;"><?php echo $tutf; ?></td></tr>
					  <?php if($conf>0){ ?>
					  	<tr><td><b><u>Conveyance Fee</b></u><br><?php echo $cons;  ?>&nbsp&nbsp&nbsp&nbsp</b></td><td style="text-align:right;"><?php echo $conf; ?></td></tr>
					  	<?php } ?>
					  	<?php if($othf>0){ ?>
					  <tr><td><b><u>Other Fee</b></u></b><?php echo $st; ?></td><td style="text-align:right;"><?php echo $othf; ?></td></tr>	   
				  	 </td></tr>
				  	<?php } ?>
				  	 <tr><td><b><u>Total Fee</b></u></b></td><td style="text-align:right;"><?php echo $total; ?></td></tr>	   
				  	 </td></tr>
				  	</table>
				  	</div><br>
				  	<pre style="font-size: 16px">
मान्यवर,
    अभिभावक महोदय,
आपके पाल्य का मासिक शुल्क बकाया है| कुल मिलाकर इनका 
बकाया शुल्क रु० <?php echo "<b>".$total."</b>"; ?> है|
   आपसे यह निवेदन है कि शुल्क का भुगतान यथाशीघ्र करके
 पठन-पाठन कार्य सुचारू रूप से चलाने में हमारी मदद करें|
</pre>

				  	<div style="text-align:right;"><b>Cashier/Clerk &nbsp&nbsp&nbsp&nbsp</b></div>
			 
		    
		</td></tr></table>
	 		</div>
	 		
			
 		<?php


 		if($n%2==0){
 			?>
 			</div>
 			<?php
 		}
 		

 		
 		if($n%6==0){
 			?>
 			</div>
 			<?php
 		}


 	}

	} 			

   ?>

   <?php



 }
 else
  {

?>
			<script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
    Access Denied.
   Please Login to Continue
<?php

  }

 ?>