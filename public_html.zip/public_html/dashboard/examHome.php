<?php
  include "examHeader.php";
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Examination Dashboard</h2>
            </div>
          </header>
          <br>
    <div class="container">
              <div class="row bg-white has-shadow"> 
                <div class="col-xl-3 col-sm-4">
                <a href="marksEntryTM.php">
                    <center><img src="./img/addst.jpg" height=150px style="border-radius:50%"><br>Add Marks ThirdMonthly</center>
                </a>
                <a href="marksEntryHY.php">
                    <!--<center><img src="./img/addst.jpg" height=150px style="border-radius:50%"><br>Add Marks HalfYearly</center>-->
                </a>
                <a href="marksEntryY.php">
                    <!--<center><img src="./img/addst.jpg" height=150px style="border-radius:50%"><br>Add Marks Yearly</center>-->
                </a>
                <a href="logout.php">
                    <center><img src="./img/logout.jpg" height=150px style="border-radius:50%"><br>Logout</center>
                </a>
                </div>
              </div>
    </div>
<?php
}
?>


<?php
  include "footer.php";
?>
          
          