<?php
  include "examHeader.php";
  include "connection.php";
  if(!isset($_SESSION["teacher_user"]))
  {
    ?>
    <script type="text/javascript">
        window.location="StaffLogin.php";
    </script>
    <?php
   } else
   {
?>
    <!-- Page Header-->
    <header class="page-header">
        <div class="container-fluid">
            <h2 class="no-margin-bottom">Third Monthly Examination Marks List</h2>
        </div>
    </header>

    

    <div class="container-fluid">
        <select name="classList" id="classList">
            <option value="Class"> Class </option>
        </select>

        <select name="subjects" id="subjects" style="display : none">
            <option value="Subject"> Subject </option>
        </select>

        <button id="btn">Submit</button>

        <div id="result"></div>

        <table id="studentsList" class="uList" style="border: 1px solid black">
            <tr>
                <td>Roll</td><td>Name</td><td>Marks</td>
            </tr>
        </table>

       
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript">
        const studentMarks = {}; 
        $(document).ready(function() {
            fetchClassList();
            $("#subjects").hide();
            $("#btn").hide();
            $("#submitMarksButton").hide();
        });
        $("#classList").change(function() {
            var selectedClass = $("#classList").find(':selected').val();
            fetchSubjects(selectedClass);
            $("#subjects").show();
            $("#classList").prop("disabled", true);
        });
        $("#subjects").change(function() {
            $("#submitMarksButton").show();
            $("#subjects").prop("disabled", true);
            var selectedClass = $("#classList").find(':selected').val();
            var selectSub = $("#subjects").find(':selected').val();
            fetchMarkList(selectedClass, selectSub);
        });
        $("#btn").click(function() {
            $(this).prop("disabled", true);
            var selectedClass = $("#classList").find(':selected').val();
            var selectSub = $("#subjects").find(':selected').val();
            fetchMarkList(selectedClass, selectSub);
        });

        function fetchClassList() {
            
            $.ajax({
                    url: 'examAPI.php/classList',
                    type: "GET",
                    dataType: "json",
                    success: function(data) {
                        appendClassList(data.classList);
                        
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching data:", error);
                    }
                });
        }

        function appendClassList(classList) {

            if (classList.length > 0) {
                $.each(classList, function(index, className) {
                    var classListHTML = "<option value=" + encodeURIComponent(className) + ">" + (className) + "</option>";
                    $("#classList").append($(classListHTML));
                });
            }
        }

        function fetchSubjects(selectedClass) {
            $.ajax({
                    url: 'examAPI.php/subjects?class=' + encodeURIComponent(selectedClass),
                    type: "GET",
                    dataType: "json",
                    success: function(data) {
                        appendSubject(data.subjects)
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching data:", error);
                    }
                });
        }

        function appendSubject(subjectList) {

            if (subjectList.length > 0) {
                $.each(subjectList, function(index, subject) {
                    var classListHTML = "<option value=" + subject.code + ">" + subject.name + "</option>";
                    $("#subjects").append($(classListHTML));
                });
            }
        }

        function fetchMarkList(selectedClass, subject) {
            var table='exam2024tm';
            $.ajax({
                    url: 'examAPI.php/markList?class=' + encodeURIComponent(selectedClass) + '&subCode=' + subject + '&table=' + table,
                    type: "GET",
                    dataType: "json",
                    success: function(data) {
                        const studentListElement = document.getElementById('studentsList');
                        const students = data.students;
                        students.forEach(student => {
                            // Create elements to display student info and input field
                            const listItem = document.createElement('tr');
                            const rollCol = document.createElement('td');
                            rollCol.appendChild(document.createTextNode(`${student.rollNo}  `));
                            const nameCol = document.createElement('td');
                            nameCol.appendChild(document.createTextNode(`${student.name}  `));
                            const marksCol = document.createElement('td');
                            marksCol.appendChild(document.createTextNode(`${student.marks}  `));
                            
                            listItem.appendChild(rollCol);
                            listItem.appendChild(nameCol);
                            listItem.appendChild(marksCol);
                            studentListElement.appendChild(listItem);
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching data:", error);
                    }
                });
        }

        const submitButton = document.getElementById('submitMarksButton');
        submitButton.addEventListener('click', () => {
            // Create an array of student marks and their identifiers
            const marksList = [];
            for (const studentId in studentMarks) {
                marksList.push({ id: studentId, marks: studentMarks[studentId] });
            }
            console.log(marksList);
            console.log(studentMarks);

            $.ajax({
                    url: 'examAPI.php/submitMarks',
                    type: "POST",
                    dataType: "json", // Corrected option name
                    data: JSON.stringify(marksList), // Corrected option name
                    contentType: "application/json", 
                    body: JSON.stringify(marksList),
                    success: function(data) {
                        console.log(data);
                        alert("Marks updated successfully. Redirecting...");
                        window.location="StaffLogin.php";
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching data:", error);
                    }
                });
        })

    </script>
<?php
   }
?>
