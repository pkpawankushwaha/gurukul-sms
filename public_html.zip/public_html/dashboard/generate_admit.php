<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
	
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="vendors/linericon/style.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
         <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
        <link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
        <link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
        <link rel="stylesheet" href="vendors/animate-css/animate.css">
        <link rel="stylesheet" href="vendors/popup/magnific-popup.css">
       

        <!-- main css -->
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/responsive.css">

        <!--fonts -->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Anton">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Pacifico">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
	    <link href='https://fonts.googleapis.com/css?family=Codystar' rel='stylesheet'>
	    <link href='https://fonts.googleapis.com/css?family=Nosifer' rel='stylesheet'>
	    <link href='https://fonts.googleapis.com/css?family=Kavoon' rel='stylesheet'>
	    <link href='https://fonts.googleapis.com/css?family=Eater' rel='stylesheet'>
	 	<link href='https://fonts.googleapis.com/css?family=Monofett' rel='stylesheet'>
	    <link href='https://fonts.googleapis.com/css?family=Rock Salt' rel='stylesheet'>
	    <link href='https://fonts.googleapis.com/css?family=Atomic Age' rel='stylesheet'>


		
	</head>

	<body>
		
		
		

		<?php 
		include "connection.php";
			$class=$_POST["class"];
		    echo $class."Click on link to open"."\n\n";
			$res=mysqli_query($link,"select * from student where class2023='$class'");
			$count=mysqli_num_rows($res);
            $start=1;$end=0;
            $c=$count;
            $a=1;
            
            while($start<=$c){
                $end= min($start+9,$c);
                echo "\n";
                ?>
                    <a href="http://gsshskhampar.000webhostapp.com/dashboard/generate_admit1.php?class=<?php echo $class ?>&st=<?php echo $start; ?>&e=<?php echo $end; ?>" target="_blank">Page <?php echo $a; ?></a>
                <?php
                $start=$start+10;
                $a+=1;
            }
        ?>