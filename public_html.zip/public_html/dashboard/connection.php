<?php
try{
    // echo "loooo";
$link = mysqli_connect("localhost", "u897085281_school", "Passw0r4", "u897085281_school");
// echo "done";
} catch(Exception $e){
    echo $e;
}

?>