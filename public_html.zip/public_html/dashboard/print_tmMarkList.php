<html>
    <head>
        <style>
            .resultTable {
                border: 1px black solid;
            }
            .resultTable td {
                border: 1px black solid;
            }
            .resultTable th {
                border: 1px black solid;
            }
        </style>
    </head>
    <body>
<?php
            include "connection.php";
            $class=$_GET["class"];
            // $sort=$_GET["sort"];
            $result = fetchClassResultHY($link, $class);

            // $resultY = fetchClassResultY($link, $class);

            
            
            // $rankMarks = array();

            // //Iterate through $result and calculate total marks
            // foreach ($result as $student) {
            //     $adm_no = $student->adm_no;
            //     $rankMarks[$adm_no] = $student->total;
            // }
            
            // // Iterate through $resultY and add total marks
            // foreach ($resultY as $student) {
            //     $adm_no = $student->adm_no;
            //     if (isset($rankMarks[$adm_no])) {
            //         $rankMarks[$adm_no] += $student->total;
            //     } else {
            //         $rankMarks[$adm_no] = $student->total;
            //     }
            // }
            // uasort($rankMarks, function($a, $b) {
            //     return $b - $a; // Sort in descending order
            // });
            
            
            // $ranks = array(); // You can replace this with a map

            // $rank = 1;
            // $prev_total = null;
            
            // foreach ($rankMarks as $adm_no => $total) {
            //     if ($total !== $prev_total) {
            //         $rank = count($ranks) + 1;
            //     }
            //     $ranks[$adm_no] = $rank; // Store rank along with admission number in the map
                
            //     $prev_total = $total;
            // }

            // if($sort==1) {
            //     usort($result, 'comparator');
            // }
            echo "<b>Result MarksList - Class : ".$class."</b><br>";
            function comparator($student1, $student2) {
                return $student1->total < $student2->total;
            }

            function comparatorRollNo($student1, $student2) {
                return $student1->rollNo > $student2->rollNo;
            }

            $i=0;
            ?>
                <table class="resultTable">
            <?php
            printHeader($result[0]);
            while($i<count($result)){
                printResult($result[$i], $result[$i], $ranks[$result[$i]->adm_no]);$i+=1;
            }

            class Marks {
                public $marks;
                public $mm;
                public $subject;
            
                public function __construct($marks, $mm, $subject) {
                    $this->marks = $marks;
                    $this->mm = $mm;
                    $this->subject = $subject;
                }
            }
            
            
            class StudentResult {
                public $adm_no;
                public $class;
                public $rollNo;
                public $name;
                public $fname;
                public $marks;
                public $total;
                public $max;
                public $percentage;
                public $rank;
            
                public function __construct($adm_no, $class, $rollNo, $name, $fname, $marks, $total, $max, $percentage, $rank) {
                    $this->adm_no = $adm_no;
                    $this->name = $name;
                    $this->fname = $fname;
                    $this->marks = $marks;
                    $this->class = $class;
                    $this->rollNo = $rollNo;
                    $this->total = $total;
                    $this->max = $max;
                    $this->percentage = $percentage;
                    $this->rank = $rank;
                }
            }
            
            class Subject {
                public $code;
                public $name;
            
                public function __construct($code, $name) {
                    $this->name = $name;
                    $this->code = $code;
                }
            }
            function printHeader($studentResult) {
                ?>
                <tr>
                    <th>RollNo.</th>
                    <th>AdmNo.</th>
                    <th>Name</th>
                    <th>Father's Name</th>
                    <?php
                        for($i=0;$i<count($studentResult->marks);$i++) {
                            echo "<th>".$studentResult->marks[$i]->subject."</th>";
                        }
                    ?>
                    <th>ExamTotal</th>
                    <!--<th>Total</th>-->
                    <!--<th>Rank</th>-->
                </tr>
                <tr>
                    <th> - </th>
                    <th> - </th>
                    <th> - </th>
                    <th> - </th>
                    <?php
                        for($i=0;$i<count($studentResult->marks);$i++) {
                            echo "<th>"."50"."</th>";
                        }
                    ?>
                    <th><?php echo (count($studentResult->marks)*50); ?></th>
                    <!--<th><?php echo (count($studentResult->marks)*50)*2; ?></th>-->
                    <!--<th> - </th>-->
                </tr>
                <?php
            }
            function printResult($studentResult, $studentResultY, $rank) {
                
                ?>
                <tr>
                    <td ><?php echo $studentResult->rollNo; ?></td>
                    <td ><?php echo $studentResult->adm_no; ?></td>
                    <td ><?php echo $studentResult->name; ?></td>
                    <td ><?php echo $studentResult->fname; ?></td>
                    <?php
                        for($i=0;$i<count($studentResult->marks);$i++) {
                            echo "<td>".$studentResult->marks[$i]->marks."</td>";
                        }
                    ?>
                    <td><?php echo $studentResult->total; ?></td>
                    <!--<td ><?php echo $studentResult->total + $studentResultY->total; ?></td>-->
                    <!--<td rowspan="2"><?php echo $rank ?>-->
                </tr>
                <tr>
                    <?php
                        // for($i=0;$i<count($studentResultY->marks);$i++) {
                        //     echo "<td>".$studentResultY->marks[$i]->marks."</td>";
                        // }
                    ?>
                    <!--<td><?php echo $studentResultY->total; ?></td>-->
                </tr>
                <?php
            }

            function fetchClassResultHY($link, $class) {
                $subjects = fetchSubjects($link, $class);
                $subCode = "sub1";
                $exam = '`exam2024tm`';
                $exam_sub = "";
                for($i=0;$i<count($subjects);$i++) {
                    $exam_sub = $exam_sub."".$exam.".`".$subjects[$i]->code."`, ";
                }
                $query = "select `student`.`adm_no`, `student`.`class2024`, `student`.`roll2024`,  $exam_sub `student`.`name`,`student`.`father_name` FROM `student` INNER JOIN $exam WHERE `student`.`adm_no` = $exam.`adm_no` AND `student`.`class2024`='$class' ORDER BY `student`.`roll2024` ASC";
                $resStudents = mysqli_query($link, $query);
                $studentsList = array();
                $mm = 50;
                if($class=='IX A')
                    $mm=50;
                while ($row = mysqli_fetch_array($resStudents)) {
                    $marks = [];
                    $total = 0;
                    for($i=0;$i<count($subjects);$i++) {
                       $score = $row[$subjects[$i]->code];
                       if($score>$mm || $score<0) $score = 'A';
                       if($score!=='A') $total += $score;
                       $marks[] = new Marks($score, $mm, $subjects[$i]->name);
                    }
                    $max = count($marks)*$mm;
                    $percentage = round($total/($max)*100, 2);
                    $studentsList[] = new StudentResult($row['adm_no'], $row["class2024"], $row["roll2024"], $row['name'], $row['father_name'], $marks, $total, $max, $percentage, 0);
                }
                usort($studentsList, 'comparator');
                $rank=1;
                $studentsList[0]->rank=1;
                for($i=2;$i<=count($studentsList);$i++) {
                    if($studentsList[$i-1]->total<$studentsList[$i-2]->total) {
                        $rank = $rank + 1;
                    }
                    $studentsList[$i-1] -> rank = $rank;
                }
                usort($studentsList, 'comparatorRollNo');
                return $studentsList;
            }

            function fetchClassResultY($link, $class) {
                $subjects = fetchSubjects($link, $class);
                $subCode = "sub1";
                $exam = '`exam2023y`';
                $exam_sub = "";
                for($i=0;$i<count($subjects);$i++) {
                    $exam_sub = $exam_sub."".$exam.".`".$subjects[$i]->code."`, ";
                }
                $query = "select `student`.`adm_no`, `student`.`class2023`, `student`.`roll2023`,  $exam_sub `student`.`name`,`student`.`father_name` FROM `student` INNER JOIN $exam WHERE `student`.`adm_no` = $exam.`adm_no` AND `student`.`class2023`='$class' ORDER BY `student`.`roll2023` ASC";
                $resStudents = mysqli_query($link, $query);
                $studentsList = array();
                $mm = 50;
                if($class=='IX A')
                    $mm=100;
                while ($row = mysqli_fetch_array($resStudents)) {
                    $marks = [];
                    $total = 0;
                    for($i=0;$i<count($subjects);$i++) {
                       $score = $row[$subjects[$i]->code];
                       if($score>$mm || $score<0) $score = 'A';
                       if($score!=='A') $total += $score;
                       $marks[] = new Marks($score, $mm, $subjects[$i]->name);
                    }
                    $max = count($marks)*$mm;
                    $percentage = round($total/($max)*100, 2);
                    $studentsList[] = new StudentResult($row['adm_no'], $row["class2023"], $row["roll2023"], $row['name'], $row['father_name'], $marks, $total, $max, $percentage, 0);
                }
                usort($studentsList, 'comparator');
                $rank=1;
                $studentsList[0]->rank=1;
                for($i=2;$i<=count($studentsList);$i++) {
                    if($studentsList[$i-1]->total<$studentsList[$i-2]->total) {
                        $rank = $rank + 1;
                    }
                    $studentsList[$i-1] -> rank = $rank;
                }
                usort($studentsList, 'comparatorRollNo');
                return $studentsList;
            }

            function fetchSubjects($link, $class) {
                $query = "select subjectCode, subjectName from classsubject where `class`='$class'";
                $resSubjects = mysqli_query($link, $query);
                $subList = array();
            
                while ($row = mysqli_fetch_array($resSubjects)) {
                    $subList[] = new Subject($row['subjectCode'], $row['subjectName']);
                }
                return $subList;
            }


    
?>
</table>
</body>
</html>