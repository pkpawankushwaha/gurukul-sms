<?php
    session_start();
	unset($_SESSION["teacher_user"]);
	?>
	
	<script type="text/javascript">
		alert("You have Logged out Successfully");
	  window.location="StaffLogin.php";
	 </script>
	 Logged Out