<?php
  include "header.php";
   if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
      $mon = array("04", "05", "06","07", "08", "09","10", "11", "12", "01", "02", "03");
      $yearT=0;
      $session=$_GET['session'];
      $monCount = 0;
      $sqlQuery;
      $yearT=0;
      ?>
      <table border=1 width=100%>
        <th>Months</th><th>Fee</th><tr>
            <?php
      while($monCount<12) {
      $monFormat;
      switch ($session) {
        case 'reciept2024':
            $classCol = 'class2023';
            if($monCount<9)
            $monFormat = $mon[$monCount]."/2023";
            else 
            $monFormat = $mon[$monCount]."/2024";
            $monFormatted = "%".$monFormat."%";
            $sqlQuery = "SELECT * FROM reciept2024 INNER JOIN student ON reciept2024.adm_no = student.adm_no WHERE student.class2023 IN ('I A', 'I B', 'II A', 'II B', 'III A', 'III B', 'IV A', 'IV B', 'V A', 'V B') and date LIKE '$monFormatted' ORDER BY date ASC";
            break;
        case 'reciept2023':
            $classCol = 'class2022';
            if($monCount<9)
            $monFormat = $mon[$monCount]."/2022";
            else 
            $monFormat = $mon[$monCount]."/2023";
            $monFormatted = "%".$monFormat."%";
            $sqlQuery = "SELECT * FROM reciept2023 INNER JOIN student ON reciept2023.adm_no = student.adm_no WHERE student.class2022 IN ('I A', 'I B', 'II A', 'II B', 'III A', 'III B', 'IV A', 'IV B', 'V A', 'V B') and date LIKE '$monFormatted' ORDER BY date ASC";
            break;
        case 'reciept2022':
            $classCol = 'class2021';
            if($monCount<9)
            $monFormat = $mon[$monCount]."/2021";
            else 
            $monFormat = $mon[$monCount]."/2022";
            $monFormatted = "%".$monFormat."%";
            $sqlQuery = "SELECT * FROM reciept2022 INNER JOIN student ON reciept2022.adm_no = student.adm_no WHERE student.class2021 IN ('I A', 'I B', 'II A', 'II B', 'III A', 'III B', 'IV A', 'IV B', 'V A', 'V B') and date LIKE '$monFormatted' ORDER BY date ASC";
            break;
      }
   ?>
   
        <?php 
            $date = 1;
            $totalM=0;
            while($date<=31) {
              $c=1;
              $res1=mysqli_query($link, $sqlQuery);
              $count=mysqli_num_rows($res1);
              $totalt=0;$totalc=0;$totalo=0;
              $dateFormatted = "";
              if($date<10) $dateFormatted ="0";
              $dateFormatted = $dateFormatted.$date."/".$monFormat;
              while($c<=$count)
              {    
                $row=mysqli_fetch_array($res1);
                if($row['date'] == $dateFormatted) {
                   $otherfee=$row["form"]+$row["idcard"]+$row["tie_belt"]+$row["adm_fee"]+$row["exam1"]+$row["exam2"]+$row["exam3"]+$row["result_card"];
                      $totalt+=$row["t_m_amt"];$totalc+=$row["c_m_amt"];$totalo+=$otherfee;
                }
                $c+=1;
              }
              $date +=1;
              $totalM = $totalM + ($totalt+$totalc+$totalo);
            }
            $yearT = $yearT + $totalM;
            echo "<td>$monFormat</td><td>".($totalM)."</td><tr>";
            $monCount+=1;
        }
        echo "<td><b>Total</b></td><td><b>".($yearT)."</b></td><tr>";
        echo "</table>";
        
    }
        ?>

    </table>