<?php
  include "header.php";
   if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
      $mon=$_GET['mon'];
      $session=$_GET['session'];
      $sqlQuery;
      $monFormat = "%".$mon."%";
      switch ($session) {
        case 'reciept2024':
            $classCol = 'class2023';
            $sqlQuery = "SELECT * FROM reciept2024 INNER JOIN student ON reciept2024.adm_no = student.adm_no WHERE student.class2023 IN ('I A', 'I B', 'II A', 'II B', 'III A', 'III B', 'IV A', 'IV B', 'V A', 'V B') and date LIKE '$monFormat' ORDER BY date ASC";
            break;
        case 'reciept2023':
            $classCol = 'class2022';
            $sqlQuery = "SELECT * FROM reciept2023 INNER JOIN student ON reciept2023.adm_no = student.adm_no WHERE student.class2022 IN ('I A', 'I B', 'II A', 'II B', 'III A', 'III B', 'IV A', 'IV B', 'V A', 'V B') and date LIKE '$monFormat' ORDER BY date ASC";
            break;
        case 'reciept2022':
            $classCol = 'class2021';
            $sqlQuery = "SELECT * FROM reciept2022 INNER JOIN student ON reciept2022.adm_no = student.adm_no WHERE student.class2021 IN ('I A', 'I B', 'II A', 'II B', 'III A', 'III B', 'IV A', 'IV B', 'V A', 'V B') and date LIKE '$monFormat' ORDER BY date ASC";
            break;
      }

    $res=mysqli_query($link, $sqlQuery);
   ?>
   <table border=1 width=100%>
        <th>N.</th><th>Date</th><th>Rec.No.</th><th>Adm.No.</th><th>Name</th><th>Class</th><th>Fee</th><tr>
        <?php 
            $c=1;
            $count=mysqli_num_rows($res);
            $totalt=0;$totalc=0;$totalo=0;
            while($c<=$count)
            {    $row=mysqli_fetch_array($res);
                $otherfee=$row["form"]+$row["idcard"]+$row["tie_belt"]+$row["adm_fee"]+$row["exam1"]+$row["exam2"]+$row["exam3"]+$row["result_card"];
                
                    $totalt+=$row["t_m_amt"];$totalc+=$row["c_m_amt"];$totalo+=$otherfee;
                    
                echo "<td>".$c."</td><td>".$row["date"]."</td><td>".$row["rec_no"]."</td><td>".$row["adm_no"]."</td><td>".$row["name"]."</td><td>".$row[$classCol]."</td>
                        <td>".($otherfee+$row["t_m_amt"]+$row["c_m_amt"])."</td><tr>";
                $c+=1;
            }
            echo "<td><b>Total</b></td><td><b>".($totalc+$totalo+$totalt)."</b></td><tr>";
            echo "</table>";
        }
        ?>

    </table>