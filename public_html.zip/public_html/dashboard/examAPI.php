<?php
include "connection.php";
// Set the response content type to JSON
header("Content-Type: application/json");

// Determine the API endpoint based on the request method and path
$endpoint = $_SERVER['REQUEST_METHOD'] .' /'. basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

$table = isset($_GET['table']) ? urldecode($_GET['table']) : 0;
$class = isset($_GET['class']) ? urldecode($_GET['class']) : 0;
$subCode = isset($_GET['subCode']) ? urldecode($_GET['subCode']) : 0;

$teacherName = isset($_GET['teacherName']) ? urldecode($_GET['teacherName']) : 0;
$mobNumber = isset($_GET['mobNumber']) ? urldecode($_GET['mobNumber']) : 0;

// Handle different API endpoints
if ($endpoint === "GET /classList") {
    $data = array(
        "message" => "ClassList",
        "classList" => fetchClassList($link),
        "timestamp" => time()
    );
} elseif ($endpoint === "GET /subjects") {
    $data = array(
        "message" => "Subjects",
        "timestamp" => time(),
        "subjects" => fetchSubjects($link, $class),
        "class" => "select subjectCode, subjectName from classsubject where `class`='$class'"
    );
} elseif ($endpoint === "GET /markList") {
    $data = array(
        "message" => "Marklist",
        "subject" => time(),
        "students" => fetchMarkList($link, $table, $class, $subCode)
    );
} elseif ($endpoint === "GET /addTeacher") {
    $data = array(
        "message" => "AddTeacher",
        "subject" => time(),
        "res" => addTeacher($link, $teacherName, $mobNumber)
    );
} elseif ($endpoint === "POST /submitMarks") {
    $requestData = json_decode(file_get_contents('php://input'), true);
    $submitMarksData = ($requestData);
    $data = submitMarks($link, $submitMarksData);
} else {
    $data = array(
        "error" => "Invalid API endpoint.",
        "endpoint" => $endpoint,
        "url" => basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH))
    );
}

class Subject {
    public $code;
    public $name;

    public function __construct($code, $name) {
        $this->name = $name;
        $this->code = $code;
    }
}

class Student {
    public $adm_no;
    public $class;
    public $rollNo;
    public $name;
    public $marks;
    public $subCode;

    public function __construct($adm_no, $class, $rollNo, $name, $marks, $subCode) {
        $this->adm_no = $adm_no;
        $this->name = $name;
        $this->subCode = $subCode;
        $this->marks = $marks;
        $this->class = $class;
        $this->rollNo = $rollNo;
        
    }
}


function fetchClassList($link) {
    $resClass = mysqli_query($link,"select class from class");
    $classList = array();

    while ($row = mysqli_fetch_array($resClass)) {
        $classList[] = $row['class'];
    }
    return $classList;
}

function fetchSubjects($link, $class) {
    $query = "select subjectCode, subjectName from classsubject where `class`='$class'";
    $resSubjects = mysqli_query($link, $query);
    $subList = array();

    while ($row = mysqli_fetch_array($resSubjects)) {
        $subList[] = new Subject($row['subjectCode'], $row['subjectName']);
    }
    return $subList;
}

function fetchMarkList($link, $exam, $class, $subCode) {
    $exam_sub = $exam.".`".$subCode."`";
    $query = "select `student`.`adm_no`, `student`.`class2024`, `student`.`roll2024`, `student`.`name`, $exam_sub FROM `student` INNER JOIN $exam WHERE `student`.`adm_no` = $exam.`adm_no` AND `student`.`class2024`='$class' ORDER BY `student`.`roll2024` ASC";
    $resStudents = mysqli_query($link, $query);
    $studentsList = array();

    while ($row = mysqli_fetch_array($resStudents)) {
        if($row[$subCode] === "-1") $row[$subCode] = "A";
        $studentsList[] = new Student($row['adm_no'], $row['class2024'], $row['roll2024'], $row['name'], $row[$subCode], $subCode);
    }
    return $studentsList;
}


function addTeacher($link, $teacherName, $mobNumber) {
    $query = "INSERT INTO teacher (name, contact1, acct_access, cashinhand, password) 
          VALUES ('$teacherName', '$mobNumber', '0', '0', '$mobNumber')";
    $res = mysqli_query($link, $query);
    return 'SUCCESS';
}

function submitMarks($link, $submitMarksData) {
    
    if($submitMarksData['marklist']) {
        
        foreach ($submitMarksData['marklist'] as $studentMark) {
            $adm_no = $studentMark['marks']['adm_no'];
            $subCode = $studentMark['marks']['subCode'];
            $mark = $studentMark['marks']['marks'];
            $query = 'UPDATE '. $submitMarksData['exam'] .' SET '.$subCode.' = '.$mark.' where adm_no = '. $adm_no;
            mysqli_query($link, $query);
        }
    }
    return array(
        "message" => "Marklist",
        "subject" => time(),
        "data" => $submitMarksData
    );
}

// Convert the data array to JSON format
$response = json_encode($data);

// Send the JSON response
echo $response;
?>
