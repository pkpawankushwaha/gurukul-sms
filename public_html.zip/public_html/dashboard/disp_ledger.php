<?php
  include "header.php";
  include "connection.php";
  if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Student Ledger</h2>
            </div>
          </header>
    <div class="container"><br>
      <div class="row bg-white">

      	<div class="col-md-4">
      		<center><h4>Tuition Fee</h4></center><br>
      		<div class="table-responsive">
    			<table class="table">
    			<thead>
    				<tr>
    					<th>Month</th><th>Status</th><th>Date</th><th>Rec.No.</th>
    				</tr>

    			</thead></table>
  			  </div>
      	</div>


		<div class="col-md-4">
      		<center><h4>Other Fee</h4></center><br>
      		<div class="table-responsive">
    			<table class="table">
    			<thead>
    				<tr>
    					<th>Month</th><th>Status</th><th>Date</th><th>Rec.No.</th>
    				</tr>

    			</thead></table>
  			  </div>
      	</div>


      	<div class="col-md-4">
      		<center><h4>Conveyance Fee</h4></center><br>
      		<div class="table-responsive">
    			<table class="table">
    			<thead>
    				<tr>
    					<th>Month</th><th>Status</th><th>Date</th><th>Rec.No.</th>
    				</tr>

    			</thead></table>
  			  </div>
      	</div>


      	
      </div>
  </div>
<?php
}
?>