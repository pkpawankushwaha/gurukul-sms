<?php

    $class=$_GET["class"];
    $start=$_GET["st"];
    $end=$_GET["e"];
    
    include "connection.php";
			
		
			$res=mysqli_query($link,"select * from student where class2023='$class' ORDER BY roll2023");
			$count=mysqli_num_rows($res);
			
			for($i=1;$i<$start;$i++){
			    $row=mysqli_fetch_array($res);
			}
			
			for($i=$start;$i<=$end;$i++){
			    $row=mysqli_fetch_array($res);
			  if($i%2==1){

					?>
						<div style="width:20.5cm;height:5.95cm">
						<div style="float: left;width: 10cm;height:5.95cm;align-content: center;text-align: center;">

							<table border="1" style="width: 10cm;height: 5.95cm;">
									<tr>
										<td style="text-align: center;">
											Gurukul Shikshan Sansthan<br>
											Khampar(Jaipur), Deoria(U.P.)<br>
											Yearly Examination 2023-24<br>
										</td>
									</tr>
									
									<tr>
										<td>
											<center><u><b>Admit Card</b></u><br>
											<div style="float:left;margin-left: 10px;"> 
												Name : <?php echo $row["name"]; ?>
											</div>
											<div style="float:right;margin-right: 20px;"> 
												Class: <?php echo $row["class2023"]; ?>
											</div>
											<br>
											<div style="float:left;margin-left: 10px;"> 
												AdmNo. : <?php echo $row["adm_no"]; ?>
											</div>
											<div style="float:right;margin-right: 20px;"> 
												RollNo. <?php echo $row["roll2023"]; ?>
											</div>
											<br>
											<div style="float:left;margin-left: 10px;">
												Father's Name : <?php echo $row["father_name"]; ?>
											</div>
										   </center><br>

										<div style="float: right;padding: 5px;margin-right: 20px;margin-bottom: 10px;">
											<b>Principal</b>
										</div>

										</td>

									</tr>
									
								</table>

						</div>
					<?php


				}
				else if($i%2==0){

						?>
						<div style="float: right;width: 10cm;height:5.95cm;align-content: center;text-align: center;">

						<table border="1" style="width: 10cm;height: 5.95cm">
							<tr>
								<td style="text-align: center;">
								    Gurukul Shikshan Sansthan<br>
									Khampar(Jaipur), Deoria(U.P.)<br>
									Yearly Examination 2023-24<br>
								</td>
							</tr>
							
							<tr>
								<td>
									<center><u><b>Admit Card</b></u><br>
									<div style="float:left;margin-left: 10px;"> 
										Name : <?php echo $row["name"]; ?>
									</div>
									<div style="float:right;margin-right: 20px;"> 
										Class: <?php echo $row["class2023"]; ?>
									</div>
									<br>
									<div style="float:left;margin-left: 10px;"> 
										AdmNo. : <?php echo $row["adm_no"]; ?>
									</div>
									<div style="float:right;margin-right: 20px;"> 
										RollNo. <?php echo $row["roll2023"]; ?>
									</div>
									<br>
									<div style="float:left;margin-left: 10px;">
										Father's Name : <?php echo $row["father_name"]; ?>
									</div>
								   </center><br>

								<div style="float: right;padding: 5px;margin-right: 20px;margin-bottom: 10px;">
									<b>Principal</b>
								</div>

								</td>
							</tr>
							
							</table>

						</div>
					</div>
						<?php
				}
				
				
				


			}
			
			
            
           
    ?>