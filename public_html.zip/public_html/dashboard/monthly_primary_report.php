<?php
  include "header.php";
  include "connection.php";
  if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Monthly Primary Report</h2>
            </div>
          </header>
    


    <div class="container-fluid">
      <br>
<form name="form1" class="form" action="" method="post">
	   <center><input type="text" name="mon" class=form-control placeholder="Month mm/yyyy" >
       <select name="session" class="form-control">
            <option value="reciept2024">2023-24</option>
            <option value="reciept2023">2022-23</option>
            <option value="reciept2022">2021-22</option>
            <option value="reciept2021">2020-21</option>
        </select>
        <select name="class" class="form-control">
            <option value="primary">PRIMARY</option>
        </select>
	   <input type="submit" name="submit" value="Submit" class="btn btn-primary"></center>
	  </form>
	  <center>
	  <?php 
	     
		 if(!isset($_POST["submit"]))
		  {
			  
		     
		  }
		  else
		  { 
	         $mon=$_POST["mon"];
             $session=$_POST["session"];
	         
		 ?>
		 <br><br><br>
		  <a href="monthly_transact.php?mon=<?php echo $mon; ?>&session=<?php echo $session; ?>" target=_blank class="btn btn-primary">Monthly Report</a>
          <a href="monthly_datewise_transact.php?mon=<?php echo $mon; ?>&session=<?php echo $session; ?>" target=_blank class="btn btn-primary">Monthly Datewise Report</a>
  <?php
		  }
		}
     include "footer.php";
	 ?>