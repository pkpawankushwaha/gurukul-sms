<?php
  include "header.php";
   if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Update Student Details</h2>
            </div>
          </header>
    <div class="container bg-white">

               
    <form name="form1" class="form" action="" method="post">
    <div class="form-group row">
      <div class="col-md-4"></div>
      <div class="col-md-2">Adm No.</div>
        <div class="col-md-2">
          <input type="text" name="adm_no">
        </div></div>
    
    <center><input type="submit" class="btn btn-primary" name="submit1"></center>
    </form><br>
  
  <?php

                if(!isset($_POST["submitConveyance"]))
                     {} else{
                      
                      $sqlQ = "UPDATE student SET conveyance2025='YES' WHERE adm_no = '$_POST[adm_no]'";
                      mysqli_query($link, $sqlQ);
                      mysqli_query($link,"insert into conveyance2025 values('$_POST[adm_no]','$_POST[adm_no]','$_POST[con_fee]','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0')");
                      echo "UPDATED";
                     }

                     if(!isset($_POST["submitClassRoll"]))
                     {} else{
                      echo $_POST["adm_no"]." Class : ".$_POST["class"]."   Roll : ".$_POST["roll"];
                      
                      $sqlQ = "UPDATE student SET class2024='$_POST[class]', roll2024='$_POST[roll]' WHERE adm_no = '$_POST[adm_no]'";
                      mysqli_query($link, $sqlQ);

                     }
                     
                     if(!isset($_POST["submitName"]))
                     {} else{
                      echo $_POST["adm_no"]." Class : ".$_POST["name"];
                      
                      $sqlQ = "UPDATE student SET name='$_POST[name]' WHERE adm_no = '$_POST[adm_no]'";
                      mysqli_query($link, $sqlQ);

                     }
     if(!isset($_POST["submit1"]))
       {
         
              
       }
         else
         {     

               $res1=mysqli_query($link,"select * from student where adm_no='$_POST[adm_no]'");
               $row=mysqli_fetch_array($res1);
               $update_link = "/dashboard/update_st.php?adm=".$_POST["adm_no"];
              
               ?>
               
               <a href=<?php echo $update_link ?>>Update Student details</a>
                <?php echo "Name : ".$row["name"]." AdmNo. : ".$_POST["adm_no"]."  Conveyance : ".$row["conveyance2025"]."    Class : ".$row["class2024"]."  Roll No. : ".$row["roll2024"]."<br></p>"; 

                if($row["conveyance2025"]=="0"||$row["conveyance2025"]=="NO"){
                  ?>
                    <form name="form1" class="form" action="" method="post">
                      <div class="form-group row">
                        <div class="col-md-4"></div>
                        <div class="col-md-2">Conveyance Fee : </div>
                          <div class="col-md-2">
                            <input type="text" name="adm_no" hidden="" value=<?php echo $_POST["adm_no"];?> >
                            <input type="text" name="con_fee">
                          </div></div>
                      
                        <center><input type="submit" class="btn btn-primary" name="submitConveyance">
                        </center>
                      </form>
                      <?php                    
                    }
                  
                ?>

                <form name="form1" class="form" action="" method="post">
                      <div class="form-group row">
                        <div class="col-md-4"></div>
                        <div class="col-md-2">Class && Roll No. : </div>
                          <div class="col-md-2">
                            <input type="text" name="adm_no" hidden="" value=<?php echo $_POST["adm_no"];?> >
                            <input type="text" name="class" placeholder="Class">
                            <input type="text" name="roll" placeholder="Roll No.">
                          </div></div>
                      
                        <center><input type="submit" class="btn btn-primary" name="submitClassRoll">
                        </center>
                </form>
                      
                      
               <?php
           
       }
       echo "</center>";
     }
     include "footer.php";
   
   ?>