<?php
  include "header.php";
  include "connection.php";
  if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Daily Report</h2>
            </div>
          </header>
    


    <div class="container-fluid">
      <br>
<form name="form1" class="form" action="" method="post">
	   <center><input type="text" name="date" class=form-control placeholder="Date dd/mm/yyyy" >
	   <input type="submit" name="submit" value="Submit" class="btn btn-primary"></center>
	  </form>
	  <center>
	  <?php 
	     
		 if(!isset($_POST["submit"]))
		  {
			  
		     
		  }
		  else
		  { 
	         $date=$_POST["date"];
	         $res=mysqli_query($link,"select * from  reciept where date='$date'");
			 $crec=mysqli_num_rows($res);
			 $res_adm=mysqli_query($link,"select * from  student where doa='$date'");
			 $cadm=mysqli_num_rows($res_adm);
			 $c_old_st=0;$c_new_st=0;
			 while($cadm>0)
			 {   $row=mysqli_fetch_array($res_adm);
				 if($row["sttype"]=="NEW")
					 $c_new_st+=1;
				 else
					 $c_old_st+=1;
				 $cadm-=1;
			 }
			 $f_adm2=0;$f_adm=0;
			 echo "New Admission  :  ".$c_new_st."<br>Old Admission : ".$c_old_st."<br>Total No. of reciepts : ".$crec."<br><br><br>";
				while($crec>0)
				{
					$row=mysqli_fetch_array($res);
					if($row["teacher"]=="admin")
						$f_adm+=$row["total"];
					else
						$f_adm2+=$row["total"];
					$crec-=1;
				}
				
				
				$res=mysqli_query($link,"select * from  reciept2021 where date='$date'");
			 $crec=mysqli_num_rows($res);
			 while($crec>0)
				{
					$row=mysqli_fetch_array($res);
					if($row["teacher"]=="admin")
						$f_adm+=$row["total"];
					else
						$f_adm2+=$row["total"];
					$crec-=1;
				}
				
				$res=mysqli_query($link,"select * from  reciept2022 where date='$date'");
			 $crec=mysqli_num_rows($res);
			 while($crec>0)
				{
					$row=mysqli_fetch_array($res);
					if($row["teacher"]=="admin")
						$f_adm+=$row["total"];
					else
						$f_adm2+=$row["total"];
					$crec-=1;
				}
				$res=mysqli_query($link,"select * from  reciept2023 where date='$date'");
			 $crec=mysqli_num_rows($res);
			 while($crec>0)
				{
					$row=mysqli_fetch_array($res);
					if($row["teacher"]=="admin")
						$f_adm+=$row["total"];
					else
						$f_adm2+=$row["total"];
					$crec-=1;
				}
				
				$res=mysqli_query($link,"select * from  reciept2024 where date='$date'");
			 $crec=mysqli_num_rows($res);
			 while($crec>0)
				{
					$row=mysqli_fetch_array($res);
					if($row["teacher"]=="admin")
						$f_adm+=$row["total"];
					else
						$f_adm2+=$row["total"];
					$crec-=1;
				}
				
					$res=mysqli_query($link,"select * from  reciept2025 where date='$date'");
			 $crec=mysqli_num_rows($res);
			 while($crec>0)
				{
					$row=mysqli_fetch_array($res);
					if($row["teacher"]=="admin")
						$f_adm+=$row["total"];
					else
						$f_adm2+=$row["total"];
					$crec-=1;
				}
			echo "Fees Paid by admin : ".$f_adm."<br>";
			echo "Fees Paid by admin2 : ".$f_adm2."<br>";
			echo "Toatal Fee Paid : ".($f_adm+$f_adm2);
			
			
			 
			 
			 
			 
		 
		 
		 ?>
		 <br><br><br>
		  <a href="daily_transact.php?date=<?php echo $date; ?>" target=_blank class="btn btn-primary">Click here to See Detailed Report </a>
		  <a href="daily_transact_primary.php?date=<?php echo $date; ?>" target=_blank class="btn btn-primary">Click here to See Detailed Report (Primary) </a>
  <?php
		  }
		}
     include "footer.php";
	 ?>