<?php
  include "header.php";
   if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Reciept Status</h2>
            </div>
          </header>
    <div class="container bg-white"><br>
             <form name="form1" class="form" action="" method="post">
               <center><div class="form-group row">
                <div class="col-md-4"></div>
                <div class="col-md-4"><input type="text" name="rec" class="form-control form-control-sm" placeholder="Reciept No." ></div>
               <div class="col-md-4"><input type="submit" name="submit" value="Submit" class="btn btn-primary"></div>
             </div>
              </center>
            </form>
              <center>
            <?php 
       
     if(!isset($_POST["submit"]))
      {
        
         
      }
      else
      { 
           $rec=$_POST["rec"];
           echo $rec[2];
           if($rec[3]=='0')
       $res=mysqli_query($link,"select * from reciept2021 where rec_no='$rec'");
       if($rec[3]=='1')
       $res=mysqli_query($link,"select * from reciept2022 where rec_no='$rec'");
       else if($rec[3]=='2')
       $res=mysqli_query($link,"select * from reciept2023 where rec_no='$rec'");
       else if($rec[3]=='3')
       $res=mysqli_query($link,"select * from reciept2024 where rec_no='$rec'");
       else if($rec[3]=='4')
       $res=mysqli_query($link,"select * from reciept2025 where rec_no='$rec'");
       else $res=mysqli_query($link,"select * from reciept where rec_no='$rec'");
       
       $c=mysqli_num_rows($res);
       if($c==0)
         echo "<br><br> Reciept No. ".$_POST["rec"]." is not found";
       else 
           echo "<br><br><a href =reciept.php?rec=".$rec." target=_blank>Click here to Print Reciept</a>";
      }
      ?>
      </center>
    </div>






<?php
}
?>


<?php
  include "footer.php";
?>
          
          