<?php
    session_start();
	
   
    include "connection.php";
	if(!isset($_SESSION["teacher_user"]))
    {
    	echo "Access Denied Please Login";
    }
	else
	{

		echo "<h1>New Admissions <br> Session 2024-25</h1>";
		 
		$res=mysqli_query($link,"select * from student where adm_no>=20240000 and class2024!='0'");
		$c=mysqli_num_rows($res);
		
		?>
		
		<table border=1 >
		<th>N.</th><th>Adm.No.</th><th>Name </th><th>Father's Name</th><th>Mother's Name</th><th>Address</th><th>Class</th><tr>
		
		
		<?php $k=1;
		while($c>0)
		{
		   $row=mysqli_fetch_array($res);
		   echo "<td>".$k."</td><td>".$row["adm_no"]."</td><td>".$row["name"]."</td><td>".$row["father_name"]."</td><td>".$row["mother_name"]."</td><td>".$row["add1"]." ".$row["add2"]."</td><td>".$row["class2024"]."</td><tr>";
		   $k+=1;$c-=1;
		   
		}

		echo "</table><BR><BR><BR><BR>";
		echo "<h1>New Admissions <br> Session 2023-24</h1>";
		 
		$res=mysqli_query($link,"select * from student where adm_no>=20230000 and class2023!='0'");
		$c=mysqli_num_rows($res);
		
		?>
		
		<table border=1 >
		<th>N.</th><th>Adm.No.</th><th>Name </th><th>Father's Name</th><th>Mother's Name</th><th>Address</th><th>Class</th><tr>
		
		
		<?php $k=1;
		while($c>0)
		{
		   $row=mysqli_fetch_array($res);
		   echo "<td>".$k."</td><td>".$row["adm_no"]."</td><td>".$row["name"]."</td><td>".$row["father_name"]."</td><td>".$row["mother_name"]."</td><td>".$row["add1"]." ".$row["add2"]."</td><td>".$row["class2023"]."</td><tr>";
		   $k+=1;$c-=1;
		   
		}
		echo "</table><BR><BR><BR><BR>";
		
	    echo "<h1>New Admissions <br> Session 2022-23</h1>";
		 
		$res=mysqli_query($link,"select * from student where adm_no>=20220000 and class2022!='0'");
		$c=mysqli_num_rows($res);
		
		?>
		
		<table border=1 >
		<th>N.</th><th>Adm.No.</th><th>Name </th><th>Father's Name</th><th>Mother's Name</th><th>Address</th><th>Class</th><tr>
		
		
		<?php $k=1;
		while($c>0)
		{
		   $row=mysqli_fetch_array($res);
		   echo "<td>".$k."</td><td>".$row["adm_no"]."</td><td>".$row["name"]."</td><td>".$row["father_name"]."</td><td>".$row["mother_name"]."</td><td>".$row["add1"]." ".$row["add2"]."</td><td>".$row["class2022"]."</td><tr>";
		   $k+=1;$c-=1;
		   
		}
		
		echo "</table><br><BR><br><h1>Session 2021-22</h1>";
		$res=mysqli_query($link,"select * from student where adm_no>20210000 and adm_no<20220000");
		$c=mysqli_num_rows($res);
		
		?>
		
		<table border=1 >
		<th>N.</th><th>Adm.No.</th><th>Name </th><th>Father's Name</th><th>Mother's Name</th><th>Address</th><th>Class</th><tr>
		
		
		<?php $k=1;
		while($c>0)
		{
		   $row=mysqli_fetch_array($res);
		   echo "<td>".$k."</td><td>".$row["adm_no"]."</td><td>".$row["name"]."</td><td>".$row["father_name"]."</td><td>".$row["mother_name"]."</td><td>".$row["add1"]." ".$row["add2"]."</td><td>".$row["class2021"]."</td><tr>";
		   $k+=1;$c-=1;
		   
		}
		
		echo "</table><br>";
	}
	?>
	  </table>