<!DOCTYPE html>
<html>
<head>
    <title>Select Input Example</title>
    <style>
        .uList li {
            height: 80px;  
        }
        .uList input {
            height: 50px;  
        }
    </style>
</head>
<body>
    <h2>Select an option:</h2>
    
        <select name="classList" id="classList">
        <option value="Class"> Class </option>
        </select>
        <select name="subjects" id="subjects" style="display : none">
            <option value="Subject"> Subject </option>
        </select>
        <button id="btn">Submit</button>

        <div id="result"></div>

        <ul id="studentsList" class="uList">
        </ul>

        <button id="submitMarksButton">Submit Marks</button>


    <p id="result">Selected option will be displayed here.</p>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript">
        const studentMarks = {}; 
        $(document).ready(function() {
            fetchClassList();
            $("#subjects").hide();
            $("#btn").hide();
        });
        $("#classList").change(function() {
            var selectedClass = $("#classList").find(':selected').val();
            fetchSubjects(selectedClass);
            $("#subjects").show();
            $("#classList").prop("disabled", true);
        });
        $("#subjects").change(function() {
            $("#btn").show();
            $("#subjects").prop("disabled", true);
        });
        $("#btn").click(function() {
            $(this).prop("disabled", true);
            var selectedClass = $("#classList").find(':selected').val();
            var selectSub = $("#subjects").find(':selected').val();
            fetchMarkList(selectedClass, selectSub);
        });

        function fetchClassList() {
            
            $.ajax({
                    url: 'examAPI.php/classList',
                    type: "GET",
                    dataType: "json",
                    success: function(data) {
                        appendClassList(data.classList);
                        
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching data:", error);
                    }
                });
        }

        function appendClassList(classList) {

            if (classList.length > 0) {
                $.each(classList, function(index, className) {
                    var classListHTML = "<option value=" + encodeURIComponent(className) + ">" + (className) + "</option>";
                    $("#classList").append($(classListHTML));
                });
            }
        }

        function fetchSubjects(selectedClass) {
            $.ajax({
                    url: 'examAPI.php/subjects?class=' + encodeURIComponent(selectedClass),
                    type: "GET",
                    dataType: "json",
                    success: function(data) {
                        appendSubject(data.subjects)
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching data:", error);
                    }
                });
        }

        function appendSubject(subjectList) {

            if (subjectList.length > 0) {
                $.each(subjectList, function(index, subject) {
                    var classListHTML = "<option value=" + subject.code + ">" + subject.name + "</option>";
                    $("#subjects").append($(classListHTML));
                });
            }
        }

        function fetchMarkList(selectedClass, subject) {
            $.ajax({
                    url: 'examAPI.php/markList?class=' + encodeURIComponent(selectedClass) + '&subCode=' + subject,
                    type: "GET",
                    dataType: "json",
                    success: function(data) {
                        const studentListElement = document.getElementById('studentsList');
                        const students = data.students;
                        students.forEach(student => {
                            // Create elements to display student info and input field
                            const listItem = document.createElement('li');
                            const studentInfo = document.createTextNode(`RollNo.: ${student.rollNo}  `);
                            const markInput = document.createElement('input');
                            markInput.type = 'number';
                            markInput.placeholder = 'Enter marks';
                            
                            // Attach input field to studentMarks object when value changes
                            markInput.addEventListener('change', event => {
                                studentMarks[student.rollNo] = {
                                    "marks" : event.target.value,
                                    "adm_no" : student.adm_no,
                                    "subCode" : student.subCode
                                }
                            });
                            listItem.appendChild(studentInfo);
                            listItem.appendChild(markInput);
                            studentListElement.appendChild(listItem);
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching data:", error);
                    }
                });
        }

        const submitButton = document.getElementById('submitMarksButton');
        submitButton.addEventListener('click', () => {
            // Create an array of student marks and their identifiers
            const marksList = [];
            for (const studentId in studentMarks) {
                marksList.push({ id: studentId, marks: studentMarks[studentId] });
            }
            console.log(marksList);
            console.log(studentMarks);

            $.ajax({
                    url: 'examAPI.php/submitMarks',
                    type: "POST",
                    dataType: "json", // Corrected option name
                    data: JSON.stringify(marksList), // Corrected option name
                    contentType: "application/json", 
                    body: JSON.stringify(marksList),
                    success: function(data) {
                        console.log(data);
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching data:", error);
                    }
                });
        })




    </script>
</body>
</html>
