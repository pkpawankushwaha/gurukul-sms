<?php
  include "header.php";
  include "connection.php";
  if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript"> 
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Fee Payment</h2>
            </div>
          </header>
    <div class="container">

		<!-- Admission no. and name search field -->
    	<div class="row bg-white has-shadow">
    		<div class="col-md-6"><br>
    			
    			<form name="pay" method="post">
    				<div class="form-group row">
		     		<div class='col-sm-6'><input type=text name="adm_no" class="form-control form-control-sm" placeholder="Admission No." required></div>
			 		<div class='col-sm-6'><input type=submit name="pay" value="Search" class="btn btn-primary"></div>
			 		</div>
		 		</form>
    			
    		</div>
    		<div class="col-md-6"><br>
    			<form name="search" method="post">
    				<div class="form-group row">
		     		<div class='col-sm-6'><input type=text name="name" class="form-control form-control-sm" placeholder="Student Name" required></div>
			 		<div class='col-sm-6'><input type=submit name="search" value="Search" class="btn btn-primary"></div>
			 		</div>
		 		</form>
    		</div>
    	</div>
		<!-- Admission no. and name search field -->
    	<br>

    	<!-------------PHP Checking -->
    	<?php
		    if(!isset($_POST["pay"]))
		    { 
		     }
		  else
		  {
			  $res=mysqli_query($link,"select * from student where adm_no='$_POST[adm_no]'");
			  $count=0;$count=mysqli_num_rows($res);
			  if($count==0)
			  {  echo " Admission Number <font color=red>".$_POST["adm_no"]."</font> is not found";
		      }
			  else
			  {
				  $row=mysqli_fetch_array($res); 
				  
				         $res1=mysqli_query($link,"select * from tution where adm_no='$_POST[adm_no]'");
					     $row1=mysqli_fetch_array($res1);
				  
				  
				  ?>

				  <!-- PHP Checking area close -->

				<!--Display Student Information -->
    			<div class="row bg-white has-shadow">
    				<div  class="table-responsive">
						<table class="table">
							<thead>
								<tr"><th>Adm_NO.</th><th>Student Name </th><th> Father's Name</th><th> Class </th> </tr>
							</thead>
							<?php
								echo "<tbody><tr><td>".$row["adm_no"]."</td><td>".$row["name"]." </td><td>".$row["father_name"]."</td><td>".$row["class2024"]."</td> </tr></tbody></table>";
							?>
					</div>
    			</div>
				<hr>
				<!--Display Student Information area close-->


				<?php if($row['class'] != '0') {?>
				
				<!-- Session 2019-20 area -->
				<div class="row bg-white has-shadow">
					<div class="col-md-6" style="background-color: #f2f2f2">
						<h4 style="color:#060c21">Session 2019-20    | Class :   <?php if($row["class"]==='0')echo "Not Registered"; else echo $row["class"]; echo "   |  Fee :   ";echo $row1['fee'];echo "    |  Conveyance   ";echo $row['conveyance'] ?> </h4>
						<?php echo "<form name=form1 class=form action=fee_under_processing.php?adm=".$_POST["adm_no"]." method=post>"; ?>
				      		<br><br><br>&nbsp&nbsp Tution Fee<hr>

							<!-- session 2019-20 fee monthly form -->
					  		<?php
								$row1=mysqli_fetch_array(mysqli_query($link,"select * from tution where adm_no='$_POST[adm_no]'"));
								$c=0;$i=0;$count=0;
								echo "<div class='table-responsive'><table ><tr>";
								if($row1["April"]=='N'){
								echo "<td><input type=checkbox name=April value=April> April &nbsp </td>";$count+=1;
								if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								
								if($row1["May"]=='N'){
								echo "<td><input type=checkbox name=May value=May> May </td>";$count+=1; if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row1["June"]=='N'){
								echo "<td> <input type=checkbox name=June value=June> June </td> ";$count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row1["July"]=='N'){
								echo "<td> <input type=checkbox name=July value=July> July</td>     "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row1["August"]=='N'){
								echo "<td><input type=checkbox name=August value=August> August </td> ";$count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row1["September"]=='N'){
								echo "<td> <input type=checkbox name=September value=September> September </td>      ";$count+=1; if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row1["October"]=='N'){
								echo "<td><input type=checkbox name=October value=October> October </td>     "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row1["November"]=='N'){
								echo "<td> <input type=checkbox name=November value=November> November </td>    ";$count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row1["December"]=='N'){
								echo "<td> <input type=checkbox name=December value=December> December </td>   "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row1["Janaury"]=='N'){
								echo "<td> <input type=checkbox name=Janaury value=Janaury> Janaury </td>    "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row1["February"]=='N'){
								echo "<td><input type=checkbox name=February value=February> February </td>     ";$count+=1; if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row1["March"]=='N'){
								echo "<td> <input type=checkbox name=March value=March> March </td>     "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
						 
						 		echo "</tr></table></div>";
								//--------------------------------------------------------------------------
								//--------------------------------------------------------------------------
								//session 2019-20 conveyance monthly form
								$r=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$_POST[adm_no]'"));
								if($r["conveyance"]=="YES")
								{ 
									?>
								
									<hr>&nbsp&nbsp Conveyance Fee<hr>
								
									<?php
										$row1=mysqli_fetch_array(mysqli_query($link,"select * from conveyance where adm_no='$_POST[adm_no]'"));
										$c=0;$i=0;$count=0;
										echo "<table><tr>";
										if($row1["April"]=='N'){
										echo "<td><input type=checkbox name=cApril value=April> April &nbsp </td>";$count+=1;
										if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row1["May"]=='N'){
										echo "<td><input type=checkbox name=cMay value=May> May </td>";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row1["June"]=='N'){
										echo "<td> <input type=checkbox name=cJune value=June> June </td> ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row1["July"]=='N'){
										echo "<td> <input type=checkbox name=cJuly value=July> July</td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row1["August"]=='N'){
										echo "<td><input type=checkbox name=cAugust value=August> August </td> ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row1["September"]=='N'){
										echo "<td> <input type=checkbox name=cSeptember value=September> September </td>      ";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row1["October"]=='N'){
										echo "<td><input type=checkbox name=cOctober value=October> October </td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row1["November"]=='N'){
										echo "<td> <input type=checkbox name=cNovember value=November> November </td>    ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row1["December"]=='N'){
										echo "<td> <input type=checkbox name=cDecember value=December> December </td>   "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row1["Janaury"]=='N'){
										echo "<td> <input type=checkbox name=cJanaury value=Janaury> Janaury </td>    "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row1["February"]=='N'){
										echo "<td><input type=checkbox name=cFebruary value=February> February </td>     ";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row1["March"]=='N'){
										echo "<td> <input type=checkbox name=cMarch value=March> March </td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										echo "</tr></table><hr>";
								}
								?>			  
								<!-- session 2019-20 other fee form area -->
								&nbsp&nbsp Other Fees<hr>
								<?php
										$row1=mysqli_fetch_array(mysqli_query($link,"select * from otherfee where adm_no='$_POST[adm_no]'"));
										$c=0;$i=0;$count=0;
										echo "<table><tr>";
										if($r["sttype"]=="NEW")
										{
											if($row1["form"]=='N'){
											echo "<td><input type=checkbox name=form value=Form> Form FEE &nbsp </td>";$count+=1;
											if($c==7)
											{echo "</tr><tr>";$c=-1;
											}$c+=1;}
									
											if($row1["tie_belt"]=='N'){
														echo "<td><input type=checkbox name=tie_belt value=Tie_Belt> Tie&Belt </td>";$count+=1; if($c==7)
												{echo "</tr><tr>";$c=-1;
												}$c+=1;}
											if($row1["adm_fee"]=='N'){
												echo "<td> <input type=checkbox name=adm_fee value=Adm_FEE> Adm. FEE </td> ";$count+=1;if($c==7)
												{echo "</tr><tr>";$c=-1;
												}$c+=1;}
										}
									
									if($row1["idcard"]=='N'){
									echo "<td> <input type=checkbox name=idcard value=IDCARD> IDCARD</td>     "; $count+=1;if($c==7)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["exam1"]=='N'){
									echo "<td><input type=checkbox name=exam1 value=exam1> TM Exam </td> ";$count+=1;if($c==7)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["exam2"]=='N'){
									echo "<td> <input type=checkbox name=exam2 value=exam2> HY Exam </td>      ";$count+=1; if($c==7)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["exam3"]=='N'){
									echo "<td><input type=checkbox name=exam3 value=exam3> Y Exam </td>     "; $count+=1;if($c==7)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["result_card"]==0){
									echo "<td><input type=checkbox name=result_card value=result_card> Result Card </td>     "; $count+=1;if($c==7)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									
									echo "</tr></table><hr>";
								
								?>	
								<!-- session 2019-20 other fee form area close -->		  
								
								
								<center><input type=submit class="btn btn-primary" name="payfee" value="Pay FEE"></center>
								
							</form>
						</div>
							<!-- session 2019-20 fee form area close -->

						<!-- session 2019-20 fee paid area -->
						<div class="col-md-6">
							<font size=4px style="color:#2121ff;"> <br><u><center>TUITION FEES PAID FOR MONTHS</center></u></FONT>
								<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
								<?php
									
									$res1=mysqli_query($link,"select * from tution where adm_no='$_POST[adm_no]'");
									$row1=mysqli_fetch_array($res1);
									$c=0;$i=0;$count=0;
									
									if($row1["April"]=='Y'){
									echo "<td>April </td>      ";$count+=1;
									if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									if($row1["May"]=='Y'){
									echo "<td>May    </td>   "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["June"]=='Y'){
									echo "<td>June  </td>   ";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["July"]=='Y'){
									echo "<td>July   </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["August"]=='Y'){
									echo "<td>August   </td>";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["September"]=='Y'){
									echo "<td>September   </td>"; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["October"]=='Y'){
									echo "<td>October    </td> ";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["November"]=='Y'){
									echo "<td>November   </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["December"]=='Y'){
									echo "<td>December     </td>";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["Janaury"]=='Y'){
									echo "<td>Janaury    </td>"; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["February"]=='Y'){
									echo "<td>February   </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["March"]=='Y'){
									echo "<td>March     </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									if($count==0)
										echo "<center><h1>FEES not paid for any months</h1></center>";
									
									
								
								?></font></TABLE>
								<?php
								if($row['conveyance']=='YES')
								{
									?>
								<font size=4px style="color:#2121ff;"> <br><u><center>Conveyance FEES PAID FOR MONTHS</center></u></FONT>
								<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
											
								<?php
									$res1=mysqli_query($link,"select * from conveyance where adm_no='$_POST[adm_no]'");
									$row1=mysqli_fetch_array($res1);
									$c=0;$i=0;$count=0;
									if($row1["April"]=='Y'){
									echo "<td>April </td>      ";$count+=1;
									if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									if($row1["May"]=='Y'){
									echo "<td border=0>May    </td>   ";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["June"]=='Y'){
									echo "<td>June  </td>   "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["July"]=='Y'){
									echo "<td>July   </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["August"]=='Y'){
									echo "<td>August   </td>"; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["September"]=='Y'){
									echo "<td>September   </td>";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["October"]=='Y'){
									echo "<td>October    </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["November"]=='Y'){
									echo "<td>November   </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["December"]=='Y'){
									echo "<td>December     </td>"; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["Janaury"]=='Y'){
									echo "<td>Janaury    </td>"; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["February"]=='Y'){
									echo "<td>February   </td> ";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row1["March"]=='Y'){
									echo "<td>March     </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									if($count==0)
										echo "<center><h1>FEES not paid for any months</h1></center>";
									
								
								?></font></TABLE>
								
								
								<?php
								}
								?>
									
								
								<font size=4px style="color:#2121ff;"> <br><u><center>Other FEES PAID</center></u></FONT>
								<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
											
								<?php
									$otherres=mysqli_fetch_array(mysqli_query($link,"select * from otherfee where adm_no='$_POST[adm_no]'"));
									if($otherres["idcard"]=="Y")
										echo "<td>ID Card </td>";
									if($otherres["form"]=="Y")
										echo "<td>Form </td>";
									
									if($otherres["adm_fee"]=="Y")
										echo "<td>Admission FEE </td>";
									
									if($otherres["tie_belt"]=="Y")
										echo "<td>Tie&Belt </td><tr>";
									
									if($otherres["exam1"]=="Y")
										echo "<td>Third Monthly Exam</td>";
									if($otherres["exam2"]=="Y")
										echo "<td>Half Yearly Exam</td>";
									if($otherres["exam3"]=="Y")
										echo "<td>Yearly Exam</td>";
									if($otherres["result_card"]==20)
										echo "<td>Result Card</td>";
									
								
								?></font></TABLE>
								
						</div>
						<!-- session 2019-20 fee paid area close -->
				</div>

				<!-- Session 2019-20 area close -->
				<?php  }?>

				<hr style="color:red;size:2px;">
				<br><BR><BR>

				<!-- Session 2020-21 area -->
				<div class="row bg-white has-shadow">
					 <!-- Session 2020-21 left area -->
				 	 <div class="col-md-6" style="background-color: #f2f2f2">
                        <h4 style="color:#060c21">Session 2020-21   |  <?php if($row["class2020"]==='0')echo "Not Registered"; else echo $row["class2020"]; ?>  </h4>

						
						
						  <?php
						  	//session 2020-21 not registered --> form 
                            if($row["class2020"]=='0'){
								?>
								
								<form name="class2020reg" method="post">
										<input type="hidden" name="adm_no" value="<?php echo $_POST['adm_no']; ?>">
										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Class
											<div class="col-sm-6">
												<select name="class2020" class="form-control form-control-sm mb-3">
												<?php
							
													$cl=mysqli_query($link,"select * from class");
													$count=0;$count=mysqli_num_rows($cl);
													while($count>0)
														{   
														$clrow=mysqli_fetch_array($cl);
														echo "<option>".$clrow["class"]."</option>";
														$count-=1;
														
														}
													
												?>
												
												</select>
											</div>
														
											
          								 </div>
										   

										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Fees
											<div class='col-sm-6'><input type=text name="fees2020" class="form-control form-control-sm" placeholder="Monthly Fees " required></div>
						
										</div>

										<div class="form-group row">

											&nbsp &nbsp &nbsp &nbsp &nbsp Conveyance
											<div class="col-sm-6">
												<select name="con2020" class="form-control form-control-sm mb-3">
													<option>NO</option> 
													<option>YES</option>
												</select>
											</div>
										</div>

										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Conveyance Fees
											<div class='col-sm-6'><input type=text name="confees2020" class="form-control form-control-sm" placeholder="Conveyance Fees " required></div>
						
										</div>

										<div class="form-group row">
														&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp
											<div class='col-sm-6'><input type=submit name="reg2020" value="Transfer Class" class="btn btn-primary"></div>
										</div>
										

										   



									
								</form>
								
								<?php
								


            
                            }
							//session 2020-21 not registered --> form 
            
							//session 2020-21 registered
                            else{
								?>
								<?php $tutrow=mysqli_fetch_array(mysqli_query($link,"SELECT * from tution2021 where adm_no='$row[adm_no]'"));
								echo "Fee :  ";echo $tutrow["fee"];  
								?>
								  |  Conveyance : <?php echo $row["conveyance2021"]; ?> 


							<!-- session 2020-21 fee form -->
							<?php echo "<form name=form2020 class=form action=fee_under_processing_2020.php?adm=".$_POST["adm_no"]." method=post>"; ?>
								<br>&nbsp&nbsp Tution Fee<hr>
							
							<?php
									$row12020=mysqli_fetch_array(mysqli_query($link,"select * from tution2021 where adm_no='$_POST[adm_no]'"));
									$c=0;$i=0;$count=0;
									echo "<div class='table-responsive'><table ><tr>";
								if($row12020["April"]=='0'){
								echo "<td><input type=checkbox name=April value=April> April &nbsp </td>";$count+=1;
								if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								
								if($row12020["May"]=='0'){
								echo "<td><input type=checkbox name=May value=May> May </td>";$count+=1; if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["June"]=='0'){
								echo "<td> <input type=checkbox name=June value=June> June </td> ";$count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["July"]=='0'){
								echo "<td> <input type=checkbox name=July value=July> July</td>     "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["August"]=='0'){
								echo "<td><input type=checkbox name=August value=August> August </td> ";$count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["September"]=='0'){
								echo "<td> <input type=checkbox name=September value=September> September </td>      ";$count+=1; if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["October"]=='0'){
								echo "<td><input type=checkbox name=October value=October> October </td>     "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["November"]=='0'){
								echo "<td> <input type=checkbox name=November value=November> November </td>    ";$count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["December"]=='0'){
								echo "<td> <input type=checkbox name=December value=December> December </td>   "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["January"]=='0'){
								echo "<td> <input type=checkbox name=January value=January> January </td>    "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["February"]=='0'){
								echo "<td><input type=checkbox name=February value=February> February </td>     ";$count+=1; if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["March"]=='0'){
								echo "<td> <input type=checkbox name=March value=March> March </td>     "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								
								echo "</tr></table></div>";
							?>
							<!-- session 2020-21 tution fee input close -->


							<!-- session 2021-21 conveyance fee input -->
							<?php 						 
								$r=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$_POST[adm_no]'"));
								if($r["conveyance2021"]=="YES")
								{ 
							?>
							
								<hr>&nbsp&nbsp Conveyance Fee<hr>
					  
							<?php
									$row12020=mysqli_fetch_array(mysqli_query($link,"select * from conveyance2021 where adm_no='$_POST[adm_no]'"));
									$c=0;$i=0;$count=0;
									echo "<table><tr>";
								if($row12020["April"]=='0'){
								echo "<td><input type=checkbox name=cApril value=April> April &nbsp </td>";$count+=1;
								if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								
								if($row12020["May"]=='0'){
								echo "<td><input type=checkbox name=cMay value=May> May </td>";$count+=1; if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["June"]=='0'){
								echo "<td> <input type=checkbox name=cJune value=June> June </td> ";$count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["July"]=='0'){
								echo "<td> <input type=checkbox name=cJuly value=July> July</td>     "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["August"]=='0'){
								echo "<td><input type=checkbox name=cAugust value=August> August </td> ";$count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["September"]=='0'){
								echo "<td> <input type=checkbox name=cSeptember value=September> September </td>      ";$count+=1; if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["October"]=='0'){
								echo "<td><input type=checkbox name=cOctober value=October> October </td>     "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["November"]=='0'){
								echo "<td> <input type=checkbox name=cNovember value=November> November </td>    ";$count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["December"]=='0'){
								echo "<td> <input type=checkbox name=cDecember value=December> December </td>   "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["January"]=='0'){
								echo "<td> <input type=checkbox name=cJanuary value=January> January </td>    "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["February"]=='0'){
								echo "<td><input type=checkbox name=cFebruary value=February> February </td>     ";$count+=1; if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["March"]=='0'){
								echo "<td> <input type=checkbox name=cMarch value=March> March </td>     "; $count+=1;if($c==5)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								
								echo "</tr></table><hr>";
								}
							?>			  
					  		<!-- session 2021-21 conveyance fee input close -->
							<!-- session 2021-21 other fee input -->
					 		 &nbsp&nbsp Other Fees<hr>
							<?php
									$row12020=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2021 where adm_no='$_POST[adm_no]'"));
									$c=0;$i=0;$count=0;
									echo "<table><tr>";
									if($r["sttype"]=="NEW")
									{
										if($row12020["form"]=='0'){
										echo "<td><input type=checkbox name=form value=Form> Form FEE &nbsp </td>";$count+=1;
										if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
								
										if($row12020["tie_belt"]=='0'){
													echo "<td><input type=checkbox name=tie_belt value=Tie_Belt> Tie&Belt </td>";$count+=1; if($c==7)
											{echo "</tr><tr>";$c=-1;
											}$c+=1;}
										if($row12020["adm_fee"]=='0'){
											echo "<td> <input type=checkbox name=adm_fee value=Adm_FEE> Adm. FEE </td> ";$count+=1;if($c==7)
											{echo "</tr><tr>";$c=-1;
											}$c+=1;}
									}
								
								if($row12020["idcard"]=='0'){
								echo "<td> <input type=checkbox name=idcard value=IDCARD> IDCARD</td>     "; $count+=1;if($c==7)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["exam1"]=='0'){
								echo "<td><input type=checkbox name=exam1 value=exam1> TM Exam </td> ";$count+=1;if($c==7)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["exam2"]=='0'){
								echo "<td> <input type=checkbox name=exam2 value=exam2> HY Exam </td>      ";$count+=1; if($c==7)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["exam3"]=='0'){
								echo "<td><input type=checkbox name=exam3 value=exam3> Y Exam </td>     "; $count+=1;if($c==7)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								if($row12020["result_card"]==0){
								echo "<td><input type=checkbox name=result_card value=result_card> Result Card </td>     "; $count+=1;if($c==7)
								{echo "</tr><tr>";$c=-1;
								}$c+=1;}
								
								
								echo "</tr></table><hr>";
							
							?>			  
					  		<!-- session 2021-21 other fee input close -->
					 
					 		<center><input type=submit class="btn btn-primary" name="payfee2020" value="Pay FEE"></center>
				     
				  			</form> 
							<!-- session 2020-21 fee form close -->


							<!-- else of 2020 -->
						<?php
                            }
                        ?>
					  
							  
		  
				  </div>
				  <!-- Session 2020-21 left area -->
				  <!-- Session 2020-21 right area -->
				  <div class="col-md-6" id="div2021paid">
							<?php 
								if($row["class2020"]!='0'){
									?>
										<font size=4px style="color:#2121ff;"> <br><u><center>TUITION FEES PAID FOR MONTHS</center></u></FONT>
					   				<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
								<?php
									
									$res1=mysqli_query($link,"select * from tution2021 where adm_no='$_POST[adm_no]'");
									$row12020=mysqli_fetch_array($res1);
									$c=0;$i=0;$count=0;
									
									if($row12020["April"]=='Y'){
									echo "<td>April </td>      ";$count+=1;
									if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									if($row12020["May"]=='Y'){
									echo "<td>May    </td>   "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["June"]=='Y'){
									echo "<td>June  </td>   ";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["July"]=='Y'){
									echo "<td>July   </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["August"]=='Y'){
									echo "<td>August   </td>";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["September"]=='Y'){
									echo "<td>September   </td>"; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["October"]=='Y'){
									echo "<td>October    </td> ";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["November"]=='Y'){
									echo "<td>November   </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["December"]=='Y'){
									echo "<td>December     </td>";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["January"]=='Y'){
									echo "<td>January    </td>"; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["February"]=='Y'){
									echo "<td>February   </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["March"]=='Y'){
									echo "<td>March     </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									if($count==0)
										echo "<center><h1>FEES not paid for any months</h1></center>";
									
									
								
								?></font></TABLE>
								<?php
								if($row['conveyance2021']=='YES')
								{
									?>
								<font size=4px style="color:#2121ff;"> <br><u><center>Conveyance FEES PAID FOR MONTHS</center></u></FONT>
								<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
											
								<?php
									$res1=mysqli_query($link,"select * from conveyance2021 where adm_no='$_POST[adm_no]'");
									$row12020=mysqli_fetch_array($res1);
									$c=0;$i=0;$count=0;
									if($row12020["April"]=='Y'){
									echo "<td>April </td>      ";$count+=1;
									if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									if($row12020["May"]=='Y'){
									echo "<td border=0>May    </td>   ";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["June"]=='Y'){
									echo "<td>June  </td>   "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["July"]=='Y'){
									echo "<td>July   </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["August"]=='Y'){
									echo "<td>August   </td>"; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["September"]=='Y'){
									echo "<td>September   </td>";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["October"]=='Y'){
									echo "<td>October    </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["November"]=='Y'){
									echo "<td>November   </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["December"]=='Y'){
									echo "<td>December     </td>"; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["January"]=='Y'){
									echo "<td>January    </td>"; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["February"]=='Y'){
									echo "<td>February   </td> ";$count+=1; if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12020["March"]=='Y'){
									echo "<td>March     </td> "; $count+=1;if($c==3)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									if($count==0)
										echo "<center><h1>FEES not paid for any months</h1></center>";
									
								
								?></font></TABLE>
					
					
								<?php
								}
								?>
									
								
								<font size=4px style="color:#2121ff;"> <br><u><center>Other FEES PAID</center></u></FONT>
								<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
								
								<!-- session 2020-21 otherfee paid -->
								<?php
									$otherres=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2021 where adm_no='$_POST[adm_no]'"));
									if($otherres["idcard"]=="Y")
										echo "<td>ID Card </td>";
									if($otherres["form"]=="Y")
										echo "<td>Form </td>";
									
									if($otherres["adm_fee"]=="Y")
										echo "<td>Admission FEE </td>";
									
									if($otherres["tie_belt"]=="Y")
										echo "<td>Tie&Belt </td><tr>";
									
									if($otherres["exam1"]=="Y")
										echo "<td>Third Monthly Exam</td>";
									if($otherres["exam2"]=="Y")
										echo "<td>Half Yearly Exam</td>";
									if($otherres["exam3"]=="Y")
										echo "<td>Yearly Exam</td>";
									if($otherres["result_card"]==20)
										echo "<td>Result Card</td>";
									
								
								?>
								</font></TABLE>
								<!-- session 2020-21 otherfee paid close -->
								



									<?php

									
							
								}
							?>
				  	</div>
				  <!-- session 2020-21 right area close -->
				</div>
				<!-- session 2020-21 area close -->
            
            <hr style="color:red;size:2px;">
			 <br><BR><BR>

			 <!-- session 2021-22 area -->
                <div class="row bg-white has-shadow">
					  <!-- session 2021-22 left area -->	
				 	 <div class="col-md-6" style="background-color: #f2f2f2">
                        <h4 style="color:#060c21">Session 2021-22   |  <?php if($row["class2021"]==='0')echo "Not Registered"; else echo $row["class2021"]; ?>  </h4>

						
						
						  <?php
						  	//session 2021-22 class transfer
                            if($row["class2021"]=='0'){
								?>
								
								<form name="class2021reg" method="post">
										<input type="hidden" name="adm_no" value="<?php echo $_POST['adm_no']; ?>">
										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Class
											<div class="col-sm-6">
												<select name="class2021" class="form-control form-control-sm mb-3">
												<?php
							
													$cl=mysqli_query($link,"select * from class");
													$count=0;$count=mysqli_num_rows($cl);
													while($count>0)
														{   
														$clrow=mysqli_fetch_array($cl);
														echo "<option>".$clrow["class"]."</option>";
														$count-=1;
														
														}
													
												?>
												
												</select>
											</div>
														
											
          								 </div>
										   

										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Fees
											<div class='col-sm-6'><input type=text name="fees2021" class="form-control form-control-sm" placeholder="Monthly Fees " required></div>
						
										</div>

										<div class="form-group row">

											&nbsp &nbsp &nbsp &nbsp &nbsp Conveyance
											<div class="col-sm-6">
												<select name="con2021" class="form-control form-control-sm mb-3">
													<option>NO</option> 
													<option>YES</option>
												</select>
											</div>
										</div>

										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Conveyance Fees
											<div class='col-sm-6'><input type=text name="confees2021" class="form-control form-control-sm" placeholder="Conveyance Fees " required></div>
						
										</div>

										<div class="form-group row">
														&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp
											<div class='col-sm-6'><input type=submit name="reg2021" value="Transfer Class" class="btn btn-primary"></div>
										</div>
										

										   



									
								</form>
								
								<?php
								


            
                            }
							//session 2021-22 class transfer close

							//session 2021-22 class registered
                            else{
								?>
								<?php $tutrow=mysqli_fetch_array(mysqli_query($link,"SELECT * from tution2022 where adm_no='$row[adm_no]'"));
								echo "Fee :  ";echo $tutrow["fee"];  
								?>
								  |  Conveyance : <?php echo $row["conveyance2022"]; ?> 


								  <!-- session 2021-22 class registered -->
								<?php echo "<form name=form2020 class=form action=fee_under_processing_2021.php?adm=".$_POST["adm_no"]." method=post>"; ?>
								<br>&nbsp&nbsp Tution Fee<hr>
								
								<?php
										$row12021=mysqli_fetch_array(mysqli_query($link,"select * from tution2022 where adm_no='$_POST[adm_no]'"));
										$c=0;$i=0;$count=0;
										echo "<div class='table-responsive'><table ><tr>";
									if($row12021["April"]=='0'){
									echo "<td><input type=checkbox name=April value=April> April &nbsp </td>";$count+=1;
									if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									if($row12021["May"]=='0'){
									echo "<td><input type=checkbox name=May value=May> May </td>";$count+=1; if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12021["June"]=='0'){
									echo "<td> <input type=checkbox name=June value=June> June </td> ";$count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12021["July"]=='0'){
									echo "<td> <input type=checkbox name=July value=July> July</td>     "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12021["August"]=='0'){
									echo "<td><input type=checkbox name=August value=August> August </td> ";$count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12021["September"]=='0'){
									echo "<td> <input type=checkbox name=September value=September> September </td>      ";$count+=1; if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12021["October"]=='0'){
									echo "<td><input type=checkbox name=October value=October> October </td>     "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12021["November"]=='0'){
									echo "<td> <input type=checkbox name=November value=November> November </td>    ";$count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12021["December"]=='0'){
									echo "<td> <input type=checkbox name=December value=December> December </td>   "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12021["January"]=='0'){
									echo "<td> <input type=checkbox name=January value=January> January </td>    "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12021["February"]=='0'){
									echo "<td><input type=checkbox name=February value=February> February </td>     ";$count+=1; if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12021["March"]=='0'){
									echo "<td> <input type=checkbox name=March value=March> March </td>     "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
						 			echo "</tr></table></div>";
									//--------------------------------------------------------------------------
									//--------------------------------------------------------------------------						 
									$r=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$_POST[adm_no]'"));
									if($r["conveyance2022"]=="YES")
									{ 
										?>
									
										<hr>&nbsp&nbsp Conveyance Fee<hr>
									
									<?php
											$row12021=mysqli_fetch_array(mysqli_query($link,"select * from conveyance2022 where adm_no='$_POST[adm_no]'"));
											$c=0;$i=0;$count=0;
											echo "<table><tr>";
										if($row12021["April"]=='0'){
										echo "<td><input type=checkbox name=cApril value=April> April &nbsp </td>";$count+=1;
										if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row12021["May"]=='0'){
										echo "<td><input type=checkbox name=cMay value=May> May </td>";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["June"]=='0'){
										echo "<td> <input type=checkbox name=cJune value=June> June </td> ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["July"]=='0'){
										echo "<td> <input type=checkbox name=cJuly value=July> July</td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["August"]=='0'){
										echo "<td><input type=checkbox name=cAugust value=August> August </td> ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["September"]=='0'){
										echo "<td> <input type=checkbox name=cSeptember value=September> September </td>      ";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["October"]=='0'){
										echo "<td><input type=checkbox name=cOctober value=October> October </td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["November"]=='0'){
										echo "<td> <input type=checkbox name=cNovember value=November> November </td>    ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["December"]=='0'){
										echo "<td> <input type=checkbox name=cDecember value=December> December </td>   "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["January"]=='0'){
										echo "<td> <input type=checkbox name=cJanuary value=January> January </td>    "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["February"]=='0'){
										echo "<td><input type=checkbox name=cFebruary value=February> February </td>     ";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["March"]=='0'){
										echo "<td> <input type=checkbox name=cMarch value=March> March </td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										echo "</tr></table><hr>";
									}
									?>			  
									
									&nbsp&nbsp Other Fees<hr>
									<?php
											$row12021=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2022 where adm_no='$_POST[adm_no]'"));
											$c=0;$i=0;$count=0;
											echo "<table><tr>";
											if($r["sttype"]=="NEW")
											{
												if($row12021["form"]=='0'){
												echo "<td><input type=checkbox name=form value=Form> Form FEE &nbsp </td>";$count+=1;
												if($c==7)
												{echo "</tr><tr>";$c=-1;
												}$c+=1;}
										
												if($row12021["tie_belt"]=='0'){
															echo "<td><input type=checkbox name=tie_belt value=Tie_Belt> Tie&Belt </td>";$count+=1; if($c==7)
													{echo "</tr><tr>";$c=-1;
													}$c+=1;}
												if($row12021["adm_fee"]=='0'){
													echo "<td> <input type=checkbox name=adm_fee value=Adm_FEE> Adm. FEE </td> ";$count+=1;if($c==7)
													{echo "</tr><tr>";$c=-1;
													}$c+=1;}
											}
										
										if($row12021["idcard"]=='0'){
										echo "<td> <input type=checkbox name=idcard value=IDCARD> IDCARD</td>     "; $count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["exam1"]=='0'){
										echo "<td><input type=checkbox name=exam1 value=exam1> TM Exam </td> ";$count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["exam2"]=='0'){
										echo "<td> <input type=checkbox name=exam2 value=exam2> HY Exam </td>      ";$count+=1; if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["exam3"]=='0'){
										echo "<td><input type=checkbox name=exam3 value=exam3> Y Exam </td>     "; $count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["result_card"]==0){
										echo "<td><input type=checkbox name=result_card value=result_card> Result Card </td>     "; $count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										
										echo "</tr></table><hr>";
									
									?>			  
									
									
									<center><input type=submit class="btn btn-primary" name="payfee2020" value="Pay FEE"></center>
									
								</form>
								
								<?php
                            }
                        ?>
					</div>
					<!-- session 2021-22 left area  close-->


					<!-- session 2021-22 right area -->
				  	<div class="col-md-6" id="div2022paid">
							<?php 
								if($row["class2021"]!='0'){
									?>
									<font size=4px style="color:#2121ff;"> <br><u><center>TUITION FEES PAID FOR MONTHS</center></u></FONT>
									<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
									<?php
										
										$res1=mysqli_query($link,"select * from tution2022 where adm_no='$_POST[adm_no]'");
										$row12021=mysqli_fetch_array($res1);
										$c=0;$i=0;$count=0;
										
										if($row12021["April"]=='Y'){
										echo "<td>April </td>      ";$count+=1;
										if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row12021["May"]=='Y'){
										echo "<td>May    </td>   "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["June"]=='Y'){
										echo "<td>June  </td>   ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["July"]=='Y'){
										echo "<td>July   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["August"]=='Y'){
										echo "<td>August   </td>";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["September"]=='Y'){
										echo "<td>September   </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["October"]=='Y'){
										echo "<td>October    </td> ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["November"]=='Y'){
										echo "<td>November   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["December"]=='Y'){
										echo "<td>December     </td>";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["January"]=='Y'){
										echo "<td>January    </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["February"]=='Y'){
										echo "<td>February   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["March"]=='Y'){
										echo "<td>March     </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($count==0)
											echo "<center><h1>FEES not paid for any months</h1></center>";
										
										
									
									?></font></TABLE>

									<!-- conveyance 2021-22 paid -->
									<?php
									if($row['conveyance2022']=='YES'){
										?>
										<font size=4px style="color:#2121ff;"> <br><u><center>Conveyance FEES PAID FOR MONTHS</center></u></FONT>
										<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
													
										<?php
										$res1=mysqli_query($link,"select * from conveyance2022 where adm_no='$_POST[adm_no]'");
										$row12021=mysqli_fetch_array($res1);
										$c=0;$i=0;$count=0;
										if($row12021["April"]=='Y'){
										echo "<td>April </td>      ";$count+=1;
										if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row12021["May"]=='Y'){
										echo "<td border=0>May    </td>   ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["June"]=='Y'){
										echo "<td>June  </td>   "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["July"]=='Y'){
										echo "<td>July   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["August"]=='Y'){
										echo "<td>August   </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["September"]=='Y'){
										echo "<td>September   </td>";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["October"]=='Y'){
										echo "<td>October    </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["November"]=='Y'){
										echo "<td>November   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["December"]=='Y'){
										echo "<td>December     </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["January"]=='Y'){
										echo "<td>January    </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["February"]=='Y'){
										echo "<td>February   </td> ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12021["March"]=='Y'){
										echo "<td>March     </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($count==0)
											echo "<center><h1>FEES not paid for any months</h1></center>";
										
									
										?></font></TABLE>
										
										
										<?php
									}
									?>
										
									<!-- otherfee 2021-22 paid -->
									<font size=4px style="color:#2121ff;"> <br><u><center>Other FEES PAID</center></u></FONT>
									<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
												
										<?php
											$otherres=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2022 where adm_no='$_POST[adm_no]'"));
											if($otherres["idcard"]=="Y")
												echo "<td>ID Card </td>";
											if($otherres["form"]=="Y")
												echo "<td>Form </td>";
											
											if($otherres["adm_fee"]=="Y")
												echo "<td>Admission FEE </td>";
											
											if($otherres["tie_belt"]=="Y")
												echo "<td>Tie&Belt </td><tr>";
											
											if($otherres["exam1"]=="Y")
												echo "<td>Third Monthly Exam</td>";
											if($otherres["exam2"]=="Y")
												echo "<td>Half Yearly Exam</td>";
											if($otherres["exam3"]=="Y")
												echo "<td>Yearly Exam</td>";
											if($otherres["result_card"]==50)
												echo "<td>Result Card</td>";
											
										
										?></font>
									</TABLE>
									



									<?php

									
							
								}
							?>
				 	 </div>
					<!-- session 2021-22 right area close-->
				</div>
				<!-- session 2021-22 close -->


				<hr style="color:red;size:2px;">
			 <br><BR><BR>

			 <!-- session 2022-23 area -->
                <div class="row bg-white has-shadow">
					  <!-- session 2022-23 left area -->	
				 	 <div class="col-md-6" style="background-color: #f2f2f2">
                        <h4 style="color:#060c21">Session 2022-23   |  <?php if($row["class2022"]==='0')echo "Not Registered"; else echo $row["class2022"]; ?>  </h4>

						
						
						  <?php
						  	//session 2022-23 class transfer
                            if($row["class2022"]=='0'){
								?>
								
								<form name="class2022reg" method="post">
										<input type="hidden" name="adm_no" value="<?php echo $_POST['adm_no']; ?>">
										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Class
											<div class="col-sm-6">
												<select name="class2022" class="form-control form-control-sm mb-3">
												<?php
							
													$cl=mysqli_query($link,"select * from class");
													$count=0;$count=mysqli_num_rows($cl);
													while($count>0)
														{   
														$clrow=mysqli_fetch_array($cl);
														echo "<option>".$clrow["class"]."</option>";
														$count-=1;
														
														}
													
												?>
												
												</select>
											</div>
														
											
          								 </div>
										   

										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Fees
											<div class='col-sm-6'><input type=text name="fees2022" class="form-control form-control-sm" placeholder="Monthly Fees " required></div>
						
										</div>

										<div class="form-group row">

											&nbsp &nbsp &nbsp &nbsp &nbsp Conveyance
											<div class="col-sm-6">
												<select name="con2022" class="form-control form-control-sm mb-3">
													<option>NO</option> 
													<option>YES</option>
												</select>
											</div>
										</div>
										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Conveyance Fees
											<div class='col-sm-6'><input type=text name="confees2022" class="form-control form-control-sm" placeholder="Conveyance Fees " required></div>
						
										</div>

										<div class="form-group row">
														&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp
											<div class='col-sm-6'><input type=submit name="reg2022" value="Transfer Class" class="btn btn-primary"></div>
										</div>
										

										   



									
								</form>
								
								<?php
								


            
                            }
							//session 2022-23 class transfer close

							//session 2022-23 class registered
                            else{
								?>
								<?php $tutrow=mysqli_fetch_array(mysqli_query($link,"SELECT * from tution2023 where adm_no='$row[adm_no]'"));
								echo "Fee :  ";echo $tutrow["fee"];  
								?>
								  |  Conveyance : <?php echo $row["conveyance2023"]; ?> 


								  <!-- session 2022-23 class registered -->
								<?php echo "<form name=form2020 class=form action=fee_under_processing_2022.php?adm=".$_POST["adm_no"]." method=post>"; ?>
								<br>&nbsp&nbsp Tution Fee<hr>
								
								<?php
										$row12022=mysqli_fetch_array(mysqli_query($link,"select * from tution2023 where adm_no='$_POST[adm_no]'"));
										$c=0;$i=0;$count=0;
										echo "<div class='table-responsive'><table ><tr>";
									if($row12022["April"]=='0'){
									echo "<td><input type=checkbox name=April value=April> April &nbsp </td>";$count+=1;
									if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									if($row12022["May"]=='0'){
									echo "<td><input type=checkbox name=May value=May> May </td>";$count+=1; if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12022["June"]=='0'){
									echo "<td> <input type=checkbox name=June value=June> June </td> ";$count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12022["July"]=='0'){
									echo "<td> <input type=checkbox name=July value=July> July</td>     "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12022["August"]=='0'){
									echo "<td><input type=checkbox name=August value=August> August </td> ";$count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12022["September"]=='0'){
									echo "<td> <input type=checkbox name=September value=September> September </td>      ";$count+=1; if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12022["October"]=='0'){
									echo "<td><input type=checkbox name=October value=October> October </td>     "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12022["November"]=='0'){
									echo "<td> <input type=checkbox name=November value=November> November </td>    ";$count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12022["December"]=='0'){
									echo "<td> <input type=checkbox name=December value=December> December </td>   "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12022["January"]=='0'){
									echo "<td> <input type=checkbox name=January value=January> January </td>    "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12022["February"]=='0'){
									echo "<td><input type=checkbox name=February value=February> February </td>     ";$count+=1; if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12022["March"]=='0'){
									echo "<td> <input type=checkbox name=March value=March> March </td>     "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
						 			echo "</tr></table></div>";
									//--------------------------------------------------------------------------
									//--------------------------------------------------------------------------						 
									$r=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$_POST[adm_no]'"));
									if($r["conveyance2023"]=="YES")
									{ 
										?>
									
										<hr>&nbsp&nbsp Conveyance Fee<hr>
									
									<?php
											$row12022=mysqli_fetch_array(mysqli_query($link,"select * from conveyance2023 where adm_no='$_POST[adm_no]'"));
											$c=0;$i=0;$count=0;
											echo "<table><tr>";
										if($row12022["April"]=='0'){
										echo "<td><input type=checkbox name=cApril value=April> April &nbsp </td>";$count+=1;
										if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row12022["May"]=='0'){
										echo "<td><input type=checkbox name=cMay value=May> May </td>";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["June"]=='0'){
										echo "<td> <input type=checkbox name=cJune value=June> June </td> ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["July"]=='0'){
										echo "<td> <input type=checkbox name=cJuly value=July> July</td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["August"]=='0'){
										echo "<td><input type=checkbox name=cAugust value=August> August </td> ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["September"]=='0'){
										echo "<td> <input type=checkbox name=cSeptember value=September> September </td>      ";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["October"]=='0'){
										echo "<td><input type=checkbox name=cOctober value=October> October </td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["November"]=='0'){
										echo "<td> <input type=checkbox name=cNovember value=November> November </td>    ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["December"]=='0'){
										echo "<td> <input type=checkbox name=cDecember value=December> December </td>   "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["January"]=='0'){
										echo "<td> <input type=checkbox name=cJanuary value=January> January </td>    "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["February"]=='0'){
										echo "<td><input type=checkbox name=cFebruary value=February> February </td>     ";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["March"]=='0'){
										echo "<td> <input type=checkbox name=cMarch value=March> March </td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										echo "</tr></table><hr>";
									}
									?>			  
									
									&nbsp&nbsp Other Fees<hr>
									<?php
											$row12022=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2023 where adm_no='$_POST[adm_no]'"));
											$c=0;$i=0;$count=0;
											echo "<table><tr>";
											if($r["sttype"]=="NEW")
											{
												if($row12022["form"]=='0'){
												echo "<td><input type=checkbox name=form value=Form> Form FEE &nbsp </td>";$count+=1;
												if($c==7)
												{echo "</tr><tr>";$c=-1;
												}$c+=1;}
										
												if($row12022["tie_belt"]=='0'){
															echo "<td><input type=checkbox name=tie_belt value=Tie_Belt> Tie&Belt </td>";$count+=1; if($c==7)
													{echo "</tr><tr>";$c=-1;
													}$c+=1;}
												if($row12022["adm_fee"]=='0'){
													echo "<td> <input type=checkbox name=adm_fee value=Adm_FEE> Adm. FEE </td> ";$count+=1;if($c==7)
													{echo "</tr><tr>";$c=-1;
													}$c+=1;}
											}
										
										if($row12022["idcard"]=='0'){
										echo "<td> <input type=checkbox name=idcard value=IDCARD> IDCARD</td>     "; $count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["exam1"]=='0'){
										echo "<td><input type=checkbox name=exam1 value=exam1> TM Exam </td> ";$count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["exam2"]=='0'){
										echo "<td> <input type=checkbox name=exam2 value=exam2> HY Exam </td>      ";$count+=1; if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["exam3"]=='0'){
										echo "<td><input type=checkbox name=exam3 value=exam3> Y Exam </td>     "; $count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["result_card"]==0){
										echo "<td><input type=checkbox name=result_card value=result_card> Result Card </td>     "; $count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										
										echo "</tr></table><hr>";
									
									?>			  
									
									
									<center><input type=submit class="btn btn-primary" name="payfee2020" value="Pay FEE"></center>
									
								</form>
								
								<?php
                            }
                        ?>
					</div>
					<!-- session 2022-23 left area  close-->


					<!-- session 2022-23 right area -->
				  	<div class="col-md-6" id="div2023paid">
							<?php 
								if($row["class2022"]!='0'){
									?>
									<font size=4px style="color:#2121ff;"> <br><u><center>TUITION FEES PAID FOR MONTHS</center></u></FONT>
									<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
									<?php
										
										$res1=mysqli_query($link,"select * from tution2023 where adm_no='$_POST[adm_no]'");
										$row12022=mysqli_fetch_array($res1);
										$c=0;$i=0;$count=0;
										
										if($row12022["April"]=='Y'){
										echo "<td>April </td>      ";$count+=1;
										if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row12022["May"]=='Y'){
										echo "<td>May    </td>   "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["June"]=='Y'){
										echo "<td>June  </td>   ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["July"]=='Y'){
										echo "<td>July   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["August"]=='Y'){
										echo "<td>August   </td>";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["September"]=='Y'){
										echo "<td>September   </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["October"]=='Y'){
										echo "<td>October    </td> ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["November"]=='Y'){
										echo "<td>November   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["December"]=='Y'){
										echo "<td>December     </td>";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["January"]=='Y'){
										echo "<td>January    </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["February"]=='Y'){
										echo "<td>February   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["March"]=='Y'){
										echo "<td>March     </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($count==0)
											echo "<center><h1>FEES not paid for any months</h1></center>";
										
										
									
									?></font></TABLE>

									<!-- conveyance 2022-23 paid -->
									<?php
									if($row['conveyance2023']=='YES'){
										?>
										<font size=4px style="color:#2121ff;"> <br><u><center>Conveyance FEES PAID FOR MONTHS</center></u></FONT>
										<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
													
										<?php
										$res1=mysqli_query($link,"select * from conveyance2023 where adm_no='$_POST[adm_no]'");
										$row12022=mysqli_fetch_array($res1);
										$c=0;$i=0;$count=0;
										if($row12022["April"]=='Y'){
										echo "<td>April </td>      ";$count+=1;
										if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row12022["May"]=='Y'){
										echo "<td border=0>May    </td>   ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["June"]=='Y'){
										echo "<td>June  </td>   "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["July"]=='Y'){
										echo "<td>July   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["August"]=='Y'){
										echo "<td>August   </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["September"]=='Y'){
										echo "<td>September   </td>";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["October"]=='Y'){
										echo "<td>October    </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["November"]=='Y'){
										echo "<td>November   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["December"]=='Y'){
										echo "<td>December     </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["January"]=='Y'){
										echo "<td>January    </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["February"]=='Y'){
										echo "<td>February   </td> ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12022["March"]=='Y'){
										echo "<td>March     </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($count==0)
											echo "<center><h1>FEES not paid for any months</h1></center>";
										
									
										?></font></TABLE>
										
										
										<?php
									}
									?>
										
									<!-- otherfee 2022-23 paid -->
									<font size=4px style="color:#2121ff;"> <br><u><center>Other FEES PAID</center></u></FONT>
									<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
												
										<?php
											$otherres=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2023 where adm_no='$_POST[adm_no]'"));
											if($otherres["idcard"]=="Y")
												echo "<td>ID Card </td>";
											if($otherres["form"]=="Y")
												echo "<td>Form </td>";
											
											if($otherres["adm_fee"]=="Y")
												echo "<td>Admission FEE </td>";
											
											if($otherres["tie_belt"]=="Y")
												echo "<td>Tie&Belt </td><tr>";
											
											if($otherres["exam1"]=="Y")
												echo "<td>Third Monthly Exam</td>";
											if($otherres["exam2"]=="Y")
												echo "<td>Half Yearly Exam</td>";
											if($otherres["exam3"]=="Y")
												echo "<td>Yearly Exam</td>";
											if($otherres["result_card"]==50)
												echo "<td>Result Card</td>";
											
										
										?></font>
									</TABLE>
									



									<?php

									
							
								}
							?>
				 	 </div>
					<!-- session 2021-22 right area close-->
				</div>
				<!-- session 2021-22 close -->
				
			 <hr style="color:red;size:2px;">
			 <br><BR><BR>

			 <!-- session 2023-24 area -->
                <div class="row bg-white has-shadow">
					  <!-- session 2023-24 left area -->	
				 	 <div class="col-md-6" style="background-color: #f2f2f2">
                        <h4 style="color:#060c21">Session 2023-24   |  <?php if($row["class2023"]==='0')echo "Not Registered"; else echo $row["class2023"]; ?>  </h4>

						
						
						  <?php
						  	//session 2023-24 class transfer
                            if($row["class2023"]=='0'){
								?>
								
								<form name="class2023reg" method="post">
										<input type="hidden" name="adm_no" value="<?php echo $_POST['adm_no']; ?>">
										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Class
											<div class="col-sm-6">
												<select name="class2023" class="form-control form-control-sm mb-3">
												<?php
							
													$cl=mysqli_query($link,"select * from class");
													$count=0;$count=mysqli_num_rows($cl);
													while($count>0)
														{   
														$clrow=mysqli_fetch_array($cl);
														echo "<option>".$clrow["class"]."</option>";
														$count-=1;
														
														}
													
												?>
												
												</select>
											</div>
														
											
          								 </div>
										   

										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Fees
											<div class='col-sm-6'><input type=text name="fees2023" class="form-control form-control-sm" placeholder="Monthly Fees " required></div>
						
										</div>

										<div class="form-group row">

											&nbsp &nbsp &nbsp &nbsp &nbsp Conveyance
											<div class="col-sm-6">
												<select name="con2023" class="form-control form-control-sm mb-3">
													<option>NO</option> 
													<option>YES</option>
												</select>
											</div>
										</div>

										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Conveyance Fees
											<div class='col-sm-6'><input type=text name="confees2023" class="form-control form-control-sm" placeholder="Conveyance Fees " required></div>
						
										</div>

										<div class="form-group row">
														&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp
											<div class='col-sm-6'><input type=submit name="reg2023" value="Transfer Class" class="btn btn-primary"></div>
										</div>
										

										   



									
								</form>
								
								<?php
								


            
                            }
							//session 2023-24 class transfer close

							//session 2023-24 class registered
                            else{
								?>
								<?php $tutrow=mysqli_fetch_array(mysqli_query($link,"SELECT * from tution2024 where adm_no='$row[adm_no]'"));
								echo "Fee :  ";echo $tutrow["fee"];  
								?>
								  |  Conveyance : <?php echo $row["conveyance2024"]; ?> 


								  <!-- session 2023-23 class registered -->
								<?php echo "<form name=form2023 class=form action=fee_under_processing_2023.php?adm=".$_POST["adm_no"]." method=post>"; ?>
								<br>&nbsp&nbsp Tution Fee<hr>
								
								<?php
										$row12023=mysqli_fetch_array(mysqli_query($link,"select * from tution2024 where adm_no='$_POST[adm_no]'"));
										$c=0;$i=0;$count=0;
										echo "<div class='table-responsive'><table ><tr>";
									if($row12023["April"]=='0'){
									echo "<td><input type=checkbox name=April value=April> April &nbsp </td>";$count+=1;
									if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									if($row12023["May"]=='0'){
									echo "<td><input type=checkbox name=May value=May> May </td>";$count+=1; if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12023["June"]=='0'){
									echo "<td> <input type=checkbox name=June value=June> June </td> ";$count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12023["July"]=='0'){
									echo "<td> <input type=checkbox name=July value=July> July</td>     "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12023["August"]=='0'){
									echo "<td><input type=checkbox name=August value=August> August </td> ";$count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12023["September"]=='0'){
									echo "<td> <input type=checkbox name=September value=September> September </td>      ";$count+=1; if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12023["October"]=='0'){
									echo "<td><input type=checkbox name=October value=October> October </td>     "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12023["November"]=='0'){
									echo "<td> <input type=checkbox name=November value=November> November </td>    ";$count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12023["December"]=='0'){
									echo "<td> <input type=checkbox name=December value=December> December </td>   "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12023["January"]=='0'){
									echo "<td> <input type=checkbox name=January value=January> January </td>    "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12023["February"]=='0'){
									echo "<td><input type=checkbox name=February value=February> February </td>     ";$count+=1; if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12023["March"]=='0'){
									echo "<td> <input type=checkbox name=March value=March> March </td>     "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
						 			echo "</tr></table></div>";
									//--------------------------------------------------------------------------
									//--------------------------------------------------------------------------						 
									$r=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$_POST[adm_no]'"));
									if($r["conveyance2024"]=="YES")
									{ 
										?>
									
										<hr>&nbsp&nbsp Conveyance Fee<hr>
									
									<?php
											$row12023=mysqli_fetch_array(mysqli_query($link,"select * from conveyance2024 where adm_no='$_POST[adm_no]'"));
											$c=0;$i=0;$count=0;
											echo "<table><tr>";
										if($row12023["April"]=='0'){
										echo "<td><input type=checkbox name=cApril value=April> April &nbsp </td>";$count+=1;
										if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row12023["May"]=='0'){
										echo "<td><input type=checkbox name=cMay value=May> May </td>";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["June"]=='0'){
										echo "<td> <input type=checkbox name=cJune value=June> June </td> ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["July"]=='0'){
										echo "<td> <input type=checkbox name=cJuly value=July> July</td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["August"]=='0'){
										echo "<td><input type=checkbox name=cAugust value=August> August </td> ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["September"]=='0'){
										echo "<td> <input type=checkbox name=cSeptember value=September> September </td>      ";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["October"]=='0'){
										echo "<td><input type=checkbox name=cOctober value=October> October </td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["November"]=='0'){
										echo "<td> <input type=checkbox name=cNovember value=November> November </td>    ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["December"]=='0'){
										echo "<td> <input type=checkbox name=cDecember value=December> December </td>   "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["January"]=='0'){
										echo "<td> <input type=checkbox name=cJanuary value=January> January </td>    "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["February"]=='0'){
										echo "<td><input type=checkbox name=cFebruary value=February> February </td>     ";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["March"]=='0'){
										echo "<td> <input type=checkbox name=cMarch value=March> March </td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										echo "</tr></table><hr>";
									}
									?>			  
									
									&nbsp&nbsp Other Fees<hr>
									<?php
											$row12023=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2024 where adm_no='$_POST[adm_no]'"));
											$c=0;$i=0;$count=0;
											echo "<table><tr>";
											if($r["sttype"]=="NEW")
											{
												if($row12023["form"]=='0'){
												echo "<td><input type=checkbox name=form value=Form> Form FEE &nbsp </td>";$count+=1;
												if($c==7)
												{echo "</tr><tr>";$c=-1;
												}$c+=1;}
										
												if($row12023["tie_belt"]=='0'){
															echo "<td><input type=checkbox name=tie_belt value=Tie_Belt> Tie&Belt </td>";$count+=1; if($c==7)
													{echo "</tr><tr>";$c=-1;
													}$c+=1;}
												if($row12023["adm_fee"]=='0'){
													echo "<td> <input type=checkbox name=adm_fee value=Adm_FEE> Adm. FEE </td> ";$count+=1;if($c==7)
													{echo "</tr><tr>";$c=-1;
													}$c+=1;}
											}
										
										if($row12023["idcard"]=='0'){
										echo "<td> <input type=checkbox name=idcard value=IDCARD> IDCARD</td>     "; $count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["exam1"]=='0'){
										echo "<td><input type=checkbox name=exam1 value=exam1> TM Exam </td> ";$count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["exam2"]=='0'){
										echo "<td> <input type=checkbox name=exam2 value=exam2> HY Exam </td>      ";$count+=1; if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["exam3"]=='0'){
										echo "<td><input type=checkbox name=exam3 value=exam3> Y Exam </td>     "; $count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["result_card"]=='0'){
										echo "<td><input type=checkbox name=result_card value=result_card> Result Card </td>     "; $count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										
										echo "</tr></table><hr>";
									
									?>			  
									
									
									<center><input type=submit class="btn btn-primary" name="payfee2020" value="Pay FEE"></center>
									
								</form>
								
								<?php
                            }
                        ?>
					</div>
					<!-- session 2023-24 left area  close-->


					<!-- session 2023-24 right area -->
				  	<div class="col-md-6" id="div2022paid">
							<?php 
								if($row["class2023"]!='0'){
									?>
									<font size=4px style="color:#2121ff;"> <br><u><center>TUITION FEES PAID FOR MONTHS</center></u></FONT>
									<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
									<?php
										
										$res1=mysqli_query($link,"select * from tution2024 where adm_no='$_POST[adm_no]'");
										$row12023=mysqli_fetch_array($res1);
										$c=0;$i=0;$count=0;
										
										if($row12023["April"]=='Y'){
										echo "<td>April </td>      ";$count+=1;
										if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row12023["May"]=='Y'){
										echo "<td>May    </td>   "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["June"]=='Y'){
										echo "<td>June  </td>   ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["July"]=='Y'){
										echo "<td>July   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["August"]=='Y'){
										echo "<td>August   </td>";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["September"]=='Y'){
										echo "<td>September   </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["October"]=='Y'){
										echo "<td>October    </td> ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["November"]=='Y'){
										echo "<td>November   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["December"]=='Y'){
										echo "<td>December     </td>";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["January"]=='Y'){
										echo "<td>January    </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["February"]=='Y'){
										echo "<td>February   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["March"]=='Y'){
										echo "<td>March     </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($count==0)
											echo "<center><h1>FEES not paid for any months</h1></center>";
										
										
									
									?></font></TABLE>

									<!-- conveyance 2023-24 paid -->
									<?php
									if($row['conveyance2024']=='YES'){
										?>
										<font size=4px style="color:#2121ff;"> <br><u><center>Conveyance FEES PAID FOR MONTHS</center></u></FONT>
										<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
													
										<?php
										$res1=mysqli_query($link,"select * from conveyance2024 where adm_no='$_POST[adm_no]'");
										$row12023=mysqli_fetch_array($res1);
										$c=0;$i=0;$count=0;
										if($row12023["April"]=='Y'){
										echo "<td>April </td>      ";$count+=1;
										if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row12023["May"]=='Y'){
										echo "<td border=0>May    </td>   ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["June"]=='Y'){
										echo "<td>June  </td>   "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["July"]=='Y'){
										echo "<td>July   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["August"]=='Y'){
										echo "<td>August   </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["September"]=='Y'){
										echo "<td>September   </td>";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["October"]=='Y'){
										echo "<td>October    </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["November"]=='Y'){
										echo "<td>November   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["December"]=='Y'){
										echo "<td>December     </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["January"]=='Y'){
										echo "<td>January    </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["February"]=='Y'){
										echo "<td>February   </td> ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12023["March"]=='Y'){
										echo "<td>March     </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($count==0)
											echo "<center><h1>FEES not paid for any months</h1></center>";
										
									
										?></font></TABLE>
										
										
										<?php
									}
									?>
										
									<!-- otherfee 2023-24 paid -->
									<font size=4px style="color:#2121ff;"> <br><u><center>Other FEES PAID</center></u></FONT>
									<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
												
										<?php
											$otherres=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2024 where adm_no='$_POST[adm_no]'"));
											if($otherres["idcard"]=="Y")
												echo "<td>ID Card </td>";
											if($otherres["form"]=="Y")
												echo "<td>Form </td>";
											
											if($otherres["adm_fee"]=="Y")
												echo "<td>Admission FEE </td>";
											
											if($otherres["tie_belt"]=="Y")
												echo "<td>Tie&Belt </td><tr>";
											
											if($otherres["exam1"]=="Y")
												echo "<td>Third Monthly Exam</td>";
											if($otherres["exam2"]=="Y")
												echo "<td>Half Yearly Exam</td>";
											if($otherres["exam3"]=="Y")
												echo "<td>Yearly Exam</td>";
											if($otherres["result_card"]==50)
												echo "<td>Result Card</td>";
											
										
										?></font>
									</TABLE>
									



									<?php

									
							
								}
							?>
				 	 </div>
					<!-- session 2023-24 right area close-->
				</div>
				<!-- session 2023-24 close -->


				<hr style="color:red;size:2px;">
			 <br><BR><BR>


			 <!-- session 2024-25 area -->
			 <div class="row bg-white has-shadow">
					  <!-- session 2024-25 left area -->	
				 	 <div class="col-md-6" style="background-color: #f2f2f2">
                        <h4 style="color:#060c21">Session 2024-25   |  <?php if($row["class2024"]==='0')echo "Not Registered"; else echo $row["class2024"]; ?>  </h4>

						
						
						  <?php
						  	//session 2024-25 class transfer
                            if($row["class2024"]=='0'){
								?>
								
								<form name="class2024reg" method="post">
										<input type="hidden" name="adm_no" value="<?php echo $_POST['adm_no']; ?>">
										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Class
											<div class="col-sm-6">
												<select name="class2024" class="form-control form-control-sm mb-3">
												<?php
							
													$cl=mysqli_query($link,"select * from class");
													$count=0;$count=mysqli_num_rows($cl);
													while($count>0)
														{   
														$clrow=mysqli_fetch_array($cl);
														echo "<option>".$clrow["class"]."</option>";
														$count-=1;
														
														}
													
												?>
												
												</select>
											</div>
														
											
          								 </div>
										   

										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Fees
											<div class='col-sm-6'><input type=text name="fees2024" class="form-control form-control-sm" placeholder="Monthly Fees " required></div>
						
										</div>

										<div class="form-group row">

											&nbsp &nbsp &nbsp &nbsp &nbsp Conveyance
											<div class="col-sm-6">
												<select name="con2024" class="form-control form-control-sm mb-3">
													<option>NO</option> 
													<option>YES</option>
												</select>
											</div>
										</div>

										<div class="form-group row">
											&nbsp &nbsp &nbsp &nbsp &nbsp Conveyance Fees
											<div class='col-sm-6'><input type=text name="confees2024" class="form-control form-control-sm" placeholder="Conveyance Fees " required></div>
						
										</div>

										<div class="form-group row">
														&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp
											<div class='col-sm-6'><input type=submit name="reg2024" value="Transfer Class" class="btn btn-primary"></div>
										</div>
										

										   



									
								</form>
								
								<?php
								


            
                            }
							//session 2024-25 class transfer close

							//session 2024-25 class registered
                            else{
								?>
								<?php $tutrow=mysqli_fetch_array(mysqli_query($link,"SELECT * from tution2025 where adm_no='$row[adm_no]'"));
								echo "Fee :  ";echo $tutrow["fee"];  
								?>
								  |  Conveyance : <?php echo $row["conveyance2025"]; ?> 


								  <!-- session 2024-25 class registered -->
								<?php echo "<form name=form2024 class=form action=fee_under_processing_2024.php?adm=".$_POST["adm_no"]." method=post>"; ?>
								<br>&nbsp&nbsp Tution Fee<hr>
								
								<?php
										$row12024=mysqli_fetch_array(mysqli_query($link,"select * from tution2025 where adm_no='$_POST[adm_no]'"));
										$c=0;$i=0;$count=0;
										echo "<div class='table-responsive'><table ><tr>";
									if($row12024["April"]=='0'){
									echo "<td><input type=checkbox name=April value=April> April &nbsp </td>";$count+=1;
									if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
									if($row12024["May"]=='0'){
									echo "<td><input type=checkbox name=May value=May> May </td>";$count+=1; if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12024["June"]=='0'){
									echo "<td> <input type=checkbox name=June value=June> June </td> ";$count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12024["July"]=='0'){
									echo "<td> <input type=checkbox name=July value=July> July</td>     "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12024["August"]=='0'){
									echo "<td><input type=checkbox name=August value=August> August </td> ";$count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12024["September"]=='0'){
									echo "<td> <input type=checkbox name=September value=September> September </td>      ";$count+=1; if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12024["October"]=='0'){
									echo "<td><input type=checkbox name=October value=October> October </td>     "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12024["November"]=='0'){
									echo "<td> <input type=checkbox name=November value=November> November </td>    ";$count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12024["December"]=='0'){
									echo "<td> <input type=checkbox name=December value=December> December </td>   "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12024["January"]=='0'){
									echo "<td> <input type=checkbox name=January value=January> January </td>    "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12024["February"]=='0'){
									echo "<td><input type=checkbox name=February value=February> February </td>     ";$count+=1; if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									if($row12024["March"]=='0'){
									echo "<td> <input type=checkbox name=March value=March> March </td>     "; $count+=1;if($c==5)
									{echo "</tr><tr>";$c=-1;
									}$c+=1;}
									
						 			echo "</tr></table></div>";
									//--------------------------------------------------------------------------
									//--------------------------------------------------------------------------						 
									$r=mysqli_fetch_array(mysqli_query($link,"select * from student where adm_no='$_POST[adm_no]'"));
									if($r["conveyance2025"]=="YES")
									{ 
										?>
									
										<hr>&nbsp&nbsp Conveyance Fee<hr>
									
									<?php
											$row12024=mysqli_fetch_array(mysqli_query($link,"select * from conveyance2025 where adm_no='$_POST[adm_no]'"));
											$c=0;$i=0;$count=0;
											echo "<table><tr>";
										if($row12024["April"]=='0'){
										echo "<td><input type=checkbox name=cApril value=April> April &nbsp </td>";$count+=1;
										if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row12024["May"]=='0'){
										echo "<td><input type=checkbox name=cMay value=May> May </td>";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["June"]=='0'){
										echo "<td> <input type=checkbox name=cJune value=June> June </td> ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["July"]=='0'){
										echo "<td> <input type=checkbox name=cJuly value=July> July</td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["August"]=='0'){
										echo "<td><input type=checkbox name=cAugust value=August> August </td> ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["September"]=='0'){
										echo "<td> <input type=checkbox name=cSeptember value=September> September </td>      ";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["October"]=='0'){
										echo "<td><input type=checkbox name=cOctober value=October> October </td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["November"]=='0'){
										echo "<td> <input type=checkbox name=cNovember value=November> November </td>    ";$count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["December"]=='0'){
										echo "<td> <input type=checkbox name=cDecember value=December> December </td>   "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["January"]=='0'){
										echo "<td> <input type=checkbox name=cJanuary value=January> January </td>    "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["February"]=='0'){
										echo "<td><input type=checkbox name=cFebruary value=February> February </td>     ";$count+=1; if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["March"]=='0'){
										echo "<td> <input type=checkbox name=cMarch value=March> March </td>     "; $count+=1;if($c==5)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										echo "</tr></table><hr>";
									}
									?>			  
									
									&nbsp&nbsp Other Fees<hr>
									<?php
											$row12024=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2025 where adm_no='$_POST[adm_no]'"));
											$c=0;$i=0;$count=0;
											echo "<table><tr>";
											if($r["sttype"]=="NEW")
											{
												if($row12024["form"]=='0'){
												echo "<td><input type=checkbox name=form value=Form> Form FEE &nbsp </td>";$count+=1;
												if($c==7)
												{echo "</tr><tr>";$c=-1;
												}$c+=1;}
										
												if($row12024["tie_belt"]=='0'){
															echo "<td><input type=checkbox name=tie_belt value=Tie_Belt> Tie&Belt </td>";$count+=1; if($c==7)
													{echo "</tr><tr>";$c=-1;
													}$c+=1;}
												if($row12024["adm_fee"]=='0'){
													echo "<td> <input type=checkbox name=adm_fee value=Adm_FEE> Adm. FEE </td> ";$count+=1;if($c==7)
													{echo "</tr><tr>";$c=-1;
													}$c+=1;}
											}
										
										if($row12024["idcard"]=='0'){
										echo "<td> <input type=checkbox name=idcard value=IDCARD> IDCARD</td>     "; $count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["exam1"]=='0'){
										echo "<td><input type=checkbox name=exam1 value=exam1> TM Exam </td> ";$count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["exam2"]=='0'){
										echo "<td> <input type=checkbox name=exam2 value=exam2> HY Exam </td>      ";$count+=1; if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["exam3"]=='0'){
										echo "<td><input type=checkbox name=exam3 value=exam3> Y Exam </td>     "; $count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["result_card"]=='0'){
										echo "<td><input type=checkbox name=result_card value=result_card> Result Card </td>     "; $count+=1;if($c==7)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										
										echo "</tr></table><hr>";
									
									?>			  
									
									
									<center><input type=submit class="btn btn-primary" name="payfee2020" value="Pay FEE"></center>
									
								</form>
								
								<?php
                            }
                        ?>
					</div>
					<!-- session 2024-25 left area  close-->


					<!-- session 2024-25 right area -->
				  	<div class="col-md-6" id="div2022paid">
							<?php 
								if($row["class2024"]!='0'){
									?>
									<font size=4px style="color:#2121ff;"> <br><u><center>TUITION FEES PAID FOR MONTHS</center></u></FONT>
									<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
									<?php
										
										$res1=mysqli_query($link,"select * from tution2025 where adm_no='$_POST[adm_no]'");
										$row12024=mysqli_fetch_array($res1);
										$c=0;$i=0;$count=0;
										
										if($row12024["April"]=='Y'){
										echo "<td>April </td>      ";$count+=1;
										if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row12024["May"]=='Y'){
										echo "<td>May    </td>   "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["June"]=='Y'){
										echo "<td>June  </td>   ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["July"]=='Y'){
										echo "<td>July   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["August"]=='Y'){
										echo "<td>August   </td>";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["September"]=='Y'){
										echo "<td>September   </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["October"]=='Y'){
										echo "<td>October    </td> ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["November"]=='Y'){
										echo "<td>November   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["December"]=='Y'){
										echo "<td>December     </td>";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["January"]=='Y'){
										echo "<td>January    </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["February"]=='Y'){
										echo "<td>February   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["March"]=='Y'){
										echo "<td>March     </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($count==0)
											echo "<center><h1>FEES not paid for any months</h1></center>";
										
										
									
									?></font></TABLE>

									<!-- conveyance 2023-24 paid -->
									<?php
									if($row['conveyance2025']=='YES'){
										?>
										<font size=4px style="color:#2121ff;"> <br><u><center>Conveyance FEES PAID FOR MONTHS</center></u></FONT>
										<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
													
										<?php
										$res1=mysqli_query($link,"select * from conveyance2025 where adm_no='$_POST[adm_no]'");
										$row12024=mysqli_fetch_array($res1);
										$c=0;$i=0;$count=0;
										if($row12024["April"]=='Y'){
										echo "<td>April </td>      ";$count+=1;
										if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($row12024["May"]=='Y'){
										echo "<td border=0>May    </td>   ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["June"]=='Y'){
										echo "<td>June  </td>   "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["July"]=='Y'){
										echo "<td>July   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["August"]=='Y'){
										echo "<td>August   </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["September"]=='Y'){
										echo "<td>September   </td>";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["October"]=='Y'){
										echo "<td>October    </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["November"]=='Y'){
										echo "<td>November   </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["December"]=='Y'){
										echo "<td>December     </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["January"]=='Y'){
										echo "<td>January    </td>"; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["February"]=='Y'){
										echo "<td>February   </td> ";$count+=1; if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										if($row12024["March"]=='Y'){
										echo "<td>March     </td> "; $count+=1;if($c==3)
										{echo "</tr><tr>";$c=-1;
										}$c+=1;}
										
										if($count==0)
											echo "<center><h1>FEES not paid for any months</h1></center>";
										
									
										?></font></TABLE>
										
										
										<?php
									}
									?>
										
									<!-- otherfee 2024-25 paid -->
									<font size=4px style="color:#2121ff;"> <br><u><center>Other FEES PAID</center></u></FONT>
									<TABLE BORDER=1 color=green width=100%><font face="TimesNewRoman" color="#ff2211"><tr>
												
										<?php
											$otherres=mysqli_fetch_array(mysqli_query($link,"select * from otherfee2025 where adm_no='$_POST[adm_no]'"));
											if($otherres["idcard"]=="Y")
												echo "<td>ID Card </td>";
											if($otherres["form"]=="Y")
												echo "<td>Form </td>";
											
											if($otherres["adm_fee"]=="Y")
												echo "<td>Admission FEE </td>";
											
											if($otherres["tie_belt"]=="Y")
												echo "<td>Tie&Belt </td><tr>";
											
											if($otherres["exam1"]=="Y")
												echo "<td>Third Monthly Exam</td>";
											if($otherres["exam2"]=="Y")
												echo "<td>Half Yearly Exam</td>";
											if($otherres["exam3"]=="Y")
												echo "<td>Yearly Exam</td>";
											if($otherres["result_card"]==50)
												echo "<td>Result Card</td>";
											
										
										?></font>
									</TABLE>
									



									<?php

									
							
								}
							?>
				 	 </div>
					<!-- session 2024-25 right area close-->
				</div>
				<!-- session 2024-25 close -->


				<hr style="color:red;size:2px;">
			 <br><BR><BR>

			
		<?php
				     
				  //fee form
				  
				  
				  
				  
			  }
		  }

		  if(!isset($_POST["reg2020"]))
		    { 
		       
			 }
			 else{

				$adm_no=$_POST["adm_no"];
                $roll=mysqli_num_rows(mysqli_query($link,"select * from student where class2020='$_POST[class2020]'"))+1;
				$cl2020stat=mysqli_query($link,"UPDATE student SET class2020='$_POST[class2020]', roll2020='$roll' where adm_no='$adm_no' ");
				$tution2020stat=mysqli_query($link,"INSERT INTO tution2021 VALUES ('$adm_no','$adm_no','$_POST[fees2020]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
				$otherfee2020stat=mysqli_query($link,"INSERT INTO otherfee2021 VALUES ('$adm_no','$adm_no',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
				if($_POST['con2020']==='YES'){
					$conveyance2020stat=mysqli_query($link,"INSERT INTO conveyance2021 VALUES ('$adm_no','$adm_no','$_POST[confees2020]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
					$cl2020stat=mysqli_query($link,"UPDATE student SET conveyance2021='$_POST[con2020]' where adm_no='$adm_no' ");
				}
				?>
				 	<script type="text/javascript">
					 	alert("Class Transfer Successful");
					 </script>
					 <?php
						echo "<h1>Class Transfer Successful</h1>";
						echo "<h1>Admission No : '$adm_no'";

			 }
		  
            if(!isset($_POST["reg2021"])){ 		       
			}
			else{

				$adm_no=$_POST["adm_no"];
                $roll=mysqli_num_rows(mysqli_query($link,"select * from student where class2021='$_POST[class2021]'"))+1;
				$cl2021stat=mysqli_query($link,"UPDATE student SET class2021='$_POST[class2021]', roll2021='$roll' where adm_no='$adm_no' ");
				$tution2020stat=mysqli_query($link,"INSERT INTO tution2022 VALUES ('$adm_no','$adm_no','$_POST[fees2021]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
				$otherfee2020stat=mysqli_query($link,"INSERT INTO otherfee2022 VALUES ('$adm_no','$adm_no',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
				if($_POST['con2021']==='YES'){
					$conveyance2020stat=mysqli_query($link,"INSERT INTO conveyance2022 VALUES ('$adm_no','$adm_no','$_POST[confees2021]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
					$cl2020stat=mysqli_query($link,"UPDATE student SET conveyance2022='$_POST[con2021]' where adm_no='$adm_no' ");
				}
				?>
				 	<script type="text/javascript">
					 	alert("Class Transfer Successful");
					 </script>
					 <?php
						echo "<h1>Class Transfer Successful</h1>";
						echo "<h1>Admission No : '$adm_no'";

			}

			if(!isset($_POST["reg2022"])){ 		       
			}
			else{

				$adm_no=$_POST["adm_no"];
                $roll=mysqli_num_rows(mysqli_query($link,"select * from student where class2022='$_POST[class2022]'"))+1;
				$cl2021stat=mysqli_query($link,"UPDATE student SET class2022='$_POST[class2022]', roll2022='$roll' where adm_no='$adm_no' ");
				$tution2020stat=mysqli_query($link,"INSERT INTO tution2023 VALUES ('$adm_no','$adm_no','$_POST[fees2022]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
				$otherfee2020stat=mysqli_query($link,"INSERT INTO otherfee2023 VALUES ('$adm_no','$adm_no',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
				if($_POST['con2022']==='YES'){
					$conveyance2020stat=mysqli_query($link,"INSERT INTO conveyance2023 VALUES ('$adm_no','$adm_no','$_POST[confees2022]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
					$cl2020stat=mysqli_query($link,"UPDATE student SET conveyance2023='$_POST[con2022]' where adm_no='$adm_no' ");
				}
				?>
				 	<script type="text/javascript">
					 	alert("Class Transfer Successful");
					 </script>
					 <?php
						echo "<h1>Class Transfer Successful</h1>";
						echo "<h1>Admission No : '$adm_no'";

			}
			
			
			if(!isset($_POST["reg2023"])){ 		       
			}
			else{

				$adm_no=$_POST["adm_no"];
                $roll=mysqli_num_rows(mysqli_query($link,"select * from student where class2023='$_POST[class2023]'"))+1;
				$cl2023stat=mysqli_query($link,"UPDATE student SET class2023='$_POST[class2023]', roll2023='$roll' where adm_no='$adm_no' ");
				$tution2023stat=mysqli_query($link,"INSERT INTO tution2024 VALUES ('$adm_no','$adm_no','$_POST[fees2023]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
				$otherfee2023stat=mysqli_query($link,"INSERT INTO otherfee2024 VALUES ('$adm_no','$adm_no',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
				if($_POST['con2023']==='YES'){
					$conveyance2023stat=mysqli_query($link,"INSERT INTO conveyance2024 VALUES ('$adm_no','$adm_no','$_POST[confees2023]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
					$cl2023stat=mysqli_query($link,"UPDATE student SET conveyance2024='$_POST[con2023]' where adm_no='$adm_no' ");
				}
				?>
				 	<script type="text/javascript">
					 	alert("Class Transfer Successful");
					 </script>
					 <?php
						echo "<h1>Class Transfer Successful</h1>";
						echo "<h1>Admission No : '$adm_no'";

			}

			if(!isset($_POST["reg2024"])){ 		       
			}
			else{

				$adm_no=$_POST["adm_no"];
                $roll=mysqli_num_rows(mysqli_query($link,"select * from student where class2024='$_POST[class2024]'"))+1;
				$cl2023stat=mysqli_query($link,"UPDATE student SET class2024='$_POST[class2024]', roll2024='$roll' where adm_no='$adm_no' ");
				$tution2023stat=mysqli_query($link,"INSERT INTO tution2025 VALUES ('$adm_no','$adm_no','$_POST[fees2024]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
				$otherfee2023stat=mysqli_query($link,"INSERT INTO otherfee2025 VALUES ('$adm_no','$adm_no',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
				if($_POST['con2024']==='YES'){
					$conveyance2023stat=mysqli_query($link,"INSERT INTO conveyance2025 VALUES ('$adm_no','$adm_no','$_POST[confees2024]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)");
					$cl2023stat=mysqli_query($link,"UPDATE student SET conveyance2025='$_POST[con2024]' where adm_no='$adm_no' ");
				}
				?>
				 	<script type="text/javascript">
					 	alert("Class Transfer Successful");
					 </script>
					 <?php
						echo "<h1>Class Transfer Successful</h1>";
						echo "<h1>Admission No : '$adm_no'";

			}
		  
			
		    
		if(!isset($_POST["search"])){ 
		 }
		else
		{
			  $res=mysqli_query($link,"select * from student where name like '%$_POST[name]%'");
			  $count=0;
			  $count=mysqli_num_rows($res);
			  if($count==0)
			  {  ?><div style="float:right"><?php echo " Student with Name <font color=red>".$_POST["name"]."</font> is not found"."</div>";
		      }
			  else
			  {   ?>
				  <table border=1 width=80%>
				  <tr style="background:#2dd2ff;"><th>Sr_NO.</th><th>Adm_NO.</th><th>Student Name </th><th> Father's Name</th><th> Class </th> <th> Conveyance</th></tr>
				  <?php $sn=1;
		         while($count--){
				  $row=mysqli_fetch_array($res); 
				  
				  
				    if($sn%2==0)
					  echo "<tr style='background:#adadff;'>";
				  else
					  echo "<tr style='background:#ccccff;'>";
				 
					              echo "<td width=4%>".$sn."</td><td>".$row["adm_no"]."</td><td>".$row["name"]." </td><td>".$row["father_name"]."</td><td>".$row["class"]."</td> <td>".$row["conveyance"]."</td></tr>";
				 $sn=1+$sn;
				 }
			  }
		}
		  ?>
		  </table>
		  
	  
			
    </div>

<?php
}
?>

<?php
 include "footer.php";
 ?>
