<?php
  include "header.php";
  include "connection.php";
  if(!isset($_SESSION["teacher_user"]))
 {
   ?>
   <script type="text/javascript">
      window.location="StaffLogin.php";
   </script>
   <?php
 }
 else
  {
?>
    <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Add Student</h2>
            </div>
          </header>
    


    <div class="container-fluid">
      <br>
      <form name="form1" class="form" action="" method="post">
      <div class="row bg-white has-shadow">
        <div class="col-md-4">
          <div class="form-group row">
                          Student Type
                          <div class="col-sm-6">
                            <select name="sttype" class="form-control form-control-sm mb-3" >
                              
                              <option>NEW</option>
                              
                            </select>
                          </div>
           </div>
         </div>
        <div class="col-md-4">
          <div class="form-group row">
          Admission No.
          <?php $adm=20240111+mysqli_num_rows(mysqli_query($link,"select * from student")); 
           echo "<div class='col-sm-6'><input type='text' name='adm' value=".$adm." class='form-control form-control-sm mb-3' disabled ></div>"  ?>
         </div>
        </div>
        <div class="col-md-4">
          <div class="form-group row">
                          Class
                          <div class="col-sm-6">
                            <select name="class" class="form-control form-control-sm mb-3">
                              <?php
            
           $cl=mysqli_query($link,"select * from class");
                 
           $count=0;$count=mysqli_num_rows($cl);
              
           while($count>0)
             {   
              $row=mysqli_fetch_array($cl);
               echo "<option>".$row["class"]."</option>";
              $count-=1;
            
              }
        
        ?>
                              
                            </select>
                          </div>
           </div>
        </div>
      </div>

      <br>

      <div class="row bg-white has-shadow">
          <div class="col-md-6">
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Name</label>
                          <div class="col-sm-6">
                            <input type="text" name="stname" placeholder="Student Full name" required class="form-control form-control-sm ">
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Father's Name</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="fname" placeholder="Father's Full name" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Mother's Name</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="mname" placeholder="Mother's Full name" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Address</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="add1" placeholder="Address Line 1" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label"></label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="add2" placeholder="Address Line 2" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Contact No.</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="mob1" placeholder="Mobile 1" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label"></label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="mob2" placeholder="Mobile 2" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Aadhar No.</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="aadhaar" placeholder="Aadhaar Number" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Date of Birth</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="dob" placeholder="dd/mm/yyyy" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Nationality</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="nationality" value="Indian" >
                          </div>
            </div>

          </div>



          <div class="col-md-6">
<div class="form-group row">
                          <label class="col-sm-3 form-control-label">Religion</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="religion" placeholder="Religion" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Caste</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="caste" placeholder="Caste" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Category</label>
                          <div class="col-sm-6">
                            <select name="category" class="form-control form-control-sm mb-3">
                              <option>OBC</option>
                              <option>GEN</option>
                              <option>SC</option>
                              <option>ST</option>
                              
                            </select>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Gender</label>
                          <div class="col-sm-6">
                            <select name="gender" class="form-control form-control-sm mb-3">
                              <option>Male</option>
                              <option>Female</option>
                              
                            </select>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Height</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="height" placeholder="Height" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Weight</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="weight" placeholder="Weight" required>
                          </div>
            </div>
            
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Tuition FEE</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="tut_fee" placeholder="Monthly Tution Fee" required>
                          </div>
            </div>
            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Conveyance</label>
                          <div class="col-sm-6">
                            <select name="con" class="form-control form-control-sm mb-3">
                              <option>NO</option>
                              <option>YES</option>
                              
                            </select>
                          </div>
            </div>


            <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Conveyance FEE</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm " name="con_fee" placeholder="Monthly Conveyance Fee" required>
                          </div>
            </div>

            <center>Ensure that all the information provided are correct.<br><br><br>
              <input type="submit" class="btn btn-primary" name="submit1">
              </center>

          </div>



          
      </div>
      </form>       
    </div>

<?php
       if(!isset($_POST["submit1"]))
       {
         
              
       }
         else
         {   
             
          
             $doa=date("d/m/Y");
             $password="password";
           $idc=$adm;
           $classnow=$_POST['class'];
                 $roll=mysqli_num_rows(mysqli_query($link,"select * from student where class2024='$classnow'"))+1;
                 
                 $rrrr=mysqli_query($link,"insert into student values('$adm','$adm','$_POST[stname]','$_POST[fname]','$_POST[mname]','$_POST[add1]','$_POST[add2]','$_POST[aadhaar]','$_POST[mob1]','$_POST[mob2]','$_POST[dob]','$_POST[nationality]','$_POST[religion]','$_POST[caste]','$_POST[sttype]','$password','0','0','0','NO','NO','0','0','NO','0','0','NO','0','0','NO','$_POST[class]','$roll','$_POST[con]','$doa')");
           ?>
                 
                     
                    <?php
           $st_c=mysqli_num_rows(mysqli_query($link,"select * from student where adm_no='$adm'"));
           
           if($st_c==1)
           {$idc+=1;
           mysqli_query($link,"insert into otherfee2025 values('$idc','$adm','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0')");
                $idc-=1;
                mysqli_query($link,"insert into tution2025 values('$idc','$adm','$_POST[tut_fee]','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0')");
             if($_POST['con']=='YES')
             { 
           mysqli_query($link,"insert into conveyance2025 values('$idc','$adm','$_POST[con_fee]','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0')");
         
             }
           
           ?>
           <script type="text/javascript">
          
            alert("\n\n\n            Admission Successful\n\n            Admission No. : <?php echo $adm; ?>");
                        
            
             window.location="./adm_success.php?adm=<?php echo $adm; ?>";
            
            
          </script>
           
           
           <?php
           }
           else
           {
             ?>
                <script type="text/javascript">
          
            alert("\n\n\n            Admission Not Successful\nTry Again\n");
                        
             window.location="./add_student.php";
            
            
            
                </script>
           
           
           <?php
           }
           
           
      }        
     
      ?>
        
     





<?php
}
?>

<?php
  include "footer.php";
?>
          
          